﻿using System;
using System.Diagnostics;

namespace KG_Killer
{
	// Token: 0x0200006D RID: 109
	internal class KillCommand
	{
		// Token: 0x06000239 RID: 569 RVA: 0x0002667C File Offset: 0x0002487C
		public static void ProcessKill()
		{
			string[] array = new string[]
			{
				"Python", "Python.exe", "QMSL_MSVC10R", "QMSL_MSVC10R.dll", "pythonw", "pythonw.exe", "sampropy.dll", "adb", "adb.exe", "fh_loader",
				"fh_loader.exe", "adb", "adb.exe", "fastboot", "fastboot.exe", "install_x86", "install_x86.exe", "install_x64", "install_x64.exe", "linux-adk",
				"emmcdl", "emmcdl.exe", "linux-adk.exe", "cmd.exe", "cmd"
			};
			foreach (string text in array)
			{
				Process[] processes = Process.GetProcesses();
				foreach (Process process in processes)
				{
					if ((process.ProcessName.ToLower() ?? "") == (text.ToLower() ?? ""))
					{
						process.Kill();
						process.WaitForExit();
						process.Dispose();
					}
				}
			}
		}
	}
}
