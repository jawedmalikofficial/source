﻿using System;
using System.Windows.Forms;

namespace KG_Killer
{
	// Token: 0x0200006F RID: 111
	internal static class Program
	{
		// Token: 0x0600023E RID: 574 RVA: 0x0002695C File Offset: 0x00024B5C
		[STAThread]
		private static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Form3 form = new Form3();
			form.Show();
			Application.Run();
		}
	}
}
