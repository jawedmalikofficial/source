﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace KG_Killer
{
	// Token: 0x02000067 RID: 103
	public partial class Form2 : Form
	{
		// Token: 0x06000214 RID: 532 RVA: 0x00024180 File Offset: 0x00022380
		public Form2()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000215 RID: 533 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void pictureBox1_Click(object sender, EventArgs e)
		{
		}
	}
}
