﻿namespace KG_Killer
{
	// Token: 0x0200006C RID: 108
	public partial class imei : global::System.Windows.Forms.Form
	{
		// Token: 0x06000237 RID: 567 RVA: 0x00026278 File Offset: 0x00024478
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000238 RID: 568 RVA: 0x000262A8 File Offset: 0x000244A8
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::KG_Killer.imei));
			this.textBox1 = new global::System.Windows.Forms.TextBox();
			this.label1 = new global::System.Windows.Forms.Label();
			this.button16 = new global::System.Windows.Forms.Button();
			this.pictureBox2 = new global::System.Windows.Forms.PictureBox();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox2).BeginInit();
			base.SuspendLayout();
			this.textBox1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.textBox1.Location = new global::System.Drawing.Point(98, 257);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new global::System.Drawing.Size(271, 26);
			this.textBox1.TabIndex = 0;
			this.textBox1.KeyPress += new global::System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
			this.label1.AutoSize = true;
			this.label1.BackColor = global::System.Drawing.Color.Transparent;
			this.label1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 11.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label1.ForeColor = global::System.Drawing.SystemColors.ButtonFace;
			this.label1.Location = new global::System.Drawing.Point(12, 261);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(76, 18);
			this.label1.TabIndex = 2;
			this.label1.Text = "Enter IMEI";
			this.button16.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button16.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button16.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold);
			this.button16.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button16.Image");
			this.button16.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button16.Location = new global::System.Drawing.Point(142, 319);
			this.button16.Name = "button16";
			this.button16.Size = new global::System.Drawing.Size(126, 39);
			this.button16.TabIndex = 14;
			this.button16.Text = "    Submit Now";
			this.button16.UseVisualStyleBackColor = false;
			this.button16.Click += new global::System.EventHandler(this.button16_Click);
			this.pictureBox2.BackColor = global::System.Drawing.Color.Transparent;
			this.pictureBox2.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox2.Image");
			this.pictureBox2.Location = new global::System.Drawing.Point(95, 12);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new global::System.Drawing.Size(196, 192);
			this.pictureBox2.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox2.TabIndex = 16;
			this.pictureBox2.TabStop = false;
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("$this.BackgroundImage");
			this.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			base.ClientSize = new global::System.Drawing.Size(382, 402);
			base.Controls.Add(this.pictureBox2);
			base.Controls.Add(this.button16);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.textBox1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.Name = "imei";
			base.ShowInTaskbar = false;
			this.Text = "KG Active 01";
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox2).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x040003C5 RID: 965
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x040003C6 RID: 966
		private global::System.Windows.Forms.TextBox textBox1;

		// Token: 0x040003C7 RID: 967
		private global::System.Windows.Forms.Label label1;

		// Token: 0x040003C8 RID: 968
		private global::System.Windows.Forms.Button button16;

		// Token: 0x040003C9 RID: 969
		private global::System.Windows.Forms.PictureBox pictureBox2;
	}
}
