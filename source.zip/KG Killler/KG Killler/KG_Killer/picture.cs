﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace KG_Killer
{
	// Token: 0x0200006E RID: 110
	public partial class picture : Form
	{
		// Token: 0x0600023B RID: 571 RVA: 0x000267E4 File Offset: 0x000249E4
		public picture()
		{
			this.InitializeComponent();
		}
	}
}
