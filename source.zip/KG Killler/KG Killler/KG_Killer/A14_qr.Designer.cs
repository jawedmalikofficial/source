﻿namespace KG_Killer
{
	// Token: 0x0200001C RID: 28
	public partial class A14_qr : global::System.Windows.Forms.Form
	{
		// Token: 0x060000A7 RID: 167 RVA: 0x0000826C File Offset: 0x0000646C
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x060000A8 RID: 168 RVA: 0x0000829C File Offset: 0x0000649C
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::KG_Killer.A14_qr));
			this.textBox1 = new global::System.Windows.Forms.TextBox();
			this.label1 = new global::System.Windows.Forms.Label();
			this.button4 = new global::System.Windows.Forms.Button();
			this.pictureBox1 = new global::System.Windows.Forms.PictureBox();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).BeginInit();
			base.SuspendLayout();
			this.textBox1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.textBox1.Location = new global::System.Drawing.Point(114, 50);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new global::System.Drawing.Size(166, 22);
			this.textBox1.TabIndex = 1;
			this.textBox1.TextChanged += new global::System.EventHandler(this.textBox1_TextChanged);
			this.label1.AutoSize = true;
			this.label1.BackColor = global::System.Drawing.Color.Transparent;
			this.label1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label1.ForeColor = global::System.Drawing.SystemColors.ButtonFace;
			this.label1.Location = new global::System.Drawing.Point(42, 53);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(66, 16);
			this.label1.TabIndex = 2;
			this.label1.Text = "Serial No.";
			this.button4.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button4.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button4.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold);
			this.button4.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button4.Image");
			this.button4.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button4.Location = new global::System.Drawing.Point(137, 78);
			this.button4.Name = "button4";
			this.button4.Size = new global::System.Drawing.Size(120, 38);
			this.button4.TabIndex = 9;
			this.button4.Text = "     GENERATE";
			this.button4.UseVisualStyleBackColor = false;
			this.button4.Click += new global::System.EventHandler(this.button4_Click);
			this.pictureBox1.BackColor = global::System.Drawing.Color.Transparent;
			this.pictureBox1.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.Image");
			this.pictureBox1.Location = new global::System.Drawing.Point(7, 134);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new global::System.Drawing.Size(368, 377);
			this.pictureBox1.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 10;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Click += new global::System.EventHandler(this.pictureBox1_Click);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("$this.BackgroundImage");
			this.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			base.ClientSize = new global::System.Drawing.Size(381, 510);
			base.Controls.Add(this.pictureBox1);
			base.Controls.Add(this.button4);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.textBox1);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.Name = "A14_qr";
			this.Text = "Android 14 QR";
			base.Load += new global::System.EventHandler(this.A14_qr_Load);
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000074 RID: 116
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x04000075 RID: 117
		private global::System.Windows.Forms.TextBox textBox1;

		// Token: 0x04000076 RID: 118
		private global::System.Windows.Forms.Label label1;

		// Token: 0x04000077 RID: 119
		private global::System.Windows.Forms.Button button4;

		// Token: 0x04000078 RID: 120
		private global::System.Windows.Forms.PictureBox pictureBox1;
	}
}
