﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.CSharp.RuntimeBinder;
using Newtonsoft.Json;
using QRCoder;

namespace KG_Killer
{
	// Token: 0x02000018 RID: 24
	public partial class A14_QR_2 : Form
	{
		// Token: 0x06000093 RID: 147 RVA: 0x00007648 File Offset: 0x00005848
		public A14_QR_2()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000094 RID: 148 RVA: 0x00007668 File Offset: 0x00005868
		private async Task QrGenerate()
		{
			try
			{
				string serialNumber = this.textBox1.Text;
				if (!string.IsNullOrEmpty(serialNumber))
				{
					TaskAwaiter<string> taskAwaiter = this.GetEnrollmentIdFromPHP(serialNumber).GetAwaiter();
					if (!taskAwaiter.IsCompleted)
					{
						await taskAwaiter;
						TaskAwaiter<string> taskAwaiter2;
						taskAwaiter = taskAwaiter2;
						taskAwaiter2 = default(TaskAwaiter<string>);
					}
					string text = taskAwaiter.GetResult();
					string enrollmentId = text;
					text = null;
					if (!string.IsNullOrEmpty(enrollmentId))
					{
						string Enrolment = enrollmentId;
						Dictionary<string, object> provisioningData = new Dictionary<string, object>
						{
							{
								"android.app.extra.PROVISIONING_ADMIN_EXTRAS_BUNDLE",
								new Dictionary<string, object> { { "enrollmentId", Enrolment } }
							},
							{ "android.app.extra.PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME", "com.guard.mdm/.Citipati" },
							{ "android.app.extra.PROVISIONING_DEVICE_ADMIN_PACKAGE_CHECKSUM", "WcRnQAvdAwPxaFMtDqKMp6oWbXAw6z8X9nFZWceMTw4=" },
							{ "android.app.extra.PROVISIONING_DEVICE_ADMIN_PACKAGE_DOWNLOAD_LOCATION", "https://kgkiller.com/download/app-testing.apk" },
							{ "android.app.extra.PROVISIONING_LEAVE_ALL_SYSTEM_APPS_ENABLED", true },
							{ "android.app.extra.PROVISIONING_SKIP_ENCRYPTION", true }
						};
						string json_data = JsonConvert.SerializeObject(provisioningData);
						QRCodeGenerator qrCoderQrGenerator = new QRCodeGenerator();
						QRCodeData qrCodeData = qrCoderQrGenerator.CreateQrCode(json_data, QRCodeGenerator.ECCLevel.L, false, false, QRCodeGenerator.EciMode.Default, -1);
						QRCode qrCode = new QRCode(qrCodeData);
						Bitmap qrImage = qrCode.GetGraphic(20);
						Bitmap finalImage = new Bitmap(423, 470);
						using (Graphics g = Graphics.FromImage(finalImage))
						{
							g.Clear(Color.White);
							int topOffset = 40;
							g.DrawImage(qrImage, new Rectangle(0, topOffset, 423, 423));
						}
						Graphics g = null;
						this.pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
						this.pictureBox1.Image = finalImage;
						serialNumber = null;
						enrollmentId = null;
						Enrolment = null;
						provisioningData = null;
						json_data = null;
						qrCoderQrGenerator = null;
						qrCodeData = null;
						qrCode = null;
						qrImage = null;
						finalImage = null;
					}
					else
					{
						MessageBox.Show("Failed to get Enrollment ID from server.");
					}
				}
				else
				{
					MessageBox.Show("Please enter the serial number.");
				}
			}
			catch (JsonReaderException ex)
			{
				MessageBox.Show("JSON Parsing Error: " + ex.Message);
				Console.WriteLine("JSON Parsing Error: " + ex.Message);
			}
			catch (Exception ex2)
			{
				MessageBox.Show("Error: " + ex2.Message);
				Console.WriteLine("Error: " + ex2.Message);
			}
		}

		// Token: 0x06000095 RID: 149 RVA: 0x000076AC File Offset: 0x000058AC
		private async Task<string> GetEnrollmentIdFromPHP(string serialNumber)
		{
			string text2;
			try
			{
				using (HttpClient client = new HttpClient())
				{
					Dictionary<string, string> values = new Dictionary<string, string> { { "serialNumber", serialNumber } };
					FormUrlEncodedContent content = new FormUrlEncodedContent(values);
					HttpResponseMessage httpResponseMessage = await client.PostAsync("https://kgkiller.com/server/qr/samqr_id.php", content);
					HttpResponseMessage response = httpResponseMessage;
					httpResponseMessage = null;
					TaskAwaiter<string> taskAwaiter = response.Content.ReadAsStringAsync().GetAwaiter();
					if (!taskAwaiter.IsCompleted)
					{
						await taskAwaiter;
						TaskAwaiter<string> taskAwaiter2;
						taskAwaiter = taskAwaiter2;
						taskAwaiter2 = default(TaskAwaiter<string>);
					}
					string text = taskAwaiter.GetResult();
					string responseString = text;
					text = null;
					object jsonResponse = JsonConvert.DeserializeObject(responseString);
					if (A14_QR_2.<>o__2.<>p__1 == null)
					{
						A14_QR_2.<>o__2.<>p__1 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof(string), typeof(A14_QR_2)));
					}
					Func<CallSite, object, string> target = A14_QR_2.<>o__2.<>p__1.Target;
					CallSite <>p__ = A14_QR_2.<>o__2.<>p__1;
					if (A14_QR_2.<>o__2.<>p__0 == null)
					{
						A14_QR_2.<>o__2.<>p__0 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "enrollmentId", typeof(A14_QR_2), new CSharpArgumentInfo[] { CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null) }));
					}
					text2 = target(<>p__, A14_QR_2.<>o__2.<>p__0.Target(A14_QR_2.<>o__2.<>p__0, jsonResponse));
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Failed to fetch enrollment ID: " + ex.Message);
				text2 = null;
			}
			return text2;
		}

		// Token: 0x06000096 RID: 150 RVA: 0x000076F8 File Offset: 0x000058F8
		private void button4_Click(object sender, EventArgs e)
		{
			this.QrGenerate();
		}
	}
}
