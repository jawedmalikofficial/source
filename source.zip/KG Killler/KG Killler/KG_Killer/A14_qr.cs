﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.CSharp.RuntimeBinder;
using Newtonsoft.Json;
using QRCoder;

namespace KG_Killer
{
	// Token: 0x0200001C RID: 28
	public partial class A14_qr : Form
	{
		// Token: 0x0600009F RID: 159 RVA: 0x000081A8 File Offset: 0x000063A8
		public A14_qr()
		{
			this.InitializeComponent();
		}

		// Token: 0x060000A0 RID: 160 RVA: 0x000081C8 File Offset: 0x000063C8
		private async Task QrGenerate()
		{
			try
			{
				string serialNumber = this.textBox1.Text;
				if (string.IsNullOrEmpty(serialNumber))
				{
					MessageBox.Show("Please enter the serial number.");
				}
				else
				{
					string text = await this.GetEnrollmentIdFromPHP(serialNumber);
					string enrollmentId = text;
					text = null;
					if (string.IsNullOrEmpty(enrollmentId))
					{
						MessageBox.Show("Failed to get Enrollment ID from server.");
					}
					else
					{
						string Enrolment = enrollmentId;
						Dictionary<string, object> provisioningData = new Dictionary<string, object>
						{
							{
								"android.app.extra.PROVISIONING_ADMIN_EXTRAS_BUNDLE",
								new Dictionary<string, object> { { "enrollmentId", Enrolment } }
							},
							{ "android.app.extra.PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME", "com.mdmfixtool.mdmfixtool/.DeviceAdmin" },
							{ "android.app.extra.PROVISIONING_DEVICE_ADMIN_PACKAGE_CHECKSUM", "4crcNtnabLEBzKQ5HrnsDteTZUA5aXCvAxGnI58lNlY=" },
							{ "android.app.extra.PROVISIONING_DEVICE_ADMIN_PACKAGE_DOWNLOAD_LOCATION", "https://kgkiller.com/download/app-release.apk" },
							{ "android.app.extra.PROVISIONING_LEAVE_ALL_SYSTEM_APPS_ENABLED", true },
							{ "android.app.extra.PROVISIONING_SKIP_ENCRYPTION", true }
						};
						string json_data = JsonConvert.SerializeObject(provisioningData);
						QRCodeGenerator qrCoderQrGenerator = new QRCodeGenerator();
						QRCodeData qrCodeData = qrCoderQrGenerator.CreateQrCode(json_data, QRCodeGenerator.ECCLevel.L, false, false, QRCodeGenerator.EciMode.Default, -1);
						QRCode qrCode = new QRCode(qrCodeData);
						Bitmap qrImage = qrCode.GetGraphic(20);
						Bitmap finalImage = new Bitmap(423, 470);
						using (Graphics g = Graphics.FromImage(finalImage))
						{
							g.Clear(Color.White);
							int topOffset = 40;
							g.DrawImage(qrImage, new Rectangle(0, topOffset, 423, 423));
						}
						Graphics g = null;
						this.pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
						this.pictureBox1.Image = finalImage;
						serialNumber = null;
						enrollmentId = null;
						Enrolment = null;
						provisioningData = null;
						json_data = null;
						qrCoderQrGenerator = null;
						qrCodeData = null;
						qrCode = null;
						qrImage = null;
						finalImage = null;
					}
				}
			}
			catch (JsonReaderException ex)
			{
				MessageBox.Show("JSON Parsing Error: " + ex.Message);
				Console.WriteLine("JSON Parsing Error: " + ex.Message);
			}
			catch (Exception ex2)
			{
				MessageBox.Show("Error: " + ex2.Message);
				Console.WriteLine("Error: " + ex2.Message);
			}
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x0000820C File Offset: 0x0000640C
		private async Task<string> GetEnrollmentIdFromPHP(string serialNumber)
		{
			string text2;
			try
			{
				using (HttpClient client = new HttpClient())
				{
					Dictionary<string, string> values = new Dictionary<string, string> { { "serialNumber", serialNumber } };
					FormUrlEncodedContent content = new FormUrlEncodedContent(values);
					TaskAwaiter<HttpResponseMessage> taskAwaiter = client.PostAsync("https://kgkiller.com/server/qr/samqr_id.php", content).GetAwaiter();
					if (!taskAwaiter.IsCompleted)
					{
						await taskAwaiter;
						TaskAwaiter<HttpResponseMessage> taskAwaiter2;
						taskAwaiter = taskAwaiter2;
						taskAwaiter2 = default(TaskAwaiter<HttpResponseMessage>);
					}
					HttpResponseMessage httpResponseMessage = taskAwaiter.GetResult();
					HttpResponseMessage response = httpResponseMessage;
					httpResponseMessage = null;
					TaskAwaiter<string> taskAwaiter3 = response.Content.ReadAsStringAsync().GetAwaiter();
					if (!taskAwaiter3.IsCompleted)
					{
						await taskAwaiter3;
						TaskAwaiter<string> taskAwaiter4;
						taskAwaiter3 = taskAwaiter4;
						taskAwaiter4 = default(TaskAwaiter<string>);
					}
					string text = taskAwaiter3.GetResult();
					string responseString = text;
					text = null;
					object jsonResponse = JsonConvert.DeserializeObject(responseString);
					if (A14_qr.<>o__2.<>p__1 == null)
					{
						A14_qr.<>o__2.<>p__1 = CallSite<Func<CallSite, object, string>>.Create(Binder.Convert(CSharpBinderFlags.None, typeof(string), typeof(A14_qr)));
					}
					Func<CallSite, object, string> target = A14_qr.<>o__2.<>p__1.Target;
					CallSite <>p__ = A14_qr.<>o__2.<>p__1;
					if (A14_qr.<>o__2.<>p__0 == null)
					{
						A14_qr.<>o__2.<>p__0 = CallSite<Func<CallSite, object, object>>.Create(Binder.GetMember(CSharpBinderFlags.None, "enrollmentId", typeof(A14_qr), new CSharpArgumentInfo[] { CSharpArgumentInfo.Create(CSharpArgumentInfoFlags.None, null) }));
					}
					text2 = target(<>p__, A14_qr.<>o__2.<>p__0.Target(A14_qr.<>o__2.<>p__0, jsonResponse));
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Failed to fetch enrollment ID: " + ex.Message);
				text2 = null;
			}
			return text2;
		}

		// Token: 0x060000A2 RID: 162 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void button1_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x060000A3 RID: 163 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void textBox1_TextChanged(object sender, EventArgs e)
		{
		}

		// Token: 0x060000A4 RID: 164 RVA: 0x00008258 File Offset: 0x00006458
		private void button4_Click(object sender, EventArgs e)
		{
			this.QrGenerate();
		}

		// Token: 0x060000A5 RID: 165 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void A14_qr_Load(object sender, EventArgs e)
		{
		}

		// Token: 0x060000A6 RID: 166 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void pictureBox1_Click(object sender, EventArgs e)
		{
		}
	}
}
