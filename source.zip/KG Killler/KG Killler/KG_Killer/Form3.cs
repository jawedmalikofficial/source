﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Management;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using KG_Killer.Properties;

namespace KG_Killer
{
	// Token: 0x02000068 RID: 104
	public partial class Form3 : Form
	{
		// Token: 0x06000218 RID: 536 RVA: 0x0002431C File Offset: 0x0002251C
		public Form3()
		{
			this.InitializeComponent();
			string text = this.txtUsername.Text;
			string text2 = this.txtPassword.Text;
			this.GenerateHWID();
		}

		// Token: 0x06000219 RID: 537 RVA: 0x0002435C File Offset: 0x0002255C
		private void Form3_Load(object sender, EventArgs e)
		{
			this.lblErrorMessage.Visible = false;
			this.lblSuccessMessage.Visible = false;
			this.lblBannedMessage.Visible = false;
			this.lblNotActivatedMessage.Visible = false;
			this.lblInvalidPasswordMessage.Visible = false;
			this.lblHWIDMismatchMessage.Visible = false;
			this.label2.Visible = false;
			if (Settings.Default.RememberMe)
			{
				this.txtUsername.Text = Settings.Default.Username;
				this.txtPassword.Text = Settings.Default.Password;
				this.chkRememberMe.Checked = true;
			}
		}

		// Token: 0x0600021A RID: 538 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void pictureBox1_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x0600021B RID: 539 RVA: 0x0000A5C4 File Offset: 0x000087C4
		private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = "https://kgkiller.com/",
				UseShellExecute = true
			});
		}

		// Token: 0x0600021C RID: 540 RVA: 0x0000A35C File Offset: 0x0000855C
		private void pictureBox6_Click(object sender, EventArgs e)
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = "https://t.me/+T2mPs1x8T6hhNmU9",
				UseShellExecute = true
			});
		}

		// Token: 0x0600021D RID: 541 RVA: 0x00024400 File Offset: 0x00022600
		private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = "https://user.kgkiller.com/password/reset",
				UseShellExecute = true
			});
		}

		// Token: 0x0600021E RID: 542 RVA: 0x0002442C File Offset: 0x0002262C
		private void LogUsernameText_Enter(object sender, EventArgs e)
		{
			if (this.txtUsername.Text == "Username")
			{
				this.txtUsername.Text = "";
				this.txtUsername.ForeColor = Color.Black;
			}
		}

		// Token: 0x0600021F RID: 543 RVA: 0x00024470 File Offset: 0x00022670
		private void LogUsernameText_Leave(object sender, EventArgs e)
		{
			if (this.txtUsername.Text == "")
			{
				this.txtUsername.Text = "Username";
				this.txtUsername.ForeColor = Color.FromArgb(130, 130, 130);
			}
		}

		// Token: 0x06000220 RID: 544 RVA: 0x000244C4 File Offset: 0x000226C4
		private void Form3_FormClosing(object sender, FormClosingEventArgs e)
		{
			Application.Exit();
		}

		// Token: 0x06000221 RID: 545 RVA: 0x000244D8 File Offset: 0x000226D8
		private async void button1_Click(object sender, EventArgs e)
		{
			Form3.usrname = this.txtUsername.Text;
			this.button1.Enabled = false;
			this.GenerateHWID();
			string text = this.txtUsername.Text;
			string text2 = this.txtPassword.Text;
			if (text.Equals("") && text2.Equals("8685855531"))
			{
				MessageBox.Show("Login Successful", "Success", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				new KGKiller().Show();
				base.Hide();
			}
			else
			{
				MessageBox.Show("Please Enter Username and Password", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
		}

		// Token: 0x06000222 RID: 546 RVA: 0x00024510 File Offset: 0x00022710
		private string GenerateHWID()
		{
			string text = string.Empty;
			try
			{
				string biosserialNumber = this.GetBIOSSerialNumber();
				string processorID = this.GetProcessorID();
				string hardDriveSerialNumber = this.GetHardDriveSerialNumber();
				string biosproduct = this.GetBIOSproduct();
				string text2 = biosserialNumber + processorID + hardDriveSerialNumber + biosproduct;
				if (string.IsNullOrEmpty(text2))
				{
					text = "HWID not found.";
				}
				else
				{
					text = this.GenerateMD5Hash(text2);
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("An error occurred while generating the HWID: " + ex.Message);
			}
			return text;
		}

		// Token: 0x06000223 RID: 547 RVA: 0x0000AA68 File Offset: 0x00008C68
		private string GetBIOSSerialNumber()
		{
			string text = string.Empty;
			try
			{
				ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_BaseBoard");
				using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						ManagementObject managementObject = (ManagementObject)enumerator.Current;
						text = managementObject["SerialNumber"].ToString();
					}
				}
			}
			catch
			{
				text = string.Empty;
			}
			return text;
		}

		// Token: 0x06000224 RID: 548 RVA: 0x0000AAF0 File Offset: 0x00008CF0
		private string GetBIOSproduct()
		{
			string text = string.Empty;
			try
			{
				ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_BaseBoard");
				using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						ManagementObject managementObject = (ManagementObject)enumerator.Current;
						text = managementObject["Product"].ToString();
					}
				}
			}
			catch
			{
				text = string.Empty;
			}
			return text;
		}

		// Token: 0x06000225 RID: 549 RVA: 0x0000AB78 File Offset: 0x00008D78
		private string GetProcessorID()
		{
			string text = string.Empty;
			try
			{
				ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_Processor");
				using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						ManagementObject managementObject = (ManagementObject)enumerator.Current;
						text = managementObject["ProcessorId"].ToString();
					}
				}
			}
			catch
			{
				text = string.Empty;
			}
			return text;
		}

		// Token: 0x06000226 RID: 550 RVA: 0x0000AC00 File Offset: 0x00008E00
		private string GetHardDriveSerialNumber()
		{
			string text = string.Empty;
			try
			{
				ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMedia");
				using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						ManagementObject managementObject = (ManagementObject)enumerator.Current;
						text = managementObject["SerialNumber"].ToString();
					}
				}
			}
			catch
			{
				text = string.Empty;
			}
			return text;
		}

		// Token: 0x06000227 RID: 551 RVA: 0x0000AC88 File Offset: 0x00008E88
		private string GenerateMD5Hash(string input)
		{
			string text;
			using (MD5 md = MD5.Create())
			{
				byte[] array = md.ComputeHash(Encoding.UTF8.GetBytes(input));
				StringBuilder stringBuilder = new StringBuilder();
				foreach (byte b in array)
				{
					stringBuilder.Append(b.ToString("x2"));
				}
				text = stringBuilder.ToString();
			}
			return text;
		}

		// Token: 0x06000228 RID: 552 RVA: 0x000244C4 File Offset: 0x000226C4
		private void button3_Click(object sender, EventArgs e)
		{
			Application.Exit();
		}

		// Token: 0x06000229 RID: 553 RVA: 0x00024598 File Offset: 0x00022798
		private void button2_Click(object sender, EventArgs e)
		{
			base.WindowState = FormWindowState.Minimized;
		}

		// Token: 0x04000394 RID: 916
		private static readonly HttpClient client = new HttpClient();

		// Token: 0x04000395 RID: 917
		public static string usrname;
	}
}
