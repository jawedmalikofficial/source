﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace KG_Killer
{
	// Token: 0x02000020 RID: 32
	internal class Adb
	{
		// Token: 0x060000AF RID: 175 RVA: 0x00008D38 File Offset: 0x00006F38
		public static string AdbCommand(string cmd)
		{
			Process process = new Process();
			ProcessStartInfo processStartInfo = new ProcessStartInfo
			{
				UseShellExecute = false,
				CreateNoWindow = true,
				FileName = "data/adb.exe",
				Arguments = cmd,
				RedirectStandardOutput = true
			};
			process.StartInfo = processStartInfo;
			process.Start();
			return process.StandardOutput.ReadToEnd();
		}

		// Token: 0x060000B0 RID: 176 RVA: 0x00008D94 File Offset: 0x00006F94
		public static async Task<string> AdbCommandAsync(string cmd)
		{
			return await Task.Run<string>(() => Adb.AdbCommand(cmd));
		}

		// Token: 0x060000B1 RID: 177 RVA: 0x00008DD8 File Offset: 0x00006FD8
		public static bool Adbfound()
		{
			return Adb.AdbCommand("get-state").Contains("device");
		}

		// Token: 0x060000B2 RID: 178 RVA: 0x00008DFC File Offset: 0x00006FFC
		public static string Shell(string args)
		{
			Process process = new Process
			{
				StartInfo = 
				{
					CreateNoWindow = true,
					FileName = "data\\adb.exe",
					Arguments = args,
					UseShellExecute = false,
					RedirectStandardOutput = true
				}
			};
			process.Start();
			string text = string.Empty;
			while (!process.HasExited)
			{
				text = process.StandardOutput.ReadToEnd();
			}
			return text.Trim();
		}

		// Token: 0x060000B3 RID: 179 RVA: 0x00008E80 File Offset: 0x00007080
		public static async Task<string> AdbCommandAsync2(string cmd)
		{
			return await Task.Run<string>(() => Adb.Shell(cmd));
		}

		// Token: 0x060000B4 RID: 180 RVA: 0x00008EC4 File Offset: 0x000070C4
		public static async void StartScrcpy()
		{
			if (Adb.Adbfound())
			{
				string scrcpyPath = "data\\scrcpy";
				string deviceSerialNumber = Adb.GetDeviceSerialNumber();
				if (deviceSerialNumber == null)
				{
					Console.WriteLine("No connected Android device found.");
				}
				else
				{
					Adb.<>c__DisplayClass5_0 CS$<>8__locals1 = new Adb.<>c__DisplayClass5_0();
					string scrcpyCommand = scrcpyPath + " -s " + deviceSerialNumber;
					CS$<>8__locals1.scrcpyProcess = new Process
					{
						StartInfo = new ProcessStartInfo
						{
							CreateNoWindow = true,
							FileName = "cmd.exe",
							RedirectStandardInput = true,
							RedirectStandardOutput = true,
							UseShellExecute = false,
							Arguments = "/c " + scrcpyCommand
						}
					};
					CS$<>8__locals1.scrcpyProcess.Start();
					TaskAwaiter taskAwaiter = Task.Run(delegate
					{
						CS$<>8__locals1.scrcpyProcess.WaitForExit();
					}).GetAwaiter();
					if (!taskAwaiter.IsCompleted)
					{
						await taskAwaiter;
						TaskAwaiter taskAwaiter2;
						taskAwaiter = taskAwaiter2;
						taskAwaiter2 = default(TaskAwaiter);
					}
					taskAwaiter.GetResult();
					CS$<>8__locals1.scrcpyProcess.Close();
					CS$<>8__locals1 = null;
					scrcpyCommand = null;
				}
				scrcpyPath = null;
				deviceSerialNumber = null;
			}
			else
			{
				Console.WriteLine("ADB not found or no connected device.");
			}
		}

		// Token: 0x060000B5 RID: 181 RVA: 0x00008EF8 File Offset: 0x000070F8
		private static string GetDeviceSerialNumber()
		{
			string text = Adb.Shell("devices").Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries).Skip(1)
				.FirstOrDefault<string>();
			return (text != null) ? text.Split(new char[] { '\t' }).FirstOrDefault<string>() : null;
		}
	}
}
