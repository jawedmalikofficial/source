﻿namespace KG_Killer
{
	// Token: 0x02000027 RID: 39
	public partial class KGKiller : global::System.Windows.Forms.Form
	{
		// Token: 0x06000133 RID: 307 RVA: 0x0000B284 File Offset: 0x00009484
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x06000134 RID: 308 RVA: 0x0000B2B4 File Offset: 0x000094B4
		private void InitializeComponent()
		{
			this.components = new global::System.ComponentModel.Container();
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::KG_Killer.KGKiller));
			this.panel3 = new global::System.Windows.Forms.Panel();
			this.button29 = new global::System.Windows.Forms.Button();
			this.pictureBox3 = new global::System.Windows.Forms.PictureBox();
			this.pictureBox1 = new global::System.Windows.Forms.PictureBox();
			this.Adb_Devices = new global::System.Windows.Forms.ComboBox();
			this.label1 = new global::System.Windows.Forms.Label();
			this.panel1 = new global::System.Windows.Forms.Panel();
			this.panel5 = new global::System.Windows.Forms.Panel();
			this.lblDate = new global::System.Windows.Forms.Label();
			this.pictureBox4 = new global::System.Windows.Forms.PictureBox();
			this.label5 = new global::System.Windows.Forms.Label();
			this.pictureBox6 = new global::System.Windows.Forms.PictureBox();
			this.pictureBox5 = new global::System.Windows.Forms.PictureBox();
			this.label3 = new global::System.Windows.Forms.Label();
			this.tabControl1 = new global::System.Windows.Forms.TabControl();
			this.tabPage1 = new global::System.Windows.Forms.TabPage();
			this.button40 = new global::System.Windows.Forms.Button();
			this.button37 = new global::System.Windows.Forms.Button();
			this.button32 = new global::System.Windows.Forms.Button();
			this.button26 = new global::System.Windows.Forms.Button();
			this.button12 = new global::System.Windows.Forms.Button();
			this.button9 = new global::System.Windows.Forms.Button();
			this.button17 = new global::System.Windows.Forms.Button();
			this.button5 = new global::System.Windows.Forms.Button();
			this.button2 = new global::System.Windows.Forms.Button();
			this.button1 = new global::System.Windows.Forms.Button();
			this.MtpBtn = new global::System.Windows.Forms.Button();
			this.LiveScrnBtn = new global::System.Windows.Forms.Button();
			this.KgBtn = new global::System.Windows.Forms.Button();
			this.tabPage2 = new global::System.Windows.Forms.TabPage();
			this.button20 = new global::System.Windows.Forms.Button();
			this.checkBox12 = new global::System.Windows.Forms.CheckBox();
			this.checkBox10 = new global::System.Windows.Forms.CheckBox();
			this.checkBox9 = new global::System.Windows.Forms.CheckBox();
			this.checkBox8 = new global::System.Windows.Forms.CheckBox();
			this.checkBox7 = new global::System.Windows.Forms.CheckBox();
			this.checkBox6 = new global::System.Windows.Forms.CheckBox();
			this.checkBox5 = new global::System.Windows.Forms.CheckBox();
			this.checkBox4 = new global::System.Windows.Forms.CheckBox();
			this.label2 = new global::System.Windows.Forms.Label();
			this.comboBox1 = new global::System.Windows.Forms.ComboBox();
			this.DataView = new global::System.Windows.Forms.DataGridView();
			this.dataGridViewCheckBoxColumn1 = new global::System.Windows.Forms.DataGridViewCheckBoxColumn();
			this.dataGridViewTextBoxColumn1 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn3 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn4 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn5 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn6 = new global::System.Windows.Forms.DataGridViewTextBoxColumn();
			this.tabPage4 = new global::System.Windows.Forms.TabPage();
			this.button38 = new global::System.Windows.Forms.Button();
			this.button36 = new global::System.Windows.Forms.Button();
			this.button35 = new global::System.Windows.Forms.Button();
			this.button30 = new global::System.Windows.Forms.Button();
			this.button24 = new global::System.Windows.Forms.Button();
			this.button22 = new global::System.Windows.Forms.Button();
			this.button18 = new global::System.Windows.Forms.Button();
			this.button14 = new global::System.Windows.Forms.Button();
			this.button15 = new global::System.Windows.Forms.Button();
			this.button16 = new global::System.Windows.Forms.Button();
			this.button13 = new global::System.Windows.Forms.Button();
			this.tabPage5 = new global::System.Windows.Forms.TabPage();
			this.button44 = new global::System.Windows.Forms.Button();
			this.button43 = new global::System.Windows.Forms.Button();
			this.button42 = new global::System.Windows.Forms.Button();
			this.button41 = new global::System.Windows.Forms.Button();
			this.button39 = new global::System.Windows.Forms.Button();
			this.button34 = new global::System.Windows.Forms.Button();
			this.button11 = new global::System.Windows.Forms.Button();
			this.button31 = new global::System.Windows.Forms.Button();
			this.button23 = new global::System.Windows.Forms.Button();
			this.button7 = new global::System.Windows.Forms.Button();
			this.button6 = new global::System.Windows.Forms.Button();
			this.button10 = new global::System.Windows.Forms.Button();
			this.ItAdminBtn = new global::System.Windows.Forms.Button();
			this.tabPage6 = new global::System.Windows.Forms.TabPage();
			this.button25 = new global::System.Windows.Forms.Button();
			this.button21 = new global::System.Windows.Forms.Button();
			this.button19 = new global::System.Windows.Forms.Button();
			this.tabPage3 = new global::System.Windows.Forms.TabPage();
			this.button33 = new global::System.Windows.Forms.Button();
			this.button28 = new global::System.Windows.Forms.Button();
			this.button3 = new global::System.Windows.Forms.Button();
			this.button27 = new global::System.Windows.Forms.Button();
			this.button4 = new global::System.Windows.Forms.Button();
			this.tabPage7 = new global::System.Windows.Forms.TabPage();
			this.pictureBox8 = new global::System.Windows.Forms.PictureBox();
			this.panel2 = new global::System.Windows.Forms.Panel();
			this.panel4 = new global::System.Windows.Forms.Panel();
			this.lblCredits = new global::System.Windows.Forms.Label();
			this.pictureBox7 = new global::System.Windows.Forms.PictureBox();
			this.lblExpiryDate = new global::System.Windows.Forms.Label();
			this.pictureBox2 = new global::System.Windows.Forms.PictureBox();
			this.button8 = new global::System.Windows.Forms.Button();
			this.progressBar1 = new global::System.Windows.Forms.ProgressBar();
			this.ResultTxt = new global::System.Windows.Forms.RichTextBox();
			this.timer1 = new global::System.Windows.Forms.Timer(this.components);
			this.panel3.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).BeginInit();
			this.panel1.SuspendLayout();
			this.panel5.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox4).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox6).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox5).BeginInit();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage2.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.DataView).BeginInit();
			this.tabPage4.SuspendLayout();
			this.tabPage5.SuspendLayout();
			this.tabPage6.SuspendLayout();
			this.tabPage3.SuspendLayout();
			this.tabPage7.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox8).BeginInit();
			this.panel2.SuspendLayout();
			this.panel4.SuspendLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox7).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox2).BeginInit();
			base.SuspendLayout();
			this.panel3.BackColor = global::System.Drawing.Color.Gainsboro;
			this.panel3.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("panel3.BackgroundImage");
			this.panel3.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.panel3.Controls.Add(this.button29);
			this.panel3.Controls.Add(this.pictureBox3);
			this.panel3.Controls.Add(this.pictureBox1);
			this.panel3.Controls.Add(this.Adb_Devices);
			this.panel3.Controls.Add(this.label1);
			this.panel3.Dock = global::System.Windows.Forms.DockStyle.Top;
			this.panel3.Location = new global::System.Drawing.Point(0, 0);
			this.panel3.Name = "panel3";
			this.panel3.Size = new global::System.Drawing.Size(891, 35);
			this.panel3.TabIndex = 1;
			this.button29.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button29.Image");
			this.button29.Location = new global::System.Drawing.Point(865, 10);
			this.button29.Name = "button29";
			this.button29.Size = new global::System.Drawing.Size(23, 23);
			this.button29.TabIndex = 8;
			this.button29.UseVisualStyleBackColor = true;
			this.button29.Click += new global::System.EventHandler(this.button29_Click);
			this.pictureBox3.BackColor = global::System.Drawing.Color.Transparent;
			this.pictureBox3.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox3.Image");
			this.pictureBox3.Location = new global::System.Drawing.Point(457, 3);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new global::System.Drawing.Size(28, 32);
			this.pictureBox3.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox3.TabIndex = 7;
			this.pictureBox3.TabStop = false;
			this.pictureBox3.Click += new global::System.EventHandler(this.pictureBox3_Click);
			this.pictureBox1.BackColor = global::System.Drawing.Color.Transparent;
			this.pictureBox1.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.Image");
			this.pictureBox1.Location = new global::System.Drawing.Point(3, 0);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new global::System.Drawing.Size(35, 35);
			this.pictureBox1.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 5;
			this.pictureBox1.TabStop = false;
			this.Adb_Devices.BackColor = global::System.Drawing.SystemColors.InactiveCaption;
			this.Adb_Devices.Font = new global::System.Drawing.Font("Bahnschrift", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.Adb_Devices.ForeColor = global::System.Drawing.SystemColors.ActiveCaptionText;
			this.Adb_Devices.FormattingEnabled = true;
			this.Adb_Devices.Location = new global::System.Drawing.Point(563, 12);
			this.Adb_Devices.Name = "Adb_Devices";
			this.Adb_Devices.Size = new global::System.Drawing.Size(300, 21);
			this.Adb_Devices.TabIndex = 2;
			this.Adb_Devices.DropDown += new global::System.EventHandler(this.Adb_Devices_DropDown);
			this.Adb_Devices.SelectedIndexChanged += new global::System.EventHandler(this.Adb_Devices_SelectedIndexChanged);
			this.label1.AutoSize = true;
			this.label1.BackColor = global::System.Drawing.Color.Transparent;
			this.label1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label1.ForeColor = global::System.Drawing.Color.Azure;
			this.label1.Location = new global::System.Drawing.Point(491, 15);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(84, 13);
			this.label1.TabIndex = 1;
			this.label1.Text = "USB/PORT : ";
			this.label1.Click += new global::System.EventHandler(this.label1_Click);
			this.panel1.Controls.Add(this.panel5);
			this.panel1.Controls.Add(this.tabControl1);
			this.panel1.Dock = global::System.Windows.Forms.DockStyle.Left;
			this.panel1.Location = new global::System.Drawing.Point(0, 35);
			this.panel1.Name = "panel1";
			this.panel1.Size = new global::System.Drawing.Size(567, 490);
			this.panel1.TabIndex = 1;
			this.panel1.Paint += new global::System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
			this.panel5.BackColor = global::System.Drawing.SystemColors.GradientActiveCaption;
			this.panel5.Controls.Add(this.lblDate);
			this.panel5.Controls.Add(this.pictureBox4);
			this.panel5.Controls.Add(this.label5);
			this.panel5.Controls.Add(this.pictureBox6);
			this.panel5.Controls.Add(this.pictureBox5);
			this.panel5.Controls.Add(this.label3);
			this.panel5.Location = new global::System.Drawing.Point(0, 459);
			this.panel5.Name = "panel5";
			this.panel5.Size = new global::System.Drawing.Size(563, 30);
			this.panel5.TabIndex = 6;
			this.lblDate.AutoSize = true;
			this.lblDate.Font = new global::System.Drawing.Font("Roboto", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.lblDate.Location = new global::System.Drawing.Point(419, 11);
			this.lblDate.Name = "lblDate";
			this.lblDate.Size = new global::System.Drawing.Size(57, 15);
			this.lblDate.TabIndex = 10;
			this.lblDate.Text = "00:00:00";
			this.lblDate.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.pictureBox4.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox4.Image");
			this.pictureBox4.Location = new global::System.Drawing.Point(390, 4);
			this.pictureBox4.Name = "pictureBox4";
			this.pictureBox4.Size = new global::System.Drawing.Size(25, 25);
			this.pictureBox4.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox4.TabIndex = 9;
			this.pictureBox4.TabStop = false;
			this.label5.AutoSize = true;
			this.label5.Font = new global::System.Drawing.Font("Constantia", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label5.Location = new global::System.Drawing.Point(217, 11);
			this.label5.Name = "label5";
			this.label5.Size = new global::System.Drawing.Size(63, 15);
			this.label5.TabIndex = 7;
			this.label5.Text = "PC Name";
			this.pictureBox6.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox6.Image");
			this.pictureBox6.Location = new global::System.Drawing.Point(192, 4);
			this.pictureBox6.Name = "pictureBox6";
			this.pictureBox6.Size = new global::System.Drawing.Size(25, 25);
			this.pictureBox6.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox6.TabIndex = 6;
			this.pictureBox6.TabStop = false;
			this.pictureBox6.Click += new global::System.EventHandler(this.pictureBox6_Click);
			this.pictureBox5.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox5.Image");
			this.pictureBox5.Location = new global::System.Drawing.Point(3, 4);
			this.pictureBox5.Name = "pictureBox5";
			this.pictureBox5.Size = new global::System.Drawing.Size(25, 25);
			this.pictureBox5.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox5.TabIndex = 4;
			this.pictureBox5.TabStop = false;
			this.label3.AutoSize = true;
			this.label3.Font = new global::System.Drawing.Font("Constantia", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label3.Location = new global::System.Drawing.Point(25, 11);
			this.label3.Name = "label3";
			this.label3.Size = new global::System.Drawing.Size(70, 15);
			this.label3.TabIndex = 3;
			this.label3.Text = "Username";
			this.label3.Click += new global::System.EventHandler(this.label3_Click);
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Controls.Add(this.tabPage4);
			this.tabControl1.Controls.Add(this.tabPage5);
			this.tabControl1.Controls.Add(this.tabPage6);
			this.tabControl1.Controls.Add(this.tabPage3);
			this.tabControl1.Controls.Add(this.tabPage7);
			this.tabControl1.Font = new global::System.Drawing.Font("Bahnschrift SemiBold", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.tabControl1.Location = new global::System.Drawing.Point(0, 3);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new global::System.Drawing.Size(567, 457);
			this.tabControl1.TabIndex = 5;
			this.tabPage1.BackColor = global::System.Drawing.Color.LightSlateGray;
			this.tabPage1.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("tabPage1.BackgroundImage");
			this.tabPage1.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.tabPage1.Controls.Add(this.button40);
			this.tabPage1.Controls.Add(this.button37);
			this.tabPage1.Controls.Add(this.button32);
			this.tabPage1.Controls.Add(this.button26);
			this.tabPage1.Controls.Add(this.button12);
			this.tabPage1.Controls.Add(this.button9);
			this.tabPage1.Controls.Add(this.button17);
			this.tabPage1.Controls.Add(this.button5);
			this.tabPage1.Controls.Add(this.button2);
			this.tabPage1.Controls.Add(this.button1);
			this.tabPage1.Controls.Add(this.MtpBtn);
			this.tabPage1.Controls.Add(this.LiveScrnBtn);
			this.tabPage1.Controls.Add(this.KgBtn);
			this.tabPage1.Location = new global::System.Drawing.Point(4, 27);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new global::System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new global::System.Drawing.Size(559, 426);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "KG(ADB)";
			this.tabPage1.Click += new global::System.EventHandler(this.tabPage1_Click);
			this.button40.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button40.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button40.Enabled = false;
			this.button40.Font = new global::System.Drawing.Font("Bahnschrift Condensed", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button40.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button40.Image");
			this.button40.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button40.Location = new global::System.Drawing.Point(156, 364);
			this.button40.Name = "button40";
			this.button40.Size = new global::System.Drawing.Size(200, 42);
			this.button40.TabIndex = 16;
			this.button40.Text = "KG Android 14 Permanent     ";
			this.button40.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button40.UseVisualStyleBackColor = false;
			this.button37.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button37.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button37.Font = new global::System.Drawing.Font("Bahnschrift Condensed", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button37.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button37.Image");
			this.button37.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button37.Location = new global::System.Drawing.Point(33, 199);
			this.button37.Name = "button37";
			this.button37.Size = new global::System.Drawing.Size(200, 42);
			this.button37.TabIndex = 15;
			this.button37.Text = "KG Android 14 New Method 3";
			this.button37.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button37.UseVisualStyleBackColor = false;
			this.button37.Click += new global::System.EventHandler(this.button37_Click);
			this.button32.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button32.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button32.Font = new global::System.Drawing.Font("Bahnschrift Condensed", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button32.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button32.Image");
			this.button32.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button32.Location = new global::System.Drawing.Point(33, 141);
			this.button32.Name = "button32";
			this.button32.Size = new global::System.Drawing.Size(200, 42);
			this.button32.TabIndex = 14;
			this.button32.Text = "KG Android 14 New Method 2";
			this.button32.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button32.UseVisualStyleBackColor = false;
			this.button32.Click += new global::System.EventHandler(this.button32_Click);
			this.button26.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button26.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button26.Font = new global::System.Drawing.Font("Bahnschrift Condensed", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button26.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button26.Image");
			this.button26.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button26.Location = new global::System.Drawing.Point(33, 316);
			this.button26.Name = "button26";
			this.button26.Size = new global::System.Drawing.Size(200, 42);
			this.button26.TabIndex = 13;
			this.button26.Text = "Set To KG Active 01(IMEI)        ";
			this.button26.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button26.UseVisualStyleBackColor = false;
			this.button26.Click += new global::System.EventHandler(this.button26_Click);
			this.button12.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button12.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button12.Font = new global::System.Drawing.Font("Bahnschrift Condensed", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button12.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button12.Image");
			this.button12.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button12.Location = new global::System.Drawing.Point(292, 199);
			this.button12.Name = "button12";
			this.button12.Size = new global::System.Drawing.Size(200, 42);
			this.button12.TabIndex = 12;
			this.button12.Text = "KG Android 13 (New Patch)   ";
			this.button12.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button12.UseVisualStyleBackColor = false;
			this.button12.Click += new global::System.EventHandler(this.button12_Click_1);
			this.button9.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button9.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button9.Font = new global::System.Drawing.Font("Bahnschrift Condensed", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button9.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button9.Image");
			this.button9.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button9.Location = new global::System.Drawing.Point(33, 81);
			this.button9.Name = "button9";
			this.button9.Size = new global::System.Drawing.Size(200, 42);
			this.button9.TabIndex = 11;
			this.button9.Text = "KG Android 14 New Method 1";
			this.button9.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button9.UseVisualStyleBackColor = false;
			this.button9.Click += new global::System.EventHandler(this.button9_Click);
			this.button17.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button17.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button17.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button17.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button17.Image");
			this.button17.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button17.Location = new global::System.Drawing.Point(292, 23);
			this.button17.Name = "button17";
			this.button17.Size = new global::System.Drawing.Size(200, 42);
			this.button17.TabIndex = 10;
			this.button17.Text = "  KG Status Check";
			this.button17.UseVisualStyleBackColor = false;
			this.button17.Click += new global::System.EventHandler(this.button17_Click);
			this.button5.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button5.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button5.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button5.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button5.Image");
			this.button5.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button5.Location = new global::System.Drawing.Point(292, 141);
			this.button5.Name = "button5";
			this.button5.Size = new global::System.Drawing.Size(200, 42);
			this.button5.TabIndex = 9;
			this.button5.Text = "     Enable ADB (05-23)    ";
			this.button5.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button5.UseVisualStyleBackColor = false;
			this.button5.Click += new global::System.EventHandler(this.button5_Click);
			this.button2.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button2.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button2.Font = new global::System.Drawing.Font("Bahnschrift Condensed", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button2.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button2.Image");
			this.button2.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button2.Location = new global::System.Drawing.Point(33, 260);
			this.button2.Name = "button2";
			this.button2.Size = new global::System.Drawing.Size(200, 42);
			this.button2.TabIndex = 6;
			this.button2.Text = "    KG Android 14(All Patch)";
			this.button2.UseVisualStyleBackColor = false;
			this.button2.Click += new global::System.EventHandler(this.button2_Click);
			this.button1.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button1.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button1.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button1.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button1.Image");
			this.button1.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button1.Location = new global::System.Drawing.Point(292, 259);
			this.button1.Name = "button1";
			this.button1.Size = new global::System.Drawing.Size(200, 42);
			this.button1.TabIndex = 5;
			this.button1.Text = "KG Android 13 (03-24)   ";
			this.button1.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new global::System.EventHandler(this.button1_Click);
			this.MtpBtn.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.MtpBtn.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.MtpBtn.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.MtpBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("MtpBtn.Image");
			this.MtpBtn.ImageAlign = global::System.Drawing.ContentAlignment.TopLeft;
			this.MtpBtn.Location = new global::System.Drawing.Point(33, 24);
			this.MtpBtn.Name = "MtpBtn";
			this.MtpBtn.Size = new global::System.Drawing.Size(200, 42);
			this.MtpBtn.TabIndex = 0;
			this.MtpBtn.Text = "      MTP Read Info";
			this.MtpBtn.UseVisualStyleBackColor = false;
			this.MtpBtn.Click += new global::System.EventHandler(this.MtpBtn_Click);
			this.LiveScrnBtn.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.LiveScrnBtn.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.LiveScrnBtn.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.LiveScrnBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("LiveScrnBtn.Image");
			this.LiveScrnBtn.ImageAlign = global::System.Drawing.ContentAlignment.TopLeft;
			this.LiveScrnBtn.Location = new global::System.Drawing.Point(292, 81);
			this.LiveScrnBtn.Name = "LiveScrnBtn";
			this.LiveScrnBtn.Size = new global::System.Drawing.Size(200, 42);
			this.LiveScrnBtn.TabIndex = 1;
			this.LiveScrnBtn.Text = "   ADB Live Screen";
			this.LiveScrnBtn.UseVisualStyleBackColor = false;
			this.LiveScrnBtn.Click += new global::System.EventHandler(this.LiveScrnBtn_Click);
			this.KgBtn.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.KgBtn.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.KgBtn.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.KgBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("KgBtn.Image");
			this.KgBtn.ImageAlign = global::System.Drawing.ContentAlignment.TopLeft;
			this.KgBtn.Location = new global::System.Drawing.Point(292, 315);
			this.KgBtn.Name = "KgBtn";
			this.KgBtn.Size = new global::System.Drawing.Size(200, 42);
			this.KgBtn.TabIndex = 2;
			this.KgBtn.Text = "KG Android 13 (07-23)   ";
			this.KgBtn.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.KgBtn.UseVisualStyleBackColor = false;
			this.KgBtn.Click += new global::System.EventHandler(this.KgBtn_Click);
			this.tabPage2.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("tabPage2.BackgroundImage");
			this.tabPage2.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.tabPage2.Controls.Add(this.button20);
			this.tabPage2.Controls.Add(this.checkBox12);
			this.tabPage2.Controls.Add(this.checkBox10);
			this.tabPage2.Controls.Add(this.checkBox9);
			this.tabPage2.Controls.Add(this.checkBox8);
			this.tabPage2.Controls.Add(this.checkBox7);
			this.tabPage2.Controls.Add(this.checkBox6);
			this.tabPage2.Controls.Add(this.checkBox5);
			this.tabPage2.Controls.Add(this.checkBox4);
			this.tabPage2.Controls.Add(this.label2);
			this.tabPage2.Controls.Add(this.comboBox1);
			this.tabPage2.Controls.Add(this.DataView);
			this.tabPage2.Location = new global::System.Drawing.Point(4, 27);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new global::System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new global::System.Drawing.Size(559, 426);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "KG(EDL)";
			this.tabPage2.UseVisualStyleBackColor = true;
			this.tabPage2.Click += new global::System.EventHandler(this.tabPage2_Click);
			this.button20.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button20.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button20.Enabled = false;
			this.button20.Font = new global::System.Drawing.Font("Bahnschrift", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button20.ForeColor = global::System.Drawing.SystemColors.ActiveCaptionText;
			this.button20.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button20.Image");
			this.button20.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button20.Location = new global::System.Drawing.Point(364, 344);
			this.button20.Name = "button20";
			this.button20.Size = new global::System.Drawing.Size(117, 44);
			this.button20.TabIndex = 12;
			this.button20.Text = "    Perform";
			this.button20.UseVisualStyleBackColor = false;
			this.checkBox12.AutoSize = true;
			this.checkBox12.Enabled = false;
			this.checkBox12.Font = new global::System.Drawing.Font("Nirmala UI", 9f, global::System.Drawing.FontStyle.Bold);
			this.checkBox12.ForeColor = global::System.Drawing.SystemColors.ButtonFace;
			this.checkBox12.Location = new global::System.Drawing.Point(26, 389);
			this.checkBox12.Name = "checkBox12";
			this.checkBox12.Size = new global::System.Drawing.Size(168, 19);
			this.checkBox12.TabIndex = 11;
			this.checkBox12.Text = "MDM Can't Download FIX";
			this.checkBox12.UseVisualStyleBackColor = true;
			this.checkBox10.AutoSize = true;
			this.checkBox10.Enabled = false;
			this.checkBox10.Font = new global::System.Drawing.Font("Nirmala UI", 9f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.checkBox10.ForeColor = global::System.Drawing.SystemColors.ButtonFace;
			this.checkBox10.Location = new global::System.Drawing.Point(116, 328);
			this.checkBox10.Name = "checkBox10";
			this.checkBox10.Size = new global::System.Drawing.Size(62, 19);
			this.checkBox10.TabIndex = 9;
			this.checkBox10.Text = "Kill KG";
			this.checkBox10.UseVisualStyleBackColor = true;
			this.checkBox9.AutoSize = true;
			this.checkBox9.Enabled = false;
			this.checkBox9.Font = new global::System.Drawing.Font("Nirmala UI", 9f, global::System.Drawing.FontStyle.Bold);
			this.checkBox9.ForeColor = global::System.Drawing.SystemColors.ButtonFace;
			this.checkBox9.Location = new global::System.Drawing.Point(26, 359);
			this.checkBox9.Name = "checkBox9";
			this.checkBox9.Size = new global::System.Drawing.Size(123, 19);
			this.checkBox9.TabIndex = 8;
			this.checkBox9.Text = "Change Serial No.";
			this.checkBox9.UseVisualStyleBackColor = true;
			this.checkBox8.AutoSize = true;
			this.checkBox8.Enabled = false;
			this.checkBox8.Font = new global::System.Drawing.Font("Nirmala UI", 9f, global::System.Drawing.FontStyle.Bold);
			this.checkBox8.ForeColor = global::System.Drawing.SystemColors.ButtonFace;
			this.checkBox8.Location = new global::System.Drawing.Point(184, 328);
			this.checkBox8.Name = "checkBox8";
			this.checkBox8.Size = new global::System.Drawing.Size(79, 19);
			this.checkBox8.TabIndex = 7;
			this.checkBox8.Text = " IT Admin";
			this.checkBox8.UseVisualStyleBackColor = true;
			this.checkBox7.AutoSize = true;
			this.checkBox7.Enabled = false;
			this.checkBox7.Font = new global::System.Drawing.Font("Nirmala UI", 9f, global::System.Drawing.FontStyle.Bold);
			this.checkBox7.ForeColor = global::System.Drawing.SystemColors.ButtonFace;
			this.checkBox7.Location = new global::System.Drawing.Point(237, 359);
			this.checkBox7.Name = "checkBox7";
			this.checkBox7.Size = new global::System.Drawing.Size(69, 19);
			this.checkBox7.TabIndex = 6;
			this.checkBox7.Text = "BL Lock";
			this.checkBox7.UseVisualStyleBackColor = true;
			this.checkBox6.AutoSize = true;
			this.checkBox6.Enabled = false;
			this.checkBox6.Font = new global::System.Drawing.Font("Nirmala UI", 9f, global::System.Drawing.FontStyle.Bold);
			this.checkBox6.ForeColor = global::System.Drawing.SystemColors.ButtonFace;
			this.checkBox6.Location = new global::System.Drawing.Point(26, 328);
			this.checkBox6.Name = "checkBox6";
			this.checkBox6.Size = new global::System.Drawing.Size(84, 19);
			this.checkBox6.TabIndex = 5;
			this.checkBox6.Text = "KG Unload";
			this.checkBox6.UseVisualStyleBackColor = true;
			this.checkBox5.AutoSize = true;
			this.checkBox5.Enabled = false;
			this.checkBox5.Font = new global::System.Drawing.Font("Nirmala UI", 9f, global::System.Drawing.FontStyle.Bold);
			this.checkBox5.ForeColor = global::System.Drawing.SystemColors.ButtonFace;
			this.checkBox5.Location = new global::System.Drawing.Point(150, 359);
			this.checkBox5.Name = "checkBox5";
			this.checkBox5.Size = new global::System.Drawing.Size(82, 19);
			this.checkBox5.TabIndex = 4;
			this.checkBox5.Text = "BL Unlock";
			this.checkBox5.UseVisualStyleBackColor = true;
			this.checkBox4.AutoSize = true;
			this.checkBox4.Enabled = false;
			this.checkBox4.Font = new global::System.Drawing.Font("Nirmala UI", 9f, global::System.Drawing.FontStyle.Bold);
			this.checkBox4.ForeColor = global::System.Drawing.SystemColors.ButtonFace;
			this.checkBox4.Location = new global::System.Drawing.Point(200, 389);
			this.checkBox4.Name = "checkBox4";
			this.checkBox4.Size = new global::System.Drawing.Size(79, 19);
			this.checkBox4.TabIndex = 3;
			this.checkBox4.Text = "Erase FRP";
			this.checkBox4.UseVisualStyleBackColor = true;
			this.label2.AutoSize = true;
			this.label2.Font = new global::System.Drawing.Font("Bahnschrift Condensed", 14.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label2.ForeColor = global::System.Drawing.Color.Cornsilk;
			this.label2.Location = new global::System.Drawing.Point(23, 15);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(47, 23);
			this.label2.TabIndex = 2;
			this.label2.Text = "Model";
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Items.AddRange(new object[]
			{
				"Galaxy Z Fold6 [SM-F956W] (BIT_1)", "Galaxy Z Fold6 [SM-F956U] (BIT_1)", "Galaxy Z Fold6 5G [SM-F956B] (BIT_1)", "Galaxy Z Fold5 [SM-F946W] (BIT_4)", "Galaxy Z Fold5 [SM-F946U] (BIT_4)", "Galaxy Z Fold5 5G [SM-F946B] (BIT_3)", "Galaxy Z Fold 4 [SM-F936W] (BIT_6)", "Galaxy Z Fold 4 [SM-F936U] (BIT_6)", "Galaxy Z Fold 4 [SM-F936N] (BIT_2)", "Galaxy Z Fold 4 [SM-F936B] (BIT_7)",
				"Galaxy Z Fold 3 [SM-F926U] (BIT_5)", "Galaxy Z Fold 3 [SM-F926N] (BIT_2)", "Galaxy Z Fold 3 [SM-F926B] (BIT_5)", "Galaxy Z Fold 2 5G [SM-F916U] (BIT_2)", "Galaxy Z Flip6 [SM-F741W] (BIT_1)", "Galaxy Z Flip6 5G [SM-F741U] (BIT_1)", "Galaxy Z Flip6 5G [SM-F741B] (BIT_1)", "Galaxy Z Flip5 [SM-F731W] (BIT_4)", "Galaxy Z Flip5 [SM-F731U] (BIT_4)", "Galaxy Z Flip5 5G [SM-F731B] (BIT_3)",
				"Galaxy Z Flip 4 [SM-F721W] (BIT_4)", "Galaxy Z Flip 4 [SM-F721U] (BIT_4)", "Galaxy Z Flip 4 [SM-F721B] (BIT_5)", "Galaxy Z Flip 3 5G [SM-F711W] (BIT_6)", "Galaxy Z Flip 3 5G [SM-F711U] (BIT_6)", "Galaxy Z Flip 3 5G [SM-F711B] (BIT_6)", "Galaxy Tablet A9+ [SM-X210] (BIT_1)", "Galaxy Tab S8 Ultra [SM-X900] (BIT_5)", "Galaxy Tab S5e [SM-T725] (BIT_1)", "Galaxy Tab A9+ [SM-X216B] (BIT_1)",
				"Galaxy Tab A7 LTE [SM-T507] (BIT_4)", "Galaxy Tab A7 LTE [SM-T505] (BIT_3)", "Galaxy Tab A7 10.4 (2020) [SM-T500] (BIT_8)", "Galaxy Tab A 8.0 2021 [SM-T295] (BIT_6)", "Galaxy Tab A 10.5 4G [SM-T595] (BIT_4)", "Galaxy S9+ [SM-G965U] (BIT_7)", "Galaxy S9+ PLUS [SC-03K] (BIT_1)", "Galaxy S9 [SM-G960U] (BIT_7)", "Galaxy S8 Active [SM-G892U/SM-G892A] (BIT_6)", "Galaxy S24+ [SM-S926W] (BIT_3)",
				"Galaxy S24+ [SM-S926U] (BIT_3)", "Galaxy S24 [SM-S921W] (BIT_3)", "Galaxy S24 [SM-S921U] (BIT_3)", "Galaxy S24 Ultra [SM-S928B] (BIT_3)", "Galaxy S24 Ultra 5G [SM-S928W] (BIT_3)", "Galaxy S24 Ultra 5G [SM-S928U] (BIT_3)", "Galaxy S24 Ultra 5G [SM-S9280] (BIT_3)", "Galaxy S23 [SM-S911W] (BIT_4)", "Galaxy S23 [SM-S911U] (BIT_4)", "Galaxy S23 Ultra [SM-S918W] (BIT_4)",
				"Galaxy S23 Ultra [SM-S918U] (BIT_4)", "Galaxy S23 Ultra 5G [SM-S918N] (BIT_2)", "Galaxy S23 Ultra 5G [SM-S918B] (BIT_6)", "Galaxy S23 Plus 5G [SM-S916W] (BIT_4)", "Galaxy S23 Plus 5G [SM-S916U] (BIT_4)", "Galaxy S23 Plus 5G [SM-S916N] (BIT_2)", "Galaxy S23 Plus 5G [SM-S916B] (BIT_5)", "Galaxy S23 FE [SM-S711W] (BIT_5)", "Galaxy S23 FE [SM-S711U] (BIT_5)", "Galaxy S23 5G [SM-S911B] (BIT_6)",
				"Galaxy S22 [SM-S901E] (BIT_7)", "Galaxy S22 [SM-S9010] (BIT_4)", "Galaxy S22 Ultra 5G [SM-S908W] (BIT_6)", "Galaxy S22 Ultra 5G [SM-S908U] (BIT_6)", "Galaxy S22 Ultra 5G [SM-S908N] (BIT_3)", "Galaxy S22 Ultra 5G [SM-S908E] (BIT_A)", "Galaxy S22 Plus 5G [SM-S906W] (BIT_6)", "Galaxy S22 Plus 5G [SM-S906U] (BIT_6)", "Galaxy S22 Plus 5G [SM-S906E] (BIT_7)", "Galaxy S22 5G [SM-S901W] (BIT_6)",
				"Galaxy S22 5G [SM-S901U] (BIT_6)", "Galaxy S21+ Plus [SM-G996W] (BIT_C)", "Galaxy S21+ Plus [SM-G996U] (BIT_C)", "Galaxy S21 Ultra [SM-G998W] (BIT_C)", "Galaxy S21 Ultra [SM-G998U] (BIT_C)", "Galaxy S21 FE [SM-G990U] (BIT_C)", "Galaxy S21 FE [SM-G990U3] (BIT_A)", "Galaxy S21 FE [SM-G990U2] (BIT_A)", "Galaxy S21 FE [SM-G990U1] (BIT_C)", "Galaxy S21 FE 5G [SM-G990B] (BIT_6)",
				"Galaxy S21 FE 5G [SM-G990B2] (BIT_6)", "Galaxy S21 5G [SM-G991W] (BIT_C)", "Galaxy S21 5G [SM-G991U] (BIT_C)", "Galaxy S20+ Plus [SM-G986W] (BIT_9)", "Galaxy S20+ Plus [SM-G986U] (BIT_9)", "Galaxy S20 Ultra 5G [SM-G988W] (BIT_8)", "Galaxy S20 Ultra 5G [SM-G988U] (BIT_8)", "Galaxy S20 FE [SM-G780G] (BIT_8)", "Galaxy S20 FE 5G [SM-G781V] (BIT_B)", "Galaxy S20 FE 5G [SM-G781U] (BIT_H)",
				"Galaxy S20 FE 5G [SM-G781B] (BIT_8)", "Galaxy S20 5G [SM-G981W] (BIT_9)", "Galaxy S20 5G [SM-G981U] (BIT_9)", "Galaxy S10E [SM-G970U] (BIT_9)", "Galaxy S10+ Plus [SM-G975U] (BIT_9)", "Galaxy S10 [SM-G973W] (BIT_9)", "Galaxy S10 [SM-G973U] (BIT_9)", "Galaxy S10 Plus [SM-G975W] (BIT_9)", "Galaxy Note10+ 5G [SM-N976V] (BIT_8)", "Galaxy Note10 [SM-N970U] (BIT_7)",
				"Galaxy Note10 Plus [SM-N975W] (BIT_8)", "Galaxy Note10 Plus [SM-N975U] (BIT_8)", "Galaxy Note 20 Ultra 5G [SM-N986W] (BIT_8)", "Galaxy Note 20 Ultra 5G [SM-N986U] (BIT_8)", "Galaxy Note 20 5G [SM-N981W] (BIT_6)", "Galaxy Note 20 5G [SM-N981U] (BIT_6)", "Galaxy M55 5G [SM-M556B] (BIT_2)", "Galaxy M23 5G [SM-M236L] (BIT_6)", "Galaxy M14 [SM-M145F] (BIT_1)", "Galaxy F55 5G [SM-E556B] (BIT_1)",
				"Galaxy F02s [SM-E025F] (BIT_6)", "Galaxy A80 [SM-A805F] (BIT_4)", "Galaxy A73 5G [SM-A736B] (BIT_6)", "Galaxy A72 [SM-A725F] (BIT_6)", "Galaxy A71 [SM-A715F] (BIT_3)", "Galaxy A71 5G [SM-A716W] (BIT_B)", "Galaxy A71 5G [SM-A716U] (BIT_B)", "Galaxy A70 [SM-A705Y] (BIT_3)", "Galaxy A70 [SM-A705MN] (BIT_5)", "Galaxy A70 [SM-A705F] (BIT_5)",
				"Galaxy A52 [SM-A525F] (BIT_6)", "Galaxy A52 5G [SM-A526W] (BIT_C)", "Galaxy A52 5G [SM-A526U] (BIT_C)", "Galaxy A52 5G [SM-A526B] (BIT_6)", "Galaxy A42 5G [SM-A426U] (BIT_8)", "Galaxy A23 [SM-A235M] (BIT_5)", "Galaxy A23 [SM-A235F] (BIT_5)", "Galaxy A23 5G [SM-S236DL] (BIT_9)", "Galaxy A23 5G [SM-A236W] (BIT_6)", "Galaxy A23 5G [SM-A236U] (BIT_6)",
				"Galaxy A23 5G [SM-A236E] (BIT_5)", "Galaxy A20s [SM-A207F] (BIT_5)", "Galaxy A05s [SM-A057M] (BIT_2)", "Galaxy A05s [SM-A057F] (BIT_2)", "Galaxy A02s [SM-A025M] (BIT_8)", "Galaxy A01 [SM-A015G] (BIT_6)"
			});
			this.comboBox1.Location = new global::System.Drawing.Point(76, 13);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new global::System.Drawing.Size(464, 26);
			this.comboBox1.TabIndex = 1;
			this.comboBox1.SelectedIndexChanged += new global::System.EventHandler(this.comboBox1_SelectedIndexChanged);
			this.DataView.AllowUserToAddRows = false;
			this.DataView.AllowUserToDeleteRows = false;
			this.DataView.BackgroundColor = global::System.Drawing.Color.FromArgb(39, 39, 39);
			this.DataView.ColumnHeadersBorderStyle = global::System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
			this.DataView.ColumnHeadersHeightSizeMode = global::System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.DataView.Columns.AddRange(new global::System.Windows.Forms.DataGridViewColumn[] { this.dataGridViewCheckBoxColumn1, this.dataGridViewTextBoxColumn1, this.dataGridViewTextBoxColumn3, this.dataGridViewTextBoxColumn4, this.dataGridViewTextBoxColumn5, this.dataGridViewTextBoxColumn6 });
			this.DataView.Location = new global::System.Drawing.Point(24, 42);
			this.DataView.Name = "DataView";
			this.DataView.RowHeadersVisible = false;
			this.DataView.Size = new global::System.Drawing.Size(516, 269);
			this.DataView.TabIndex = 18;
			this.dataGridViewCheckBoxColumn1.HeaderText = " ";
			this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
			this.dataGridViewCheckBoxColumn1.Width = 20;
			this.dataGridViewTextBoxColumn1.HeaderText = "Lun";
			this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
			this.dataGridViewTextBoxColumn1.Width = 50;
			this.dataGridViewTextBoxColumn3.HeaderText = "Partition";
			this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
			this.dataGridViewTextBoxColumn4.HeaderText = "Sector Size";
			this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
			this.dataGridViewTextBoxColumn5.HeaderText = "Partition Size";
			this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
			this.dataGridViewTextBoxColumn6.HeaderText = "Location";
			this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
			this.dataGridViewTextBoxColumn6.Width = 300;
			this.tabPage4.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("tabPage4.BackgroundImage");
			this.tabPage4.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.tabPage4.Controls.Add(this.button38);
			this.tabPage4.Controls.Add(this.button36);
			this.tabPage4.Controls.Add(this.button35);
			this.tabPage4.Controls.Add(this.button30);
			this.tabPage4.Controls.Add(this.button24);
			this.tabPage4.Controls.Add(this.button22);
			this.tabPage4.Controls.Add(this.button18);
			this.tabPage4.Controls.Add(this.button14);
			this.tabPage4.Controls.Add(this.button15);
			this.tabPage4.Controls.Add(this.button16);
			this.tabPage4.Controls.Add(this.button13);
			this.tabPage4.Location = new global::System.Drawing.Point(4, 27);
			this.tabPage4.Name = "tabPage4";
			this.tabPage4.Padding = new global::System.Windows.Forms.Padding(3);
			this.tabPage4.Size = new global::System.Drawing.Size(559, 426);
			this.tabPage4.TabIndex = 3;
			this.tabPage4.Text = "TOOLS";
			this.tabPage4.UseVisualStyleBackColor = true;
			this.button38.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button38.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button38.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold);
			this.button38.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button38.Image");
			this.button38.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button38.Location = new global::System.Drawing.Point(40, 350);
			this.button38.Name = "button38";
			this.button38.Size = new global::System.Drawing.Size(223, 46);
			this.button38.TabIndex = 20;
			this.button38.Text = "        Devloper Option Hide";
			this.button38.UseVisualStyleBackColor = false;
			this.button38.Click += new global::System.EventHandler(this.button38_Click);
			this.button36.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button36.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button36.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button36.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button36.Image");
			this.button36.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button36.Location = new global::System.Drawing.Point(298, 223);
			this.button36.Name = "button36";
			this.button36.Size = new global::System.Drawing.Size(223, 46);
			this.button36.TabIndex = 19;
			this.button36.Text = "Service Provide Update Fix.  ";
			this.button36.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button36.UseVisualStyleBackColor = false;
			this.button36.Click += new global::System.EventHandler(this.button36_Click);
			this.button35.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button35.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button35.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold);
			this.button35.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button35.Image");
			this.button35.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button35.Location = new global::System.Drawing.Point(40, 37);
			this.button35.Name = "button35";
			this.button35.Size = new global::System.Drawing.Size(223, 46);
			this.button35.TabIndex = 18;
			this.button35.Text = "Sim Unlock (Pixel)             ";
			this.button35.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button35.UseVisualStyleBackColor = false;
			this.button35.Click += new global::System.EventHandler(this.button35_Click);
			this.button30.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button30.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button30.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button30.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button30.Image");
			this.button30.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button30.Location = new global::System.Drawing.Point(298, 99);
			this.button30.Name = "button30";
			this.button30.Size = new global::System.Drawing.Size(223, 46);
			this.button30.TabIndex = 17;
			this.button30.Text = "        Disable Factory Reset Method 2 ";
			this.button30.UseVisualStyleBackColor = false;
			this.button30.Click += new global::System.EventHandler(this.button30_Click);
			this.button24.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button24.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button24.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button24.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button24.Image");
			this.button24.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button24.Location = new global::System.Drawing.Point(40, 223);
			this.button24.Name = "button24";
			this.button24.Size = new global::System.Drawing.Size(223, 46);
			this.button24.TabIndex = 16;
			this.button24.Text = "        Sam. Account Remove (ADB) ";
			this.button24.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button24.UseVisualStyleBackColor = false;
			this.button24.Click += new global::System.EventHandler(this.button24_Click);
			this.button22.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button22.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button22.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold);
			this.button22.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button22.Image");
			this.button22.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button22.Location = new global::System.Drawing.Point(298, 37);
			this.button22.Name = "button22";
			this.button22.Size = new global::System.Drawing.Size(223, 46);
			this.button22.TabIndex = 15;
			this.button22.Text = "    FRP (ADB) ";
			this.button22.UseVisualStyleBackColor = false;
			this.button22.Click += new global::System.EventHandler(this.button22_Click);
			this.button18.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button18.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button18.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold);
			this.button18.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button18.Image");
			this.button18.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button18.Location = new global::System.Drawing.Point(40, 286);
			this.button18.Name = "button18";
			this.button18.Size = new global::System.Drawing.Size(223, 46);
			this.button18.TabIndex = 14;
			this.button18.Text = "     Factory Reset ";
			this.button18.UseVisualStyleBackColor = false;
			this.button18.Click += new global::System.EventHandler(this.button18_Click);
			this.button14.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button14.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button14.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold);
			this.button14.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button14.Image");
			this.button14.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button14.Location = new global::System.Drawing.Point(40, 160);
			this.button14.Name = "button14";
			this.button14.Size = new global::System.Drawing.Size(223, 46);
			this.button14.TabIndex = 11;
			this.button14.Text = "    Disable OTA";
			this.button14.UseVisualStyleBackColor = false;
			this.button14.Click += new global::System.EventHandler(this.button14_Click);
			this.button15.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button15.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button15.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button15.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button15.Image");
			this.button15.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button15.Location = new global::System.Drawing.Point(40, 99);
			this.button15.Name = "button15";
			this.button15.Size = new global::System.Drawing.Size(223, 46);
			this.button15.TabIndex = 12;
			this.button15.Text = "        Disable Factory Reset Method 1";
			this.button15.UseVisualStyleBackColor = false;
			this.button15.Click += new global::System.EventHandler(this.button15_Click);
			this.button16.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button16.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button16.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold);
			this.button16.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button16.Image");
			this.button16.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button16.Location = new global::System.Drawing.Point(298, 160);
			this.button16.Name = "button16";
			this.button16.Size = new global::System.Drawing.Size(223, 46);
			this.button16.TabIndex = 13;
			this.button16.Text = "      Enable OTA   ";
			this.button16.UseVisualStyleBackColor = false;
			this.button16.Click += new global::System.EventHandler(this.button16_Click);
			this.button13.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button13.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button13.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button13.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button13.Image");
			this.button13.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button13.Location = new global::System.Drawing.Point(298, 286);
			this.button13.Name = "button13";
			this.button13.Size = new global::System.Drawing.Size(223, 46);
			this.button13.TabIndex = 10;
			this.button13.Text = "        Install Samsung Driver";
			this.button13.UseVisualStyleBackColor = false;
			this.button13.Click += new global::System.EventHandler(this.button13_Click);
			this.tabPage5.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("tabPage5.BackgroundImage");
			this.tabPage5.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.tabPage5.Controls.Add(this.button44);
			this.tabPage5.Controls.Add(this.button43);
			this.tabPage5.Controls.Add(this.button42);
			this.tabPage5.Controls.Add(this.button41);
			this.tabPage5.Controls.Add(this.button39);
			this.tabPage5.Controls.Add(this.button34);
			this.tabPage5.Controls.Add(this.button11);
			this.tabPage5.Controls.Add(this.button31);
			this.tabPage5.Controls.Add(this.button23);
			this.tabPage5.Controls.Add(this.button7);
			this.tabPage5.Controls.Add(this.button6);
			this.tabPage5.Controls.Add(this.button10);
			this.tabPage5.Controls.Add(this.ItAdminBtn);
			this.tabPage5.Location = new global::System.Drawing.Point(4, 27);
			this.tabPage5.Name = "tabPage5";
			this.tabPage5.Padding = new global::System.Windows.Forms.Padding(3);
			this.tabPage5.Size = new global::System.Drawing.Size(559, 426);
			this.tabPage5.TabIndex = 4;
			this.tabPage5.Text = "MDM";
			this.tabPage5.UseVisualStyleBackColor = true;
			this.tabPage5.Click += new global::System.EventHandler(this.tabPage5_Click);
			this.button44.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button44.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button44.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button44.ForeColor = global::System.Drawing.SystemColors.ControlText;
			this.button44.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button44.Image");
			this.button44.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button44.Location = new global::System.Drawing.Point(324, 42);
			this.button44.Name = "button44";
			this.button44.Size = new global::System.Drawing.Size(200, 42);
			this.button44.TabIndex = 25;
			this.button44.Text = "     Samsung Knox Disable";
			this.button44.UseVisualStyleBackColor = false;
			this.button44.Click += new global::System.EventHandler(this.button44_Click);
			this.button43.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button43.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button43.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button43.ForeColor = global::System.Drawing.SystemColors.ControlText;
			this.button43.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button43.Image");
			this.button43.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button43.Location = new global::System.Drawing.Point(324, 160);
			this.button43.Name = "button43";
			this.button43.Size = new global::System.Drawing.Size(200, 42);
			this.button43.TabIndex = 24;
			this.button43.Text = "IT Admin (Hyper OS )    ";
			this.button43.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button43.UseVisualStyleBackColor = false;
			this.button43.Click += new global::System.EventHandler(this.button43_Click);
			this.button42.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button42.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button42.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button42.ForeColor = global::System.Drawing.SystemColors.ControlText;
			this.button42.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button42.Image");
			this.button42.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button42.Location = new global::System.Drawing.Point(324, 101);
			this.button42.Name = "button42";
			this.button42.Size = new global::System.Drawing.Size(200, 42);
			this.button42.TabIndex = 23;
			this.button42.Text = "       Samsung MDM (All Patch)";
			this.button42.UseVisualStyleBackColor = false;
			this.button42.Click += new global::System.EventHandler(this.button42_Click);
			this.button41.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button41.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button41.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button41.ForeColor = global::System.Drawing.SystemColors.ControlText;
			this.button41.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button41.Image");
			this.button41.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button41.Location = new global::System.Drawing.Point(33, 42);
			this.button41.Name = "button41";
			this.button41.Size = new global::System.Drawing.Size(200, 42);
			this.button41.TabIndex = 22;
			this.button41.Text = "IT Admin Android 15";
			this.button41.UseVisualStyleBackColor = false;
			this.button41.Click += new global::System.EventHandler(this.button41_Click);
			this.button39.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button39.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button39.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold);
			this.button39.ForeColor = global::System.Drawing.SystemColors.ControlText;
			this.button39.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button39.Image");
			this.button39.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button39.Location = new global::System.Drawing.Point(33, 219);
			this.button39.Name = "button39";
			this.button39.Size = new global::System.Drawing.Size(200, 42);
			this.button39.TabIndex = 21;
			this.button39.Text = "    Redmi MDM (All In One)";
			this.button39.UseVisualStyleBackColor = false;
			this.button39.Click += new global::System.EventHandler(this.button39_Click_1);
			this.button34.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button34.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button34.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button34.ForeColor = global::System.Drawing.SystemColors.ControlText;
			this.button34.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button34.Image");
			this.button34.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button34.Location = new global::System.Drawing.Point(324, 218);
			this.button34.Name = "button34";
			this.button34.Size = new global::System.Drawing.Size(200, 42);
			this.button34.TabIndex = 20;
			this.button34.Text = "      Samsung Payjoy (New )";
			this.button34.UseVisualStyleBackColor = false;
			this.button34.Click += new global::System.EventHandler(this.button34_Click_1);
			this.button11.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button11.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button11.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button11.ForeColor = global::System.Drawing.SystemColors.ControlText;
			this.button11.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button11.Image");
			this.button11.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button11.Location = new global::System.Drawing.Point(33, 279);
			this.button11.Name = "button11";
			this.button11.Size = new global::System.Drawing.Size(200, 42);
			this.button11.TabIndex = 19;
			this.button11.Text = "IT Admin VIVO (New Security)";
			this.button11.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button11.UseVisualStyleBackColor = false;
			this.button11.Click += new global::System.EventHandler(this.button11_Click);
			this.button31.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button31.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button31.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button31.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button31.Image");
			this.button31.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button31.Location = new global::System.Drawing.Point(33, 337);
			this.button31.Name = "button31";
			this.button31.Size = new global::System.Drawing.Size(200, 42);
			this.button31.TabIndex = 18;
			this.button31.Text = "    Disable Framework";
			this.button31.UseVisualStyleBackColor = false;
			this.button31.Click += new global::System.EventHandler(this.button31_Click);
			this.button23.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button23.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button23.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button23.ForeColor = global::System.Drawing.SystemColors.ControlText;
			this.button23.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button23.Image");
			this.button23.ImageAlign = global::System.Drawing.ContentAlignment.BottomLeft;
			this.button23.Location = new global::System.Drawing.Point(33, 101);
			this.button23.Name = "button23";
			this.button23.Size = new global::System.Drawing.Size(200, 42);
			this.button23.TabIndex = 14;
			this.button23.Text = "IT Admin Universal";
			this.button23.UseVisualStyleBackColor = false;
			this.button23.Click += new global::System.EventHandler(this.button23_Click);
			this.button7.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button7.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button7.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button7.ForeColor = global::System.Drawing.SystemColors.ControlText;
			this.button7.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button7.Image");
			this.button7.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button7.Location = new global::System.Drawing.Point(324, 279);
			this.button7.Name = "button7";
			this.button7.Size = new global::System.Drawing.Size(200, 42);
			this.button7.TabIndex = 13;
			this.button7.Text = "IT Admin (Tecno,Infinix,Itel)    ";
			this.button7.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button7.UseVisualStyleBackColor = false;
			this.button7.Click += new global::System.EventHandler(this.button7_Click_1);
			this.button6.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button6.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button6.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 9.75f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button6.ForeColor = global::System.Drawing.SystemColors.ControlText;
			this.button6.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button6.Image");
			this.button6.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button6.Location = new global::System.Drawing.Point(33, 160);
			this.button6.Name = "button6";
			this.button6.Size = new global::System.Drawing.Size(200, 42);
			this.button6.TabIndex = 12;
			this.button6.Text = "IT Admin Hyper OS (Android 15)";
			this.button6.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button6.UseVisualStyleBackColor = false;
			this.button6.Click += new global::System.EventHandler(this.button6_Click);
			this.button10.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button10.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button10.Enabled = false;
			this.button10.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold);
			this.button10.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button10.Image");
			this.button10.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button10.Location = new global::System.Drawing.Point(1291, 532);
			this.button10.Name = "button10";
			this.button10.Size = new global::System.Drawing.Size(87, 34);
			this.button10.TabIndex = 11;
			this.button10.Text = "Exit DL";
			this.button10.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button10.UseVisualStyleBackColor = false;
			this.ItAdminBtn.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.ItAdminBtn.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.ItAdminBtn.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 12f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.ItAdminBtn.ForeColor = global::System.Drawing.SystemColors.ControlText;
			this.ItAdminBtn.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("ItAdminBtn.Image");
			this.ItAdminBtn.ImageAlign = global::System.Drawing.ContentAlignment.BottomLeft;
			this.ItAdminBtn.Location = new global::System.Drawing.Point(324, 338);
			this.ItAdminBtn.Name = "ItAdminBtn";
			this.ItAdminBtn.Size = new global::System.Drawing.Size(200, 42);
			this.ItAdminBtn.TabIndex = 3;
			this.ItAdminBtn.Text = "      IT Admin (Work profile)";
			this.ItAdminBtn.UseVisualStyleBackColor = false;
			this.ItAdminBtn.Click += new global::System.EventHandler(this.ItAdminBtn_Click);
			this.tabPage6.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("tabPage6.BackgroundImage");
			this.tabPage6.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.tabPage6.Controls.Add(this.button25);
			this.tabPage6.Controls.Add(this.button21);
			this.tabPage6.Controls.Add(this.button19);
			this.tabPage6.Location = new global::System.Drawing.Point(4, 27);
			this.tabPage6.Name = "tabPage6";
			this.tabPage6.Padding = new global::System.Windows.Forms.Padding(3);
			this.tabPage6.Size = new global::System.Drawing.Size(559, 426);
			this.tabPage6.TabIndex = 5;
			this.tabPage6.Text = "FLASH";
			this.tabPage6.UseVisualStyleBackColor = true;
			this.tabPage6.Click += new global::System.EventHandler(this.tabPage6_Click);
			this.button25.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button25.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Bold);
			this.button25.Location = new global::System.Drawing.Point(385, 6);
			this.button25.Name = "button25";
			this.button25.Size = new global::System.Drawing.Size(171, 23);
			this.button25.TabIndex = 2;
			this.button25.Text = "Reboot Download Mode";
			this.button25.UseVisualStyleBackColor = true;
			this.button25.Click += new global::System.EventHandler(this.button25_Click);
			this.button21.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button21.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button21.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 14.25f, global::System.Drawing.FontStyle.Bold);
			this.button21.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button21.Image");
			this.button21.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button21.Location = new global::System.Drawing.Point(188, 228);
			this.button21.Name = "button21";
			this.button21.Size = new global::System.Drawing.Size(181, 74);
			this.button21.TabIndex = 1;
			this.button21.Text = "Samfw.com       ";
			this.button21.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button21.UseVisualStyleBackColor = false;
			this.button21.Click += new global::System.EventHandler(this.button21_Click);
			this.button19.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button19.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button19.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 14.25f, global::System.Drawing.FontStyle.Bold);
			this.button19.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button19.Image");
			this.button19.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button19.Location = new global::System.Drawing.Point(188, 104);
			this.button19.Name = "button19";
			this.button19.Size = new global::System.Drawing.Size(181, 74);
			this.button19.TabIndex = 0;
			this.button19.Text = "Open Flash Tool   ";
			this.button19.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button19.UseVisualStyleBackColor = false;
			this.button19.Click += new global::System.EventHandler(this.button19_Click);
			this.tabPage3.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("tabPage3.BackgroundImage");
			this.tabPage3.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.tabPage3.Controls.Add(this.button33);
			this.tabPage3.Controls.Add(this.button28);
			this.tabPage3.Controls.Add(this.button3);
			this.tabPage3.Controls.Add(this.button27);
			this.tabPage3.Controls.Add(this.button4);
			this.tabPage3.Location = new global::System.Drawing.Point(4, 27);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Padding = new global::System.Windows.Forms.Padding(3);
			this.tabPage3.Size = new global::System.Drawing.Size(559, 426);
			this.tabPage3.TabIndex = 6;
			this.tabPage3.Text = "QR Codes";
			this.tabPage3.UseVisualStyleBackColor = true;
			this.button33.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button33.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button33.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold);
			this.button33.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button33.Image");
			this.button33.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button33.Location = new global::System.Drawing.Point(132, 154);
			this.button33.Name = "button33";
			this.button33.Size = new global::System.Drawing.Size(273, 38);
			this.button33.TabIndex = 21;
			this.button33.Text = "      ADB Enable QR 14 Method 2";
			this.button33.UseVisualStyleBackColor = false;
			this.button33.Click += new global::System.EventHandler(this.button33_Click_1);
			this.button28.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button28.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button28.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold);
			this.button28.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button28.Image");
			this.button28.ImageAlign = global::System.Drawing.ContentAlignment.BottomLeft;
			this.button28.Location = new global::System.Drawing.Point(269, 307);
			this.button28.Name = "button28";
			this.button28.Size = new global::System.Drawing.Size(136, 38);
			this.button28.TabIndex = 16;
			this.button28.Text = "     Hyper OS QR 2";
			this.button28.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button28.UseVisualStyleBackColor = false;
			this.button28.Click += new global::System.EventHandler(this.button28_Click);
			this.button3.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button3.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button3.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold);
			this.button3.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button3.Image");
			this.button3.ImageAlign = global::System.Drawing.ContentAlignment.BottomLeft;
			this.button3.Location = new global::System.Drawing.Point(127, 228);
			this.button3.Name = "button3";
			this.button3.Size = new global::System.Drawing.Size(278, 38);
			this.button3.TabIndex = 20;
			this.button3.Text = "     ADB Enable QR 13";
			this.button3.UseVisualStyleBackColor = false;
			this.button3.Click += new global::System.EventHandler(this.button3_Click_1);
			this.button27.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button27.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button27.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold);
			this.button27.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button27.Image");
			this.button27.ImageAlign = global::System.Drawing.ContentAlignment.BottomLeft;
			this.button27.Location = new global::System.Drawing.Point(127, 307);
			this.button27.Name = "button27";
			this.button27.Size = new global::System.Drawing.Size(136, 38);
			this.button27.TabIndex = 15;
			this.button27.Text = "     Hyper OS QR 1";
			this.button27.TextAlign = global::System.Drawing.ContentAlignment.MiddleRight;
			this.button27.UseVisualStyleBackColor = false;
			this.button27.Click += new global::System.EventHandler(this.button27_Click);
			this.button4.BackColor = global::System.Drawing.Color.PaleTurquoise;
			this.button4.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button4.Font = new global::System.Drawing.Font("Bahnschrift SemiCondensed", 11.25f, global::System.Drawing.FontStyle.Bold);
			this.button4.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button4.Image");
			this.button4.ImageAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button4.Location = new global::System.Drawing.Point(132, 80);
			this.button4.Name = "button4";
			this.button4.Size = new global::System.Drawing.Size(273, 38);
			this.button4.TabIndex = 8;
			this.button4.Text = "      ADB Enable QR 14 Method 1";
			this.button4.UseVisualStyleBackColor = false;
			this.button4.Click += new global::System.EventHandler(this.button4_Click);
			this.tabPage7.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("tabPage7.BackgroundImage");
			this.tabPage7.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			this.tabPage7.Controls.Add(this.pictureBox8);
			this.tabPage7.Location = new global::System.Drawing.Point(4, 27);
			this.tabPage7.Name = "tabPage7";
			this.tabPage7.Padding = new global::System.Windows.Forms.Padding(3);
			this.tabPage7.Size = new global::System.Drawing.Size(559, 426);
			this.tabPage7.TabIndex = 7;
			this.tabPage7.Text = "Coming Soon";
			this.tabPage7.UseVisualStyleBackColor = true;
			this.pictureBox8.Dock = global::System.Windows.Forms.DockStyle.Fill;
			this.pictureBox8.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox8.Image");
			this.pictureBox8.Location = new global::System.Drawing.Point(3, 3);
			this.pictureBox8.Name = "pictureBox8";
			this.pictureBox8.Size = new global::System.Drawing.Size(553, 420);
			this.pictureBox8.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.CenterImage;
			this.pictureBox8.TabIndex = 0;
			this.pictureBox8.TabStop = false;
			this.panel2.Controls.Add(this.panel4);
			this.panel2.Controls.Add(this.progressBar1);
			this.panel2.Controls.Add(this.ResultTxt);
			this.panel2.Location = new global::System.Drawing.Point(563, 35);
			this.panel2.Name = "panel2";
			this.panel2.Size = new global::System.Drawing.Size(328, 490);
			this.panel2.TabIndex = 2;
			this.panel2.Paint += new global::System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
			this.panel4.BackColor = global::System.Drawing.SystemColors.GradientActiveCaption;
			this.panel4.Controls.Add(this.lblCredits);
			this.panel4.Controls.Add(this.pictureBox7);
			this.panel4.Controls.Add(this.lblExpiryDate);
			this.panel4.Controls.Add(this.pictureBox2);
			this.panel4.Controls.Add(this.button8);
			this.panel4.Location = new global::System.Drawing.Point(1, 459);
			this.panel4.Name = "panel4";
			this.panel4.Size = new global::System.Drawing.Size(327, 30);
			this.panel4.TabIndex = 3;
			this.lblCredits.AutoSize = true;
			this.lblCredits.Font = new global::System.Drawing.Font("Roboto", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.lblCredits.Location = new global::System.Drawing.Point(201, 9);
			this.lblCredits.Name = "lblCredits";
			this.lblCredits.Size = new global::System.Drawing.Size(56, 18);
			this.lblCredits.TabIndex = 12;
			this.lblCredits.Text = "Credits";
			this.lblCredits.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.pictureBox7.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox7.Image");
			this.pictureBox7.Location = new global::System.Drawing.Point(3, 4);
			this.pictureBox7.Name = "pictureBox7";
			this.pictureBox7.Size = new global::System.Drawing.Size(25, 25);
			this.pictureBox7.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox7.TabIndex = 11;
			this.pictureBox7.TabStop = false;
			this.lblExpiryDate.AutoSize = true;
			this.lblExpiryDate.Font = new global::System.Drawing.Font("Roboto", 11.25f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.lblExpiryDate.Location = new global::System.Drawing.Point(34, 9);
			this.lblExpiryDate.Name = "lblExpiryDate";
			this.lblExpiryDate.Size = new global::System.Drawing.Size(84, 18);
			this.lblExpiryDate.TabIndex = 8;
			this.lblExpiryDate.Text = "Expiry Date";
			this.lblExpiryDate.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.lblExpiryDate.Click += new global::System.EventHandler(this.lblExpiryDate_Click);
			this.pictureBox2.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox2.Image");
			this.pictureBox2.Location = new global::System.Drawing.Point(176, 3);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new global::System.Drawing.Size(25, 25);
			this.pictureBox2.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox2.TabIndex = 8;
			this.pictureBox2.TabStop = false;
			this.button8.BackColor = global::System.Drawing.Color.Transparent;
			this.button8.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 8.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.button8.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button8.Image");
			this.button8.Location = new global::System.Drawing.Point(300, 2);
			this.button8.Name = "button8";
			this.button8.Size = new global::System.Drawing.Size(26, 28);
			this.button8.TabIndex = 1;
			this.button8.TextAlign = global::System.Drawing.ContentAlignment.MiddleLeft;
			this.button8.UseVisualStyleBackColor = false;
			this.button8.Click += new global::System.EventHandler(this.button8_Click_1);
			this.progressBar1.BackColor = global::System.Drawing.Color.Wheat;
			this.progressBar1.Location = new global::System.Drawing.Point(0, 436);
			this.progressBar1.Name = "progressBar1";
			this.progressBar1.Size = new global::System.Drawing.Size(328, 24);
			this.progressBar1.TabIndex = 2;
			this.progressBar1.Click += new global::System.EventHandler(this.progressBar1_Click);
			this.ResultTxt.BackColor = global::System.Drawing.Color.FromArgb(25, 25, 25);
			this.ResultTxt.Font = new global::System.Drawing.Font("Microsoft YaHei", 9f, global::System.Drawing.FontStyle.Bold, global::System.Drawing.GraphicsUnit.Point, 0);
			this.ResultTxt.ForeColor = global::System.Drawing.Color.LawnGreen;
			this.ResultTxt.Location = new global::System.Drawing.Point(0, 0);
			this.ResultTxt.Name = "ResultTxt";
			this.ResultTxt.ReadOnly = true;
			this.ResultTxt.Size = new global::System.Drawing.Size(328, 435);
			this.ResultTxt.TabIndex = 0;
			this.ResultTxt.Text = componentResourceManager.GetString("ResultTxt.Text");
			this.ResultTxt.TextChanged += new global::System.EventHandler(this.ResultTxt_TextChanged);
			this.timer1.Tick += new global::System.EventHandler(this.timer1_Tick);
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = global::System.Drawing.Color.FloralWhite;
			base.ClientSize = new global::System.Drawing.Size(891, 525);
			base.Controls.Add(this.panel2);
			base.Controls.Add(this.panel1);
			base.Controls.Add(this.panel3);
			this.ForeColor = global::System.Drawing.SystemColors.ControlText;
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.Fixed3D;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.Name = "KGKiller";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "KG Killer v1.1.0 ";
			base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.KGKiller_FormClosing);
			base.Load += new global::System.EventHandler(this.KGKiller_Load);
			base.InputLanguageChanging += new global::System.Windows.Forms.InputLanguageChangingEventHandler(this.KGKiller_InputLanguageChanging);
			this.panel3.ResumeLayout(false);
			this.panel3.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
			this.panel1.ResumeLayout(false);
			this.panel5.ResumeLayout(false);
			this.panel5.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox4).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox6).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox5).EndInit();
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage2.ResumeLayout(false);
			this.tabPage2.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.DataView).EndInit();
			this.tabPage4.ResumeLayout(false);
			this.tabPage5.ResumeLayout(false);
			this.tabPage6.ResumeLayout(false);
			this.tabPage3.ResumeLayout(false);
			this.tabPage7.ResumeLayout(false);
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox8).EndInit();
			this.panel2.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			this.panel4.PerformLayout();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox7).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox2).EndInit();
			base.ResumeLayout(false);
		}

		// Token: 0x040000C5 RID: 197
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x040000C6 RID: 198
		private global::System.Windows.Forms.Panel panel3;

		// Token: 0x040000C7 RID: 199
		private global::System.Windows.Forms.Panel panel1;

		// Token: 0x040000C8 RID: 200
		private global::System.Windows.Forms.Panel panel2;

		// Token: 0x040000C9 RID: 201
		private global::System.Windows.Forms.RichTextBox ResultTxt;

		// Token: 0x040000CA RID: 202
		private global::System.Windows.Forms.Label label1;

		// Token: 0x040000CB RID: 203
		private global::System.Windows.Forms.ComboBox Adb_Devices;

		// Token: 0x040000CC RID: 204
		private global::System.Windows.Forms.TabControl tabControl1;

		// Token: 0x040000CD RID: 205
		private global::System.Windows.Forms.TabPage tabPage2;

		// Token: 0x040000CE RID: 206
		private global::System.Windows.Forms.TabPage tabPage4;

		// Token: 0x040000CF RID: 207
		private global::System.Windows.Forms.TabPage tabPage5;

		// Token: 0x040000D0 RID: 208
		private global::System.Windows.Forms.TabPage tabPage6;

		// Token: 0x040000D1 RID: 209
		private global::System.Windows.Forms.Panel panel5;

		// Token: 0x040000D2 RID: 210
		private global::System.Windows.Forms.TabPage tabPage1;

		// Token: 0x040000D3 RID: 211
		private global::System.Windows.Forms.Button button5;

		// Token: 0x040000D4 RID: 212
		private global::System.Windows.Forms.Button ItAdminBtn;

		// Token: 0x040000D5 RID: 213
		private global::System.Windows.Forms.Button button4;

		// Token: 0x040000D6 RID: 214
		private global::System.Windows.Forms.Button button2;

		// Token: 0x040000D7 RID: 215
		private global::System.Windows.Forms.Button button1;

		// Token: 0x040000D8 RID: 216
		private global::System.Windows.Forms.Button MtpBtn;

		// Token: 0x040000D9 RID: 217
		private global::System.Windows.Forms.Button LiveScrnBtn;

		// Token: 0x040000DA RID: 218
		private global::System.Windows.Forms.Button KgBtn;

		// Token: 0x040000DB RID: 219
		private global::System.Windows.Forms.Button button10;

		// Token: 0x040000DC RID: 220
		private global::System.Windows.Forms.Button button13;

		// Token: 0x040000DD RID: 221
		private global::System.Windows.Forms.Button button14;

		// Token: 0x040000DE RID: 222
		private global::System.Windows.Forms.Button button15;

		// Token: 0x040000DF RID: 223
		private global::System.Windows.Forms.Button button16;

		// Token: 0x040000E0 RID: 224
		private global::System.Windows.Forms.Button button17;

		// Token: 0x040000E1 RID: 225
		private global::System.Windows.Forms.Button button18;

		// Token: 0x040000E2 RID: 226
		private global::System.Windows.Forms.PictureBox pictureBox1;

		// Token: 0x040000E3 RID: 227
		private global::System.Windows.Forms.PictureBox pictureBox3;

		// Token: 0x040000E4 RID: 228
		private global::System.Windows.Forms.Label label2;

		// Token: 0x040000E5 RID: 229
		private global::System.Windows.Forms.ComboBox comboBox1;

		// Token: 0x040000E6 RID: 230
		private global::System.Windows.Forms.CheckBox checkBox10;

		// Token: 0x040000E7 RID: 231
		private global::System.Windows.Forms.CheckBox checkBox9;

		// Token: 0x040000E8 RID: 232
		private global::System.Windows.Forms.CheckBox checkBox8;

		// Token: 0x040000E9 RID: 233
		private global::System.Windows.Forms.CheckBox checkBox7;

		// Token: 0x040000EA RID: 234
		private global::System.Windows.Forms.CheckBox checkBox6;

		// Token: 0x040000EB RID: 235
		private global::System.Windows.Forms.CheckBox checkBox5;

		// Token: 0x040000EC RID: 236
		private global::System.Windows.Forms.CheckBox checkBox4;

		// Token: 0x040000ED RID: 237
		private global::System.Windows.Forms.CheckBox checkBox12;

		// Token: 0x040000EE RID: 238
		private global::System.Windows.Forms.Button button20;

		// Token: 0x040000EF RID: 239
		private global::System.Windows.Forms.Button button19;

		// Token: 0x040000F0 RID: 240
		private global::System.Windows.Forms.Button button21;

		// Token: 0x040000F1 RID: 241
		private global::System.Windows.Forms.Button button6;

		// Token: 0x040000F2 RID: 242
		private global::System.Windows.Forms.Button button7;

		// Token: 0x040000F3 RID: 243
		internal global::System.Windows.Forms.DataGridView DataView;

		// Token: 0x040000F4 RID: 244
		private global::System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;

		// Token: 0x040000F5 RID: 245
		private global::System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;

		// Token: 0x040000F6 RID: 246
		private global::System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;

		// Token: 0x040000F7 RID: 247
		private global::System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;

		// Token: 0x040000F8 RID: 248
		private global::System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;

		// Token: 0x040000F9 RID: 249
		private global::System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;

		// Token: 0x040000FA RID: 250
		private global::System.Windows.Forms.Button button8;

		// Token: 0x040000FB RID: 251
		private global::System.Windows.Forms.Button button9;

		// Token: 0x040000FC RID: 252
		private global::System.Windows.Forms.Button button12;

		// Token: 0x040000FD RID: 253
		private global::System.Windows.Forms.Button button22;

		// Token: 0x040000FE RID: 254
		private global::System.Windows.Forms.Label label3;

		// Token: 0x040000FF RID: 255
		private global::System.Windows.Forms.Button button23;

		// Token: 0x04000100 RID: 256
		private global::System.Windows.Forms.ProgressBar progressBar1;

		// Token: 0x04000101 RID: 257
		private global::System.Windows.Forms.Button button24;

		// Token: 0x04000102 RID: 258
		private global::System.Windows.Forms.Button button25;

		// Token: 0x04000103 RID: 259
		private global::System.Windows.Forms.PictureBox pictureBox5;

		// Token: 0x04000104 RID: 260
		private global::System.Windows.Forms.Button button26;

		// Token: 0x04000105 RID: 261
		private global::System.Windows.Forms.PictureBox pictureBox6;

		// Token: 0x04000106 RID: 262
		private global::System.Windows.Forms.Label label5;

		// Token: 0x04000107 RID: 263
		private global::System.Windows.Forms.Button button28;

		// Token: 0x04000108 RID: 264
		private global::System.Windows.Forms.Button button27;

		// Token: 0x04000109 RID: 265
		private global::System.Windows.Forms.Panel panel4;

		// Token: 0x0400010A RID: 266
		private global::System.Windows.Forms.Button button29;

		// Token: 0x0400010B RID: 267
		private global::System.Windows.Forms.Button button30;

		// Token: 0x0400010C RID: 268
		private global::System.Windows.Forms.Button button31;

		// Token: 0x0400010D RID: 269
		private global::System.Windows.Forms.Button button32;

		// Token: 0x0400010E RID: 270
		private global::System.Windows.Forms.Button button3;

		// Token: 0x0400010F RID: 271
		private global::System.Windows.Forms.Button button33;

		// Token: 0x04000110 RID: 272
		private global::System.Windows.Forms.TabPage tabPage3;

		// Token: 0x04000111 RID: 273
		private global::System.Windows.Forms.Button button11;

		// Token: 0x04000112 RID: 274
		private global::System.Windows.Forms.Button button34;

		// Token: 0x04000113 RID: 275
		private global::System.Windows.Forms.Button button35;

		// Token: 0x04000114 RID: 276
		private global::System.Windows.Forms.Button button36;

		// Token: 0x04000115 RID: 277
		private global::System.Windows.Forms.Button button37;

		// Token: 0x04000116 RID: 278
		private global::System.Windows.Forms.Button button38;

		// Token: 0x04000117 RID: 279
		private global::System.Windows.Forms.Label lblExpiryDate;

		// Token: 0x04000118 RID: 280
		private global::System.Windows.Forms.Button button39;

		// Token: 0x04000119 RID: 281
		private global::System.Windows.Forms.Button button40;

		// Token: 0x0400011A RID: 282
		private global::System.Windows.Forms.Button button41;

		// Token: 0x0400011B RID: 283
		private global::System.Windows.Forms.Button button42;

		// Token: 0x0400011C RID: 284
		private global::System.Windows.Forms.Button button43;

		// Token: 0x0400011D RID: 285
		private global::System.Windows.Forms.TabPage tabPage7;

		// Token: 0x0400011E RID: 286
		private global::System.Windows.Forms.PictureBox pictureBox2;

		// Token: 0x0400011F RID: 287
		private global::System.Windows.Forms.PictureBox pictureBox4;

		// Token: 0x04000120 RID: 288
		private global::System.Windows.Forms.Timer timer1;

		// Token: 0x04000121 RID: 289
		private global::System.Windows.Forms.Label lblDate;

		// Token: 0x04000122 RID: 290
		private global::System.Windows.Forms.PictureBox pictureBox7;

		// Token: 0x04000123 RID: 291
		private global::System.Windows.Forms.Label lblCredits;

		// Token: 0x04000124 RID: 292
		private global::System.Windows.Forms.PictureBox pictureBox8;

		// Token: 0x04000125 RID: 293
		private global::System.Windows.Forms.Button button44;
	}
}
