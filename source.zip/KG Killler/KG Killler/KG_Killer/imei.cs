﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

namespace KG_Killer
{
	// Token: 0x0200006C RID: 108
	public partial class imei : Form
	{
		// Token: 0x06000234 RID: 564 RVA: 0x000261CC File Offset: 0x000243CC
		public imei()
		{
			this.InitializeComponent();
		}

		// Token: 0x06000235 RID: 565 RVA: 0x000261EC File Offset: 0x000243EC
		private void button16_Click(object sender, EventArgs e)
		{
			if (string.IsNullOrEmpty(this.textBox1.Text))
			{
				MessageBox.Show("Please Enter  IMEI", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
			}
			else
			{
				Thread.Sleep(4000);
				MessageBox.Show("IMEI IS Submitted To Our Server", "Success", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				base.Close();
			}
		}

		// Token: 0x06000236 RID: 566 RVA: 0x00026244 File Offset: 0x00024444
		private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
		{
			if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
			{
				e.Handled = true;
			}
		}
	}
}
