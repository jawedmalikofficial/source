﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Windows.Forms;

namespace KG_Killer
{
	// Token: 0x02000072 RID: 114
	public class ShellController
	{
		// Token: 0x06000245 RID: 581 RVA: 0x00026C88 File Offset: 0x00024E88
		public static Process CreateShellProcess()
		{
			ShellController.OutputString = "";
			string text = ShellController.adbExe;
			Process process = new Process();
			ProcessStartInfo processStartInfo = new ProcessStartInfo
			{
				FileName = text,
				WorkingDirectory = ShellController.adbFolder,
				Arguments = "shell",
				RedirectStandardOutput = true,
				RedirectStandardError = true,
				RedirectStandardInput = true,
				UseShellExecute = false,
				CreateNoWindow = true
			};
			process.StartInfo = processStartInfo;
			process.Start();
			process.OutputDataReceived += ShellController.HandleOutputData;
			process.ErrorDataReceived += ShellController.HandleErrorData;
			process.BeginOutputReadLine();
			process.BeginErrorReadLine();
			Stopwatch stopwatch = new Stopwatch();
			stopwatch.Start();
			process.StandardInput.WriteLine("echo \"" + ShellController.Delimiter + "\"");
			while (!process.HasExited)
			{
				if (stopwatch.ElapsedMilliseconds > 10000L)
				{
					process.Kill();
					break;
				}
				if (ShellController.OutputString.Contains(ShellController.Delimiter + Environment.NewLine))
				{
					break;
				}
				Thread.Sleep(10);
			}
			ShellController.OutputString = ShellController.OutputString.Replace(Environment.NewLine + ShellController.Delimiter, "");
			ShellController.OutputString = ShellController.OutputString.Replace(ShellController.Delimiter + Environment.NewLine, "");
			Thread.Sleep(1000);
			return process;
		}

		// Token: 0x06000246 RID: 582 RVA: 0x00026DFC File Offset: 0x00024FFC
		public static Process CreateShellProcess2(string command)
		{
			ShellController.OutputString = "";
			string text = ShellController.adbExe;
			Process process = new Process();
			ProcessStartInfo processStartInfo = new ProcessStartInfo
			{
				FileName = text,
				WorkingDirectory = ShellController.adbFolder,
				Arguments = "shell",
				RedirectStandardOutput = true,
				RedirectStandardError = true,
				RedirectStandardInput = true,
				UseShellExecute = false,
				CreateNoWindow = true
			};
			process.StartInfo = processStartInfo;
			process.Start();
			process.OutputDataReceived += ShellController.HandleOutputData;
			process.ErrorDataReceived += ShellController.HandleErrorData;
			process.BeginOutputReadLine();
			process.BeginErrorReadLine();
			Stopwatch stopwatch = new Stopwatch();
			stopwatch.Start();
			process.StandardInput.WriteLine(command);
			process.StandardInput.WriteLine("echo \"" + ShellController.Delimiter + "\"");
			while (!process.HasExited)
			{
				if (stopwatch.ElapsedMilliseconds <= 10000L)
				{
					if (!ShellController.OutputString.Contains(ShellController.Delimiter + Environment.NewLine))
					{
						Thread.Sleep(10);
						continue;
					}
				}
				else
				{
					process.Kill();
				}
				IL_011E:
				ShellController.OutputString = ShellController.OutputString.Replace(Environment.NewLine + ShellController.Delimiter, "");
				ShellController.OutputString = ShellController.OutputString.Replace(ShellController.Delimiter + Environment.NewLine, "");
				Thread.Sleep(1000);
				return process;
			}
			goto IL_011E;
		}

		// Token: 0x06000247 RID: 583 RVA: 0x00026F7C File Offset: 0x0002517C
		public static Process CreateShellProcess3(string command)
		{
			ShellController.OutputString = "";
			string text = ShellController.adbExe;
			Process process = new Process();
			ProcessStartInfo processStartInfo = new ProcessStartInfo
			{
				FileName = text,
				WorkingDirectory = ShellController.adbFolder,
				Arguments = "shell",
				RedirectStandardOutput = true,
				RedirectStandardError = true,
				RedirectStandardInput = true,
				UseShellExecute = false,
				CreateNoWindow = true
			};
			process.StartInfo = processStartInfo;
			process.Start();
			process.OutputDataReceived += ShellController.HandleOutputData;
			process.ErrorDataReceived += ShellController.HandleErrorData;
			process.BeginOutputReadLine();
			process.BeginErrorReadLine();
			Stopwatch stopwatch = new Stopwatch();
			stopwatch.Start();
			process.StandardInput.WriteLine(command);
			process.StandardInput.WriteLine("echo \"" + ShellController.Delimiter + "\"");
			while (!process.HasExited)
			{
				if (stopwatch.ElapsedMilliseconds > 10000L)
				{
					process.Kill();
					break;
				}
				if (ShellController.OutputString.Contains(ShellController.Delimiter + Environment.NewLine))
				{
					break;
				}
				Thread.Sleep(10);
			}
			ShellController.OutputString = ShellController.OutputString.Replace(Environment.NewLine + ShellController.Delimiter, "");
			ShellController.OutputString = ShellController.OutputString.Replace(ShellController.Delimiter + Environment.NewLine, "");
			Thread.Sleep(1000);
			return process;
		}

		// Token: 0x06000248 RID: 584 RVA: 0x000270FC File Offset: 0x000252FC
		private static void HandleOutputData(object sender, DataReceivedEventArgs e)
		{
			Console.WriteLine(e.Data);
			if (!string.IsNullOrEmpty(e.Data))
			{
				ShellController.OutputString = ShellController.OutputString + e.Data + "\r\n";
			}
		}

		// Token: 0x06000249 RID: 585 RVA: 0x000270FC File Offset: 0x000252FC
		private static void HandleErrorData(object sender, DataReceivedEventArgs e)
		{
			Console.WriteLine(e.Data);
			if (!string.IsNullOrEmpty(e.Data))
			{
				ShellController.OutputString = ShellController.OutputString + e.Data + "\r\n";
			}
		}

		// Token: 0x0600024A RID: 586 RVA: 0x00027140 File Offset: 0x00025340
		public static string ExecuteShellCommand(Process process, string command, int timeout = 20000)
		{
			Console.WriteLine(">>>" + command);
			ShellController.OutputString = "";
			process.StandardInput.WriteLine(command);
			Thread.Sleep(50);
			process.StandardInput.WriteLine("echo \"" + ShellController.Delimiter + "\"");
			Thread.Sleep(50);
			Stopwatch stopwatch = new Stopwatch();
			stopwatch.Start();
			while (!process.HasExited && stopwatch.ElapsedMilliseconds <= (long)timeout && !ShellController.OutputString.Contains(ShellController.Delimiter + Environment.NewLine))
			{
			}
			ShellController.OutputString = ShellController.OutputString.Replace(Environment.NewLine + ShellController.Delimiter, "");
			ShellController.OutputString = ShellController.OutputString.Replace(ShellController.Delimiter + Environment.NewLine, "");
			return ShellController.OutputString;
		}

		// Token: 0x0600024B RID: 587 RVA: 0x0002722C File Offset: 0x0002542C
		public static void CloseShellProcess(Process process)
		{
			try
			{
				process.Dispose();
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x0600024C RID: 588 RVA: 0x00027258 File Offset: 0x00025458
		public static string GetCommandOutput(string command, int timeout = 20000)
		{
			Process process = ShellController.CreateShellProcess();
			string text = ShellController.ExecuteShellCommand(process, command, timeout);
			ShellController.CloseShellProcess(process);
			return text;
		}

		// Token: 0x040003D0 RID: 976
		public static string adbFolder = Path.Combine(Application.StartupPath, "data");

		// Token: 0x040003D1 RID: 977
		public static string adbExe = Path.Combine(ShellController.adbFolder, "adb.exe");

		// Token: 0x040003D2 RID: 978
		public static string OutputString = "";

		// Token: 0x040003D3 RID: 979
		public static string Delimiter = "#DELIMITER#";
	}
}
