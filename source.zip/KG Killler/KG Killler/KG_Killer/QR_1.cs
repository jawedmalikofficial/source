﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace KG_Killer
{
	// Token: 0x02000070 RID: 112
	public partial class QR_1 : Form
	{
		// Token: 0x0600023F RID: 575 RVA: 0x00026988 File Offset: 0x00024B88
		public QR_1()
		{
			this.InitializeComponent();
		}
	}
}
