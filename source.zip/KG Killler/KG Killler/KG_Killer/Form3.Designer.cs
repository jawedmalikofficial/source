﻿namespace KG_Killer
{
	// Token: 0x02000068 RID: 104
	public partial class Form3 : global::System.Windows.Forms.Form
	{
		// Token: 0x0600022A RID: 554 RVA: 0x000245AC File Offset: 0x000227AC
		protected override void Dispose(bool disposing)
		{
			if (disposing && this.components != null)
			{
				this.components.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0600022B RID: 555 RVA: 0x000245DC File Offset: 0x000227DC
		private void InitializeComponent()
		{
			global::System.ComponentModel.ComponentResourceManager componentResourceManager = new global::System.ComponentModel.ComponentResourceManager(typeof(global::KG_Killer.Form3));
			this.pictureBox1 = new global::System.Windows.Forms.PictureBox();
			this.pictureBox2 = new global::System.Windows.Forms.PictureBox();
			this.pictureBox3 = new global::System.Windows.Forms.PictureBox();
			this.txtUsername = new global::System.Windows.Forms.TextBox();
			this.txtPassword = new global::System.Windows.Forms.TextBox();
			this.linkLabel1 = new global::System.Windows.Forms.LinkLabel();
			this.pictureBox5 = new global::System.Windows.Forms.PictureBox();
			this.pictureBox6 = new global::System.Windows.Forms.PictureBox();
			this.linkLabel2 = new global::System.Windows.Forms.LinkLabel();
			this.button1 = new global::System.Windows.Forms.Button();
			this.lblErrorMessage = new global::System.Windows.Forms.Label();
			this.lblSuccessMessage = new global::System.Windows.Forms.Label();
			this.lblBannedMessage = new global::System.Windows.Forms.Label();
			this.lblNotActivatedMessage = new global::System.Windows.Forms.Label();
			this.lblInvalidPasswordMessage = new global::System.Windows.Forms.Label();
			this.lblHWIDMismatchMessage = new global::System.Windows.Forms.Label();
			this.label1 = new global::System.Windows.Forms.Label();
			this.chkRememberMe = new global::System.Windows.Forms.CheckBox();
			this.label2 = new global::System.Windows.Forms.Label();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox2).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox5).BeginInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox6).BeginInit();
			base.SuspendLayout();
			this.pictureBox1.BackColor = global::System.Drawing.Color.Transparent;
			this.pictureBox1.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox1.Image");
			this.pictureBox1.Location = new global::System.Drawing.Point(73, 6);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new global::System.Drawing.Size(196, 192);
			this.pictureBox1.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			this.pictureBox1.Click += new global::System.EventHandler(this.pictureBox1_Click);
			this.pictureBox2.BackColor = global::System.Drawing.Color.Transparent;
			this.pictureBox2.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox2.Image");
			this.pictureBox2.Location = new global::System.Drawing.Point(31, 190);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new global::System.Drawing.Size(36, 36);
			this.pictureBox2.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox2.TabIndex = 1;
			this.pictureBox2.TabStop = false;
			this.pictureBox3.BackColor = global::System.Drawing.Color.Transparent;
			this.pictureBox3.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox3.Image");
			this.pictureBox3.Location = new global::System.Drawing.Point(31, 247);
			this.pictureBox3.Name = "pictureBox3";
			this.pictureBox3.Size = new global::System.Drawing.Size(36, 36);
			this.pictureBox3.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox3.TabIndex = 2;
			this.pictureBox3.TabStop = false;
			this.txtUsername.BackColor = global::System.Drawing.Color.LightSteelBlue;
			this.txtUsername.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.txtUsername.ForeColor = global::System.Drawing.Color.FromArgb(130, 130, 130);
			this.txtUsername.Location = new global::System.Drawing.Point(76, 204);
			this.txtUsername.Name = "txtUsername";
			this.txtUsername.Size = new global::System.Drawing.Size(223, 22);
			this.txtUsername.TabIndex = 3;
			this.txtUsername.Text = "Username";
			this.txtUsername.Enter += new global::System.EventHandler(this.LogUsernameText_Enter);
			this.txtUsername.Leave += new global::System.EventHandler(this.LogUsernameText_Leave);
			this.txtPassword.AccessibleRole = global::System.Windows.Forms.AccessibleRole.None;
			this.txtPassword.BackColor = global::System.Drawing.Color.LightSteelBlue;
			this.txtPassword.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.txtPassword.Location = new global::System.Drawing.Point(76, 261);
			this.txtPassword.Name = "txtPassword";
			this.txtPassword.Size = new global::System.Drawing.Size(223, 22);
			this.txtPassword.TabIndex = 4;
			this.txtPassword.UseSystemPasswordChar = true;
			this.linkLabel1.ActiveLinkColor = global::System.Drawing.Color.FromArgb(93, 93, 93);
			this.linkLabel1.AutoSize = true;
			this.linkLabel1.BackColor = global::System.Drawing.Color.Transparent;
			this.linkLabel1.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 9f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.linkLabel1.LinkColor = global::System.Drawing.Color.FromArgb(127, 127, 127);
			this.linkLabel1.Location = new global::System.Drawing.Point(201, 286);
			this.linkLabel1.Name = "linkLabel1";
			this.linkLabel1.Size = new global::System.Drawing.Size(98, 15);
			this.linkLabel1.TabIndex = 7;
			this.linkLabel1.TabStop = true;
			this.linkLabel1.Text = "Forgot password";
			this.linkLabel1.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
			this.pictureBox5.BackColor = global::System.Drawing.Color.Transparent;
			this.pictureBox5.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox5.Image");
			this.pictureBox5.Location = new global::System.Drawing.Point(4, 478);
			this.pictureBox5.Name = "pictureBox5";
			this.pictureBox5.Size = new global::System.Drawing.Size(25, 25);
			this.pictureBox5.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox5.TabIndex = 8;
			this.pictureBox5.TabStop = false;
			this.pictureBox6.BackColor = global::System.Drawing.Color.Transparent;
			this.pictureBox6.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.pictureBox6.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("pictureBox6.Image");
			this.pictureBox6.Location = new global::System.Drawing.Point(296, 478);
			this.pictureBox6.Name = "pictureBox6";
			this.pictureBox6.Size = new global::System.Drawing.Size(25, 25);
			this.pictureBox6.SizeMode = global::System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox6.TabIndex = 9;
			this.pictureBox6.TabStop = false;
			this.pictureBox6.Click += new global::System.EventHandler(this.pictureBox6_Click);
			this.linkLabel2.AutoSize = true;
			this.linkLabel2.BackColor = global::System.Drawing.Color.Transparent;
			this.linkLabel2.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.linkLabel2.Font = new global::System.Drawing.Font("Nirmala UI", 11.25f, global::System.Drawing.FontStyle.Bold);
			this.linkLabel2.LinkColor = global::System.Drawing.Color.RoyalBlue;
			this.linkLabel2.Location = new global::System.Drawing.Point(28, 482);
			this.linkLabel2.Name = "linkLabel2";
			this.linkLabel2.Size = new global::System.Drawing.Size(95, 20);
			this.linkLabel2.TabIndex = 10;
			this.linkLabel2.TabStop = true;
			this.linkLabel2.Text = "Kgkiller.com";
			this.linkLabel2.LinkClicked += new global::System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
			this.button1.BackColor = global::System.Drawing.Color.Coral;
			this.button1.Cursor = global::System.Windows.Forms.Cursors.Hand;
			this.button1.Image = (global::System.Drawing.Image)componentResourceManager.GetObject("button1.Image");
			this.button1.Location = new global::System.Drawing.Point(95, 325);
			this.button1.Name = "button1";
			this.button1.Size = new global::System.Drawing.Size(144, 48);
			this.button1.TabIndex = 12;
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new global::System.EventHandler(this.button1_Click);
			this.lblErrorMessage.AutoSize = true;
			this.lblErrorMessage.BackColor = global::System.Drawing.Color.Transparent;
			this.lblErrorMessage.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 14.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.lblErrorMessage.ForeColor = global::System.Drawing.Color.LightCoral;
			this.lblErrorMessage.Location = new global::System.Drawing.Point(69, 412);
			this.lblErrorMessage.Name = "lblErrorMessage";
			this.lblErrorMessage.Size = new global::System.Drawing.Size(194, 24);
			this.lblErrorMessage.TabIndex = 13;
			this.lblErrorMessage.Text = "User is not Registered";
			this.lblSuccessMessage.AutoSize = true;
			this.lblSuccessMessage.BackColor = global::System.Drawing.Color.Transparent;
			this.lblSuccessMessage.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 14.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.lblSuccessMessage.ForeColor = global::System.Drawing.Color.Green;
			this.lblSuccessMessage.Location = new global::System.Drawing.Point(91, 419);
			this.lblSuccessMessage.Name = "lblSuccessMessage";
			this.lblSuccessMessage.Size = new global::System.Drawing.Size(158, 24);
			this.lblSuccessMessage.TabIndex = 14;
			this.lblSuccessMessage.Text = "Login Successful!";
			this.lblBannedMessage.AutoSize = true;
			this.lblBannedMessage.BackColor = global::System.Drawing.Color.Transparent;
			this.lblBannedMessage.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 15.75f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.lblBannedMessage.ForeColor = global::System.Drawing.Color.Red;
			this.lblBannedMessage.Location = new global::System.Drawing.Point(46, 418);
			this.lblBannedMessage.Name = "lblBannedMessage";
			this.lblBannedMessage.Size = new global::System.Drawing.Size(244, 25);
			this.lblBannedMessage.TabIndex = 15;
			this.lblBannedMessage.Text = "Your Account is Banned";
			this.lblNotActivatedMessage.AutoSize = true;
			this.lblNotActivatedMessage.BackColor = global::System.Drawing.Color.Transparent;
			this.lblNotActivatedMessage.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 14.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.lblNotActivatedMessage.ForeColor = global::System.Drawing.Color.HotPink;
			this.lblNotActivatedMessage.Location = new global::System.Drawing.Point(27, 418);
			this.lblNotActivatedMessage.Name = "lblNotActivatedMessage";
			this.lblNotActivatedMessage.Size = new global::System.Drawing.Size(263, 24);
			this.lblNotActivatedMessage.TabIndex = 16;
			this.lblNotActivatedMessage.Text = "You Have Not A Valid License";
			this.lblInvalidPasswordMessage.AutoSize = true;
			this.lblInvalidPasswordMessage.BackColor = global::System.Drawing.Color.Transparent;
			this.lblInvalidPasswordMessage.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 18f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.lblInvalidPasswordMessage.ForeColor = global::System.Drawing.Color.Red;
			this.lblInvalidPasswordMessage.Location = new global::System.Drawing.Point(68, 403);
			this.lblInvalidPasswordMessage.Name = "lblInvalidPasswordMessage";
			this.lblInvalidPasswordMessage.Size = new global::System.Drawing.Size(195, 29);
			this.lblInvalidPasswordMessage.TabIndex = 17;
			this.lblInvalidPasswordMessage.Text = "Invalid Password";
			this.lblHWIDMismatchMessage.AutoSize = true;
			this.lblHWIDMismatchMessage.BackColor = global::System.Drawing.Color.Transparent;
			this.lblHWIDMismatchMessage.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 14.25f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.lblHWIDMismatchMessage.ForeColor = global::System.Drawing.Color.Gold;
			this.lblHWIDMismatchMessage.Location = new global::System.Drawing.Point(18, 406);
			this.lblHWIDMismatchMessage.Name = "lblHWIDMismatchMessage";
			this.lblHWIDMismatchMessage.Size = new global::System.Drawing.Size(294, 24);
			this.lblHWIDMismatchMessage.TabIndex = 18;
			this.lblHWIDMismatchMessage.Text = "HWID Cooldown Time 30 minutes";
			this.label1.AutoSize = true;
			this.label1.BackColor = global::System.Drawing.Color.Transparent;
			this.label1.Font = new global::System.Drawing.Font("Segoe UI Symbol", 12f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label1.ForeColor = global::System.Drawing.Color.SlateGray;
			this.label1.Location = new global::System.Drawing.Point(89, 382);
			this.label1.Name = "label1";
			this.label1.Size = new global::System.Drawing.Size(0, 21);
			this.label1.TabIndex = 19;
			this.chkRememberMe.AutoSize = true;
			this.chkRememberMe.BackColor = global::System.Drawing.Color.Transparent;
			this.chkRememberMe.ForeColor = global::System.Drawing.SystemColors.AppWorkspace;
			this.chkRememberMe.Location = new global::System.Drawing.Point(76, 289);
			this.chkRememberMe.Name = "chkRememberMe";
			this.chkRememberMe.Size = new global::System.Drawing.Size(95, 17);
			this.chkRememberMe.TabIndex = 20;
			this.chkRememberMe.Text = "Remember Me";
			this.chkRememberMe.UseVisualStyleBackColor = false;
			this.label2.AutoSize = true;
			this.label2.BackColor = global::System.Drawing.Color.Transparent;
			this.label2.Font = new global::System.Drawing.Font("Microsoft Sans Serif", 18f, global::System.Drawing.FontStyle.Regular, global::System.Drawing.GraphicsUnit.Point, 0);
			this.label2.ForeColor = global::System.Drawing.Color.LawnGreen;
			this.label2.Location = new global::System.Drawing.Point(68, 403);
			this.label2.Name = "label2";
			this.label2.Size = new global::System.Drawing.Size(195, 29);
			this.label2.TabIndex = 21;
			this.label2.Text = "Login Successful";
			base.AutoScaleDimensions = new global::System.Drawing.SizeF(6f, 13f);
			base.AutoScaleMode = global::System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImage = (global::System.Drawing.Image)componentResourceManager.GetObject("$this.BackgroundImage");
			this.BackgroundImageLayout = global::System.Windows.Forms.ImageLayout.Stretch;
			base.ClientSize = new global::System.Drawing.Size(324, 506);
			base.Controls.Add(this.label2);
			base.Controls.Add(this.chkRememberMe);
			base.Controls.Add(this.lblInvalidPasswordMessage);
			base.Controls.Add(this.lblErrorMessage);
			base.Controls.Add(this.label1);
			base.Controls.Add(this.lblHWIDMismatchMessage);
			base.Controls.Add(this.lblNotActivatedMessage);
			base.Controls.Add(this.lblSuccessMessage);
			base.Controls.Add(this.button1);
			base.Controls.Add(this.linkLabel2);
			base.Controls.Add(this.pictureBox6);
			base.Controls.Add(this.pictureBox5);
			base.Controls.Add(this.linkLabel1);
			base.Controls.Add(this.txtPassword);
			base.Controls.Add(this.txtUsername);
			base.Controls.Add(this.pictureBox3);
			base.Controls.Add(this.pictureBox2);
			base.Controls.Add(this.pictureBox1);
			base.Controls.Add(this.lblBannedMessage);
			base.FormBorderStyle = global::System.Windows.Forms.FormBorderStyle.FixedSingle;
			base.Icon = (global::System.Drawing.Icon)componentResourceManager.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.Name = "Form3";
			base.StartPosition = global::System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "KG Killer v1.1.0";
			base.FormClosing += new global::System.Windows.Forms.FormClosingEventHandler(this.Form3_FormClosing);
			base.Load += new global::System.EventHandler(this.Form3_Load);
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox1).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox2).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox3).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox5).EndInit();
			((global::System.ComponentModel.ISupportInitialize)this.pictureBox6).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000396 RID: 918
		private global::System.ComponentModel.IContainer components = null;

		// Token: 0x04000397 RID: 919
		private global::System.Windows.Forms.PictureBox pictureBox1;

		// Token: 0x04000398 RID: 920
		private global::System.Windows.Forms.PictureBox pictureBox2;

		// Token: 0x04000399 RID: 921
		private global::System.Windows.Forms.PictureBox pictureBox3;

		// Token: 0x0400039A RID: 922
		private global::System.Windows.Forms.TextBox txtUsername;

		// Token: 0x0400039B RID: 923
		private global::System.Windows.Forms.TextBox txtPassword;

		// Token: 0x0400039C RID: 924
		private global::System.Windows.Forms.LinkLabel linkLabel1;

		// Token: 0x0400039D RID: 925
		private global::System.Windows.Forms.PictureBox pictureBox5;

		// Token: 0x0400039E RID: 926
		private global::System.Windows.Forms.PictureBox pictureBox6;

		// Token: 0x0400039F RID: 927
		private global::System.Windows.Forms.LinkLabel linkLabel2;

		// Token: 0x040003A0 RID: 928
		private global::System.Windows.Forms.Button button1;

		// Token: 0x040003A1 RID: 929
		private global::System.Windows.Forms.Label lblErrorMessage;

		// Token: 0x040003A2 RID: 930
		private global::System.Windows.Forms.Label lblSuccessMessage;

		// Token: 0x040003A3 RID: 931
		private global::System.Windows.Forms.Label lblBannedMessage;

		// Token: 0x040003A4 RID: 932
		private global::System.Windows.Forms.Label lblNotActivatedMessage;

		// Token: 0x040003A5 RID: 933
		private global::System.Windows.Forms.Label lblInvalidPasswordMessage;

		// Token: 0x040003A6 RID: 934
		private global::System.Windows.Forms.Label lblHWIDMismatchMessage;

		// Token: 0x040003A7 RID: 935
		private global::System.Windows.Forms.Label label1;

		// Token: 0x040003A8 RID: 936
		private global::System.Windows.Forms.CheckBox chkRememberMe;

		// Token: 0x040003A9 RID: 937
		private global::System.Windows.Forms.Label label2;
	}
}
