﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace KG_Killer
{
	// Token: 0x02000071 RID: 113
	public partial class qr2 : Form
	{
		// Token: 0x06000242 RID: 578 RVA: 0x00026B0C File Offset: 0x00024D0C
		public qr2()
		{
			this.InitializeComponent();
		}
	}
}
