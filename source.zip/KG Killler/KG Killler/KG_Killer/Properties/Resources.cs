﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace KG_Killer.Properties
{
	// Token: 0x02000073 RID: 115
	[CompilerGenerated]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "17.0.0.0")]
	[DebuggerNonUserCode]
	internal class Resources
	{
		// Token: 0x0600024F RID: 591 RVA: 0x000050A4 File Offset: 0x000032A4
		internal Resources()
		{
		}

		// Token: 0x1700001E RID: 30
		// (get) Token: 0x06000250 RID: 592 RVA: 0x000272CC File Offset: 0x000254CC
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (Resources.resourceMan == null)
				{
					ResourceManager resourceManager = new ResourceManager("KG_Killer.Properties.Resources", typeof(Resources).Assembly);
					Resources.resourceMan = resourceManager;
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x1700001F RID: 31
		// (get) Token: 0x06000251 RID: 593 RVA: 0x0002730C File Offset: 0x0002550C
		// (set) Token: 0x06000252 RID: 594 RVA: 0x00027320 File Offset: 0x00025520
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x040003D4 RID: 980
		private static ResourceManager resourceMan;

		// Token: 0x040003D5 RID: 981
		private static CultureInfo resourceCulture;
	}
}
