﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace KG_Killer.Properties
{
	// Token: 0x02000074 RID: 116
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "17.11.0.0")]
	internal sealed partial class Settings : ApplicationSettingsBase
	{
		// Token: 0x17000020 RID: 32
		// (get) Token: 0x06000253 RID: 595 RVA: 0x00027334 File Offset: 0x00025534
		public static Settings Default
		{
			get
			{
				return Settings.defaultInstance;
			}
		}

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x06000254 RID: 596 RVA: 0x00027348 File Offset: 0x00025548
		// (set) Token: 0x06000255 RID: 597 RVA: 0x00027368 File Offset: 0x00025568
		[DefaultSettingValue("")]
		[UserScopedSetting]
		[DebuggerNonUserCode]
		public string Username
		{
			get
			{
				return (string)this["Username"];
			}
			set
			{
				this["Username"] = value;
			}
		}

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x06000256 RID: 598 RVA: 0x00027384 File Offset: 0x00025584
		// (set) Token: 0x06000257 RID: 599 RVA: 0x000273A4 File Offset: 0x000255A4
		[DebuggerNonUserCode]
		[DefaultSettingValue("")]
		[UserScopedSetting]
		public string Password
		{
			get
			{
				return (string)this["Password"];
			}
			set
			{
				this["Password"] = value;
			}
		}

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x06000258 RID: 600 RVA: 0x000273C0 File Offset: 0x000255C0
		// (set) Token: 0x06000259 RID: 601 RVA: 0x000273E0 File Offset: 0x000255E0
		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("False")]
		public bool RememberMe
		{
			get
			{
				return (bool)this["RememberMe"];
			}
			set
			{
				this["RememberMe"] = value;
			}
		}

		// Token: 0x040003D6 RID: 982
		private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());
	}
}
