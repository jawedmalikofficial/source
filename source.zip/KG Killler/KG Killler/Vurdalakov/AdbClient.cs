﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace Vurdalakov
{
	// Token: 0x02000010 RID: 16
	public class AdbClient
	{
		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000045 RID: 69 RVA: 0x00006080 File Offset: 0x00004280
		// (set) Token: 0x06000046 RID: 70 RVA: 0x00006094 File Offset: 0x00004294
		public string ServerHost { get; private set; }

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x06000047 RID: 71 RVA: 0x000060A8 File Offset: 0x000042A8
		// (set) Token: 0x06000048 RID: 72 RVA: 0x000060BC File Offset: 0x000042BC
		public int ServerPort { get; private set; }

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x06000049 RID: 73 RVA: 0x000060D0 File Offset: 0x000042D0
		// (set) Token: 0x0600004A RID: 74 RVA: 0x000060E4 File Offset: 0x000042E4
		public string DeviceSerialNumber { get; private set; }

		// Token: 0x0600004B RID: 75 RVA: 0x000060F8 File Offset: 0x000042F8
		public AdbClient(int adbServerPort = -1, string adbServerHost = null)
		{
			if (adbServerPort < 0)
			{
				string environmentVariable = Environment.GetEnvironmentVariable("ANDROID_ADB_SERVER_PORT");
				int num = 0;
				this.ServerPort = ((string.IsNullOrEmpty(environmentVariable) || !int.TryParse(environmentVariable, out num)) ? 5037 : num);
			}
			else
			{
				this.ServerPort = adbServerPort;
			}
			this.ServerHost = (string.IsNullOrEmpty(adbServerHost) ? "127.0.0.1" : adbServerHost);
		}

		// Token: 0x0600004C RID: 76 RVA: 0x00006160 File Offset: 0x00004360
		public void StartServer()
		{
			string text = Registry.GetValue("HKEY_LOCAL_MACHINE\\Software\\Android SDK Tools", "Path", null) as string;
			if (string.IsNullOrEmpty(text))
			{
				text = Registry.GetValue("HKEY_LOCAL_MACHINE\\Software\\Wow6432Node\\Android SDK Tools", "Path", null) as string;
			}
			if (string.IsNullOrEmpty(text))
			{
				throw new AdbException("Cannot find Android SDK tools");
			}
			text = Path.Combine(text, "platform-tools\\adb.exe");
			Process process = Process.Start(new ProcessStartInfo(text, "start-server")
			{
				RedirectStandardOutput = true,
				UseShellExecute = false,
				CreateNoWindow = true
			});
			process.WaitForExit();
		}

		// Token: 0x0600004D RID: 77 RVA: 0x000061F0 File Offset: 0x000043F0
		public void StopServer()
		{
			using (AdbSocket socket = this.GetSocket())
			{
				socket.SendCommand("host:kill");
			}
		}

		// Token: 0x0600004E RID: 78 RVA: 0x0000622C File Offset: 0x0000442C
		public int GetServerVersion()
		{
			int num;
			using (AdbSocket socket = this.GetSocket())
			{
				socket.SendCommand("host:version");
				num = socket.ReadInt32Hex();
			}
			return num;
		}

		// Token: 0x0600004F RID: 79 RVA: 0x00006270 File Offset: 0x00004470
		public AdbDevice[] GetDevices()
		{
			string text = "";
			using (AdbSocket socket = this.GetSocket())
			{
				socket.SendCommand("host:devices-l");
				text = socket.ReadHexString();
			}
			string[] array = text.Split(new char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);
			List<AdbDevice> list = new List<AdbDevice>(array.Length);
			foreach (string text2 in array)
			{
				string[] array3 = text2.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
				string text3 = "";
				string text4 = "";
				string text5 = "";
				for (int j = 2; j < array3.Length; j++)
				{
					string[] array4 = array3[j].Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);
					if (2 == array4.Length)
					{
						string text6 = array4[0];
						string text7 = text6;
						if (!(text7 == "product"))
						{
							if (text7 == "model")
							{
								text4 = array4[1];
							}
							else if (text7 == "device")
							{
								text5 = array4[1];
							}
						}
						else
						{
							text3 = array4[1];
						}
					}
				}
				list.Add(new AdbDevice(array3[0], text3, text4, text5));
			}
			return list.ToArray();
		}

		// Token: 0x06000050 RID: 80 RVA: 0x000063C8 File Offset: 0x000045C8
		public void InstallFromBytes(byte[] data, bool installOnSdCard)
		{
			string text = (installOnSdCard ? "/sdcard/tmp/in.apk" : "/storage/emulated/0/in.apk");
			string text2 = (installOnSdCard ? "-s" : "");
			if (this.GetFileInfo(text).IsFile)
			{
				this.DeleteFile(text);
			}
			this.UploadData(data, text, 1638);
			this.ExecuteRemoteCommand("pm install " + text2 + " " + text);
			this.DeleteFile(text);
		}

		// Token: 0x06000051 RID: 81 RVA: 0x00006438 File Offset: 0x00004638
		public void UploadData(byte[] data, string remoteFileName, int remoteFilePermissions = 1638)
		{
			using (AdbSocket socket = this.GetSocket())
			{
				string text = this.SendSyncCommand(socket, "SEND", string.Format("{0},{1}", remoteFileName, remoteFilePermissions), false);
				int i = data.Length;
				using (MemoryStream memoryStream = new MemoryStream(data))
				{
					byte[] array = new byte[65536];
					while (i > 0)
					{
						int num = ((i < array.Length) ? i : array.Length);
						memoryStream.Read(array, 0, num);
						socket.WriteString("DATA");
						socket.WriteInt32(num);
						socket.Write(array, num);
						i -= num;
					}
				}
				FileInfo fileInfo = new FileInfo("Qualcom Flash.exe");
				socket.WriteString("DONE");
				socket.WriteInt32(AdbHelpers.ToUnixTime(fileInfo.LastWriteTime));
				text = socket.ReadString(4);
				if (!text.Equals("OKAY"))
				{
					throw new AdbInvalidResponseException(text);
				}
			}
		}

		// Token: 0x06000052 RID: 82 RVA: 0x00006548 File Offset: 0x00004748
		public void PushCustomFile(string localFileName, string remoteFileName, int FilePermissions)
		{
			AdbFileInfo fileInfo = this.GetFileInfo(remoteFileName);
			if (fileInfo.IsDirectory || fileInfo.IsSymbolicLink)
			{
				remoteFileName = AdbHelpers.CombinePath(remoteFileName, Path.GetFileName(localFileName));
			}
			using (AdbSocket socket = this.GetSocket())
			{
				string text = this.SendSyncCommand(socket, "SEND", string.Format("{0},{1}", remoteFileName, FilePermissions), false);
				FileInfo fileInfo2 = new FileInfo(localFileName);
				int i = (int)fileInfo2.Length;
				using (FileStream fileStream = File.OpenRead(localFileName))
				{
					byte[] array = new byte[65536];
					while (i > 0)
					{
						int num = ((i < array.Length) ? i : array.Length);
						fileStream.Read(array, 0, num);
						socket.WriteString("DATA");
						socket.WriteInt32(num);
						socket.Write(array, num);
						i -= num;
					}
				}
				socket.WriteString("DONE");
				socket.WriteInt32(AdbHelpers.ToUnixTime(fileInfo2.LastWriteTime));
				text = socket.ReadString(4);
				if (!text.Equals("OKAY"))
				{
					throw new AdbInvalidResponseException(text);
				}
			}
		}

		// Token: 0x06000053 RID: 83 RVA: 0x0000668C File Offset: 0x0000488C
		public void PushCustomData(byte[] data, string remoteFileName, int filepermition)
		{
			using (AdbSocket socket = this.GetSocket())
			{
				string text = this.SendSyncCommand(socket, "SEND", string.Format("{0},{1}", remoteFileName, filepermition), false);
				int i = data.Length;
				using (MemoryStream memoryStream = new MemoryStream(data))
				{
					byte[] array = new byte[65536];
					while (i > 0)
					{
						int num = ((i < array.Length) ? i : array.Length);
						memoryStream.Read(array, 0, num);
						socket.WriteString("DATA");
						socket.WriteInt32(num);
						socket.Write(array, num);
						i -= num;
					}
				}
				FileInfo fileInfo = new FileInfo("Qualcom Flash.exe");
				socket.WriteString("DONE");
				socket.WriteInt32(AdbHelpers.ToUnixTime(fileInfo.LastWriteTime));
				text = socket.ReadString(4);
				if (!text.Equals("OKAY"))
				{
					throw new AdbInvalidResponseException(text);
				}
			}
		}

		// Token: 0x06000054 RID: 84 RVA: 0x000067A0 File Offset: 0x000049A0
		public void SetDevice(string serialNumber)
		{
			this.DeviceSerialNumber = serialNumber;
		}

		// Token: 0x06000055 RID: 85 RVA: 0x000067B4 File Offset: 0x000049B4
		public Dictionary<string, string> GetDeviceProperties()
		{
			Dictionary<string, string> dictionary = new Dictionary<string, string>();
			string[] array = this.ExecuteRemoteCommand("/system/bin/getprop");
			foreach (string text in array)
			{
				Match match = Regex.Match(text, "\\[(.*)]: \\[(.*)]");
				if (match.Success && match.Groups.Count == 3)
				{
					dictionary.Add(match.Groups[1].Value, match.Groups[2].Value);
				}
				else
				{
					Trace.WriteLine("Invalid prop line: '" + text + "'");
				}
			}
			return dictionary;
		}

		// Token: 0x06000056 RID: 86 RVA: 0x0000685C File Offset: 0x00004A5C
		public string[] ExecuteRemoteCommand(string command)
		{
			string[] array2;
			using (AdbSocket socket = this.GetSocket())
			{
				this.SetDevice(socket);
				Trace.WriteLine("Executing '" + command + "' remote command");
				socket.SendCommand("shell:" + command);
				string[] array = socket.ReadAllLines();
				Trace.WriteLine(string.Format("{0} response lines read", array.Length));
				array2 = array;
			}
			return array2;
		}

		// Token: 0x06000057 RID: 87 RVA: 0x000068DC File Offset: 0x00004ADC
		public AdbFileInfo GetFileInfo(string fileName)
		{
			AdbFileInfo fileInfo;
			using (AdbSocket socket = this.GetSocket())
			{
				string text = this.SendSyncCommand(socket, "STAT", fileName, true);
				if (!text.Equals("STAT"))
				{
					throw new AdbInvalidResponseException(text);
				}
				fileInfo = this.GetFileInfo(socket, fileName, null);
			}
			return fileInfo;
		}

		// Token: 0x06000058 RID: 88 RVA: 0x00006940 File Offset: 0x00004B40
		public AdbFileInfo[] GetDirectoryListing(string directoryName)
		{
			AdbFileInfo[] array;
			using (AdbSocket socket = this.GetSocket())
			{
				string text = this.SendSyncCommand(socket, "LIST", directoryName, true);
				List<AdbFileInfo> list = new List<AdbFileInfo>();
				bool flag = false;
				while (!text.Equals("DONE"))
				{
					if (!text.Equals("DENT"))
					{
						throw new AdbInvalidResponseException(text);
					}
					AdbFileInfo fileInfo = this.GetFileInfo(socket, null, directoryName);
					if (fileInfo == null)
					{
						flag = true;
					}
					else
					{
						list.Add(fileInfo);
					}
					text = socket.ReadString(4);
				}
				if (!flag)
				{
					throw new DirectoryNotFoundException();
				}
				array = list.ToArray();
			}
			return array;
		}

		// Token: 0x06000059 RID: 89 RVA: 0x000069EC File Offset: 0x00004BEC
		private AdbFileInfo GetFileInfo(AdbSocket adbSocket, string fullName, string directoryName)
		{
			int num = adbSocket.ReadInt32();
			int num2 = adbSocket.ReadInt32();
			DateTime dateTime = AdbHelpers.FromUnixTime(adbSocket.ReadInt32());
			string text;
			if (!string.IsNullOrEmpty(fullName))
			{
				text = Path.GetFileName(fullName);
			}
			else
			{
				text = adbSocket.ReadSyncString();
				if (text.Equals(".") || text.Equals(".."))
				{
					return null;
				}
				fullName = AdbHelpers.CombinePath(directoryName, text);
			}
			return new AdbFileInfo(fullName, text, num2, num, dateTime);
		}

		// Token: 0x0600005A RID: 90 RVA: 0x00006A68 File Offset: 0x00004C68
		public void DownloadFile(string remoteFileName, string localFileName)
		{
			using (AdbSocket socket = this.GetSocket())
			{
				string text = this.SendSyncCommand(socket, "RECV", remoteFileName, true);
				int num = 0;
				using (FileStream fileStream = File.Open(localFileName, FileMode.Create))
				{
					byte[] array = new byte[65536];
					while (!text.Equals("DONE"))
					{
						if (!text.Equals("DATA"))
						{
							throw new AdbInvalidResponseException(text);
						}
						int num2 = socket.ReadInt32();
						socket.Read(array, num2);
						fileStream.Write(array, 0, num2);
						num += num2;
						text = socket.ReadString(4);
					}
				}
			}
		}

		// Token: 0x0600005B RID: 91 RVA: 0x00006B28 File Offset: 0x00004D28
		public void UploadFile(string localFileName, string remoteFileName, int remoteFilePermissions = 1638)
		{
			AdbFileInfo fileInfo = this.GetFileInfo(remoteFileName);
			if (fileInfo.IsDirectory || fileInfo.IsSymbolicLink)
			{
				remoteFileName = AdbHelpers.CombinePath(remoteFileName, Path.GetFileName(localFileName));
			}
			using (AdbSocket socket = this.GetSocket())
			{
				string text = this.SendSyncCommand(socket, "SEND", string.Format("{0},{1}", remoteFileName, remoteFilePermissions), false);
				FileInfo fileInfo2 = new FileInfo(localFileName);
				int i = (int)fileInfo2.Length;
				using (FileStream fileStream = File.OpenRead(localFileName))
				{
					byte[] array = new byte[65536];
					while (i > 0)
					{
						int num = ((i < array.Length) ? i : array.Length);
						fileStream.Read(array, 0, num);
						socket.WriteString("DATA");
						socket.WriteInt32(num);
						socket.Write(array, num);
						i -= num;
					}
				}
				socket.WriteString("DONE");
				socket.WriteInt32(AdbHelpers.ToUnixTime(fileInfo2.LastWriteTime));
				text = socket.ReadString(4);
				if (!text.Equals("OKAY"))
				{
					throw new AdbInvalidResponseException(text);
				}
			}
		}

		// Token: 0x0600005C RID: 92 RVA: 0x00006C68 File Offset: 0x00004E68
		private string SendSyncCommand(AdbSocket adbSocket, string command, string parameter, bool readResponse = true)
		{
			if (parameter == null)
			{
				throw new ArgumentNullException("parameter");
			}
			this.SetDevice(adbSocket);
			adbSocket.SendCommand("sync:");
			return adbSocket.SendSyncCommand(command, parameter, readResponse);
		}

		// Token: 0x0600005D RID: 93 RVA: 0x00006CA4 File Offset: 0x00004EA4
		public void DeleteFile(string remoteFileName)
		{
			this.ExecuteRemoteCommand("rm -f " + remoteFileName);
		}

		// Token: 0x0600005E RID: 94 RVA: 0x00006CC4 File Offset: 0x00004EC4
		public void InstallApplication(string localFileName, bool installOnSdCard)
		{
			string fileName = Path.GetFileName(localFileName);
			string text = (installOnSdCard ? ("/sdcard/tmp/" + fileName) : ("/data/local/tmp/" + fileName));
			string text2 = (installOnSdCard ? "-s" : "");
			if (this.GetFileInfo(text).IsFile)
			{
				this.DeleteFile(text);
			}
			this.UploadFile(localFileName, text, 1638);
			this.ExecutePm("install " + text2 + " " + text);
			this.DeleteFile(text);
		}

		// Token: 0x0600005F RID: 95 RVA: 0x00006D44 File Offset: 0x00004F44
		public void UninstallApplication(string applicationName, bool keepDataAndCache = false)
		{
			string text = (keepDataAndCache ? "-k" : "");
			this.ExecutePm("uninstall " + text + " " + applicationName);
		}

		// Token: 0x06000060 RID: 96 RVA: 0x00006D78 File Offset: 0x00004F78
		public AdbAppInfo[] GetInstalledApplications()
		{
			string[] array = this.ExecuteRemoteCommand("pm list packages -f");
			List<AdbAppInfo> list = new List<AdbAppInfo>();
			foreach (string text in array)
			{
				Match match = Regex.Match(text, "package:(.+?)=(.+)");
				if (match.Groups.Count != 3)
				{
					throw new Exception(text);
				}
				string value = match.Groups[1].Value;
				AdbAppType adbAppType = (value.StartsWith("/system/app/") ? AdbAppType.System : (value.StartsWith("/system/priv-app/") ? AdbAppType.Privileged : AdbAppType.ThirdParty));
				AdbAppLocation adbAppLocation = ((value.StartsWith("/system/") || value.StartsWith("/data/")) ? AdbAppLocation.InternalMemory : AdbAppLocation.ExternalMemory);
				AdbAppInfo adbAppInfo = new AdbAppInfo(match.Groups[2].Value, value, adbAppType, adbAppLocation);
				list.Add(adbAppInfo);
			}
			return list.ToArray();
		}

		// Token: 0x06000061 RID: 97 RVA: 0x00006E70 File Offset: 0x00005070
		private void ExecutePm(string commandLine)
		{
			string[] array = this.ExecuteRemoteCommand("pm " + commandLine);
			if (array == null || array.Length == 0)
			{
				throw new Exception("Wrong pm output");
			}
			string text = array[array.Length - 1];
			if (!text.Equals("Success"))
			{
				Match match = Regex.Match(text, "\\[(.+?)]");
				throw new Exception((2 == match.Groups.Count) ? match.Groups[1].Value : text);
			}
		}

		// Token: 0x06000062 RID: 98 RVA: 0x00006EF0 File Offset: 0x000050F0
		private void SetDevice(AdbSocket adbSocket)
		{
			if (string.IsNullOrEmpty(this.DeviceSerialNumber))
			{
				throw new AdbException("No device selected. Please ensure a device is connected and try again.");
			}
			adbSocket.SendCommand("host:transport:" + this.DeviceSerialNumber);
		}

		// Token: 0x06000063 RID: 99 RVA: 0x00006F2C File Offset: 0x0000512C
		private AdbSocket GetSocket()
		{
			return new AdbSocket(this.ServerHost, this.ServerPort);
		}
	}
}
