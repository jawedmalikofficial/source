﻿using System;
using System.IO;

namespace Vurdalakov
{
	// Token: 0x02000015 RID: 21
	public static class AdbHelpers
	{
		// Token: 0x0600007E RID: 126 RVA: 0x00007208 File Offset: 0x00005408
		public static string CombinePath(string path1, string path2)
		{
			return Path.Combine(path1, path2).Replace('\\', '/');
		}

		// Token: 0x0600007F RID: 127 RVA: 0x00007228 File Offset: 0x00005428
		private static DateTime GetUnixEpoch()
		{
			return new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
		}

		// Token: 0x06000080 RID: 128 RVA: 0x00007248 File Offset: 0x00005448
		public static DateTime FromUnixTime(int unixTime)
		{
			return AdbHelpers.GetUnixEpoch().AddSeconds((double)unixTime).ToLocalTime();
		}

		// Token: 0x06000081 RID: 129 RVA: 0x00007270 File Offset: 0x00005470
		public static int ToUnixTime(DateTime dateTime)
		{
			return Convert.ToInt32((dateTime.ToUniversalTime() - AdbHelpers.GetUnixEpoch()).TotalSeconds);
		}
	}
}
