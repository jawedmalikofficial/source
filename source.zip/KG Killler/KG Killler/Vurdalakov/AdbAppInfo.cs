﻿using System;

namespace Vurdalakov
{
	// Token: 0x0200000F RID: 15
	public class AdbAppInfo
	{
		// Token: 0x17000004 RID: 4
		// (get) Token: 0x0600003C RID: 60 RVA: 0x00005FB0 File Offset: 0x000041B0
		// (set) Token: 0x0600003D RID: 61 RVA: 0x00005FC4 File Offset: 0x000041C4
		public string Name { get; private set; }

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x0600003E RID: 62 RVA: 0x00005FD8 File Offset: 0x000041D8
		// (set) Token: 0x0600003F RID: 63 RVA: 0x00005FEC File Offset: 0x000041EC
		public string FileName { get; private set; }

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x06000040 RID: 64 RVA: 0x00006000 File Offset: 0x00004200
		// (set) Token: 0x06000041 RID: 65 RVA: 0x00006014 File Offset: 0x00004214
		public AdbAppType Type { get; private set; }

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000042 RID: 66 RVA: 0x00006028 File Offset: 0x00004228
		// (set) Token: 0x06000043 RID: 67 RVA: 0x0000603C File Offset: 0x0000423C
		public AdbAppLocation Location { get; private set; }

		// Token: 0x06000044 RID: 68 RVA: 0x00006050 File Offset: 0x00004250
		public AdbAppInfo(string name, string fileName, AdbAppType type, AdbAppLocation location)
		{
			this.Name = name;
			this.FileName = fileName;
			this.Type = type;
			this.Location = location;
		}
	}
}
