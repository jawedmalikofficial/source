﻿using System;

namespace Vurdalakov
{
	// Token: 0x02000012 RID: 18
	public class AdbException : Exception
	{
		// Token: 0x0600006E RID: 110 RVA: 0x0000707C File Offset: 0x0000527C
		internal AdbException(string message)
			: base(message)
		{
		}
	}
}
