﻿using System;
using System.Diagnostics;

namespace Vurdalakov
{
	// Token: 0x02000017 RID: 23
	internal static class Tracer
	{
		// Token: 0x06000092 RID: 146 RVA: 0x0000762C File Offset: 0x0000582C
		public static void Trace(string format, params object[] args)
		{
			string text = string.Format(format, args);
			global::System.Diagnostics.Trace.WriteLine(text);
		}
	}
}
