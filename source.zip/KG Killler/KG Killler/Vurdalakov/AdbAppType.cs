﻿using System;

namespace Vurdalakov
{
	// Token: 0x0200000D RID: 13
	public enum AdbAppType
	{
		// Token: 0x04000030 RID: 48
		Unknown,
		// Token: 0x04000031 RID: 49
		System,
		// Token: 0x04000032 RID: 50
		Privileged,
		// Token: 0x04000033 RID: 51
		ThirdParty
	}
}
