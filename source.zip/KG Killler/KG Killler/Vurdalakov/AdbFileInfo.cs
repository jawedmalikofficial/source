﻿using System;

namespace Vurdalakov
{
	// Token: 0x02000014 RID: 20
	public class AdbFileInfo
	{
		// Token: 0x1700000F RID: 15
		// (get) Token: 0x06000070 RID: 112 RVA: 0x000070B4 File Offset: 0x000052B4
		// (set) Token: 0x06000071 RID: 113 RVA: 0x000070C8 File Offset: 0x000052C8
		public string FullName { get; private set; }

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x06000072 RID: 114 RVA: 0x000070DC File Offset: 0x000052DC
		// (set) Token: 0x06000073 RID: 115 RVA: 0x000070F0 File Offset: 0x000052F0
		public string Name { get; private set; }

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x06000074 RID: 116 RVA: 0x00007104 File Offset: 0x00005304
		// (set) Token: 0x06000075 RID: 117 RVA: 0x00007118 File Offset: 0x00005318
		public int Size { get; private set; }

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x06000076 RID: 118 RVA: 0x0000712C File Offset: 0x0000532C
		// (set) Token: 0x06000077 RID: 119 RVA: 0x00007140 File Offset: 0x00005340
		public int Mode { get; private set; }

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x06000078 RID: 120 RVA: 0x00007154 File Offset: 0x00005354
		// (set) Token: 0x06000079 RID: 121 RVA: 0x00007168 File Offset: 0x00005368
		public DateTime Modified { get; private set; }

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x0600007A RID: 122 RVA: 0x0000717C File Offset: 0x0000537C
		public bool IsFile
		{
			get
			{
				return (this.Mode & 32768) > 0;
			}
		}

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x0600007B RID: 123 RVA: 0x00007198 File Offset: 0x00005398
		public bool IsDirectory
		{
			get
			{
				return (this.Mode & 16384) > 0;
			}
		}

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x0600007C RID: 124 RVA: 0x000071B4 File Offset: 0x000053B4
		public bool IsSymbolicLink
		{
			get
			{
				return (this.Mode & 40960) > 0;
			}
		}

		// Token: 0x0600007D RID: 125 RVA: 0x000071D0 File Offset: 0x000053D0
		internal AdbFileInfo(string fullName, string name, int size, int mode, DateTime modified)
		{
			this.FullName = fullName;
			this.Name = name;
			this.Size = size;
			this.Mode = mode;
			this.Modified = modified;
		}
	}
}
