﻿using System;

namespace Vurdalakov
{
	// Token: 0x02000013 RID: 19
	public class AdbInvalidResponseException : AdbException
	{
		// Token: 0x0600006F RID: 111 RVA: 0x00007090 File Offset: 0x00005290
		internal AdbInvalidResponseException(string response)
			: base("The server returned an invalid response '" + response + "'")
		{
		}
	}
}
