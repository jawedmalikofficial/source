﻿using System;

namespace Vurdalakov
{
	// Token: 0x0200000E RID: 14
	public enum AdbAppLocation
	{
		// Token: 0x04000035 RID: 53
		InternalMemory,
		// Token: 0x04000036 RID: 54
		ExternalMemory
	}
}
