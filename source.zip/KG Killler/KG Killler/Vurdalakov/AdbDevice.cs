﻿using System;

namespace Vurdalakov
{
	// Token: 0x02000011 RID: 17
	public class AdbDevice
	{
		// Token: 0x1700000B RID: 11
		// (get) Token: 0x06000064 RID: 100 RVA: 0x00006F4C File Offset: 0x0000514C
		// (set) Token: 0x06000065 RID: 101 RVA: 0x00006F60 File Offset: 0x00005160
		public string SerialNumber { get; private set; }

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x06000066 RID: 102 RVA: 0x00006F74 File Offset: 0x00005174
		// (set) Token: 0x06000067 RID: 103 RVA: 0x00006F88 File Offset: 0x00005188
		public string Product { get; private set; }

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x06000068 RID: 104 RVA: 0x00006F9C File Offset: 0x0000519C
		// (set) Token: 0x06000069 RID: 105 RVA: 0x00006FB0 File Offset: 0x000051B0
		public string Model { get; private set; }

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x0600006A RID: 106 RVA: 0x00006FC4 File Offset: 0x000051C4
		// (set) Token: 0x0600006B RID: 107 RVA: 0x00006FD8 File Offset: 0x000051D8
		public string Device { get; private set; }

		// Token: 0x0600006C RID: 108 RVA: 0x00006FEC File Offset: 0x000051EC
		public AdbDevice(string id, string product, string model, string device)
		{
			this.SerialNumber = id;
			this.Product = product;
			this.Model = model;
			this.Device = device;
		}

		// Token: 0x0600006D RID: 109 RVA: 0x0000701C File Offset: 0x0000521C
		public override string ToString()
		{
			return string.Concat(new string[] { "serialNumber:", this.SerialNumber, ", product:", this.Product, ", model:", this.Model, ", device:", this.Device });
		}
	}
}
