﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net.Sockets;
using System.Text;

namespace Vurdalakov
{
	// Token: 0x02000016 RID: 22
	public class AdbSocket : IDisposable
	{
		// Token: 0x06000082 RID: 130 RVA: 0x000072A0 File Offset: 0x000054A0
		public AdbSocket(string adbServerHost, int adbServerPort)
		{
			Trace.WriteLine(string.Format("Connecting to {0} port {1}", adbServerHost, adbServerPort));
			this._tcpClient = new TcpClient(adbServerHost, adbServerPort);
			this._tcpStream = this._tcpClient.GetStream();
		}

		// Token: 0x06000083 RID: 131 RVA: 0x00007304 File Offset: 0x00005504
		public void Dispose()
		{
			if (this._tcpClient != null)
			{
				this._tcpClient.Close();
				this._tcpClient = null;
			}
			if (this._tcpStream != null)
			{
				this._tcpStream.Close();
				this._tcpStream = null;
			}
		}

		// Token: 0x06000084 RID: 132 RVA: 0x0000734C File Offset: 0x0000554C
		public void Write(byte[] data, int size)
		{
			Trace.WriteLine("$Sending {size} bytes");
			this._tcpStream.Write(data, 0, size);
		}

		// Token: 0x06000085 RID: 133 RVA: 0x00007374 File Offset: 0x00005574
		public void Write(byte[] data)
		{
			this.Write(data, data.Length);
		}

		// Token: 0x06000086 RID: 134 RVA: 0x0000738C File Offset: 0x0000558C
		public void WriteString(string text)
		{
			int bytes = this._encoding.GetBytes(text, 0, text.Length, this._buffer, 0);
			this.Write(this._buffer, bytes);
		}

		// Token: 0x06000087 RID: 135 RVA: 0x000073C4 File Offset: 0x000055C4
		public void WriteInt32(int number)
		{
			byte[] bytes = BitConverter.GetBytes(number);
			this.Write(bytes);
		}

		// Token: 0x06000088 RID: 136 RVA: 0x000073E0 File Offset: 0x000055E0
		public void SendCommand(string command)
		{
			this.WriteString(string.Format("{0:X04}", command.Length));
			this.WriteString(command);
			string text = this.ReadString(4);
			string text2 = text;
			string text3 = text2;
			if (text3 == "OKAY")
			{
				return;
			}
			if (!(text3 == "FAIL"))
			{
				throw new AdbInvalidResponseException(text);
			}
			string text4 = this.ReadHexString();
			throw new AdbException(text4);
		}

		// Token: 0x06000089 RID: 137 RVA: 0x0000744C File Offset: 0x0000564C
		public string SendSyncCommand(string command, string parameter, bool readResponse = true)
		{
			this.WriteString(command);
			this.WriteInt32(parameter.Length);
			this.WriteString(parameter);
			string text;
			if (!readResponse)
			{
				text = null;
			}
			else
			{
				string text2 = this.ReadString(4);
				if (text2.Equals("FAIL"))
				{
					string text3 = this.ReadSyncString();
					throw new AdbException(text3);
				}
				text = text2;
			}
			return text;
		}

		// Token: 0x0600008A RID: 138 RVA: 0x000074A8 File Offset: 0x000056A8
		public void Read(byte[] data, int size)
		{
			int num;
			for (int i = 0; i < size; i += num)
			{
				num = this._tcpStream.Read(data, i, size - i);
			}
		}

		// Token: 0x0600008B RID: 139 RVA: 0x000074D4 File Offset: 0x000056D4
		public byte[] Read(int size)
		{
			byte[] array = new byte[size];
			this.Read(array, size);
			return array;
		}

		// Token: 0x0600008C RID: 140 RVA: 0x000074F4 File Offset: 0x000056F4
		public string ReadHexString()
		{
			int num = this.ReadInt32Hex();
			return this.ReadString(num);
		}

		// Token: 0x0600008D RID: 141 RVA: 0x00007514 File Offset: 0x00005714
		public string ReadSyncString()
		{
			int num = this.ReadInt32();
			return this.ReadString(num);
		}

		// Token: 0x0600008E RID: 142 RVA: 0x00007534 File Offset: 0x00005734
		public string ReadString(int length)
		{
			this.Read(this._buffer, length);
			return this._encoding.GetString(this._buffer, 0, length);
		}

		// Token: 0x0600008F RID: 143 RVA: 0x00007564 File Offset: 0x00005764
		public int ReadInt32()
		{
			this.Read(this._buffer, 4);
			return BitConverter.ToInt32(this._buffer, 0);
		}

		// Token: 0x06000090 RID: 144 RVA: 0x0000758C File Offset: 0x0000578C
		public int ReadInt32Hex()
		{
			this.Read(this._buffer, 4);
			string @string = this._encoding.GetString(this._buffer, 0, 4);
			return Convert.ToInt32(@string, 16);
		}

		// Token: 0x06000091 RID: 145 RVA: 0x000075C4 File Offset: 0x000057C4
		public string[] ReadAllLines()
		{
			List<string> list = new List<string>();
			using (StreamReader streamReader = new StreamReader(this._tcpStream, this._encoding))
			{
				for (;;)
				{
					string text = streamReader.ReadLine();
					if (text == null)
					{
						break;
					}
					list.Add(text.Trim());
				}
			}
			return list.ToArray();
		}

		// Token: 0x04000047 RID: 71
		private TcpClient _tcpClient;

		// Token: 0x04000048 RID: 72
		private NetworkStream _tcpStream;

		// Token: 0x04000049 RID: 73
		private Encoding _encoding = Encoding.ASCII;

		// Token: 0x0400004A RID: 74
		private byte[] _buffer = new byte[65536];
	}
}
