﻿using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCopyright("Copyright ©  2025")]
[assembly: AssemblyProduct("KG Killer")]
[assembly: ComVisible(false)]
[assembly: AssemblyFileVersion("1.1.0.0")]
[assembly: Guid("932ba5da-292f-4e25-ab18-a2c137133892")]
[assembly: AssemblyTitle("KG Killer")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyDescription("")]
